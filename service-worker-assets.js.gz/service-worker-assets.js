self.assetsManifest = {
  "version": "0E7CroKG",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-UTsdNt4S8WyekD6NaMRXv0cUB1GhhGX+w1UuwMVxBeM=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-H2isaZ53T9C9Cjuo3GDKTTVVX2+Jyp49vTQqIizli7o=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-/c9d+qSA9YvRQDEeZYgj6ujsaE4sVJP2EqKMkiPrQp8=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-aXO3nT/tQXQvoGov063c6RR9RqHbArqZJVfVvuiuLD0=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-oUqzDxYNe80U+p/qGo910JR5uFQIteOxLz1nRjlOAi0=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-Pkmxp6rDnZMjlDI8IcCiFJaISJ1wwCj0DCB83oaSWHE=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-YKTqF/PeRZh8JxMKa4pkDSfK9ndKDiP8T/iPBIqW7oY=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-lYiMLG73UrqjeD3Xr0zwkygnPDSAQXeAo1554Yjqjkc=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-l/ZGAFp2SORhl7K9Ekdt30syx8J/xnmbMBRnjefHLVg=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-ASenGQ0qtDWcJJwD/kgvKLY3qE8DmpyYxgIKt3sDxVs=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-llsqvUDX8RtZTd6uSsXceE3QLngeVN1bfcHPKEwikVM=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-+PA/TMpN+uUgTwqwLmA/nfoyXy9AzOtxFRb9Ejy0j6k=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-M67GWBq1Bsd5BV1IvRUQovJf4pkQMlEsKbJH/orKcRY=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-J8kJYxpBFMrMjHMBSdDlq1lYqyntxOrDZ8AW5FrxH8U=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-ePDcJeBSPqJ7h6WXrgiSaI1wC1G8mRuGj9qIRlvYFIE=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-w1XovCe2kAYrpOm1IUBE8IY/HtX2gaXunMyYw/9kREs=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-2Qlb9LfJ0NroHfpwiy5SCLgNO+2PgU6yR2VRevlG8+k=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-mscmBJFsTrAe0H/SoknylPnukiQX2yfQ/zSnbR4B75k=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-K4Jcog9fWBBjdc+vqtzPa8i9rj4LmVd+spMDEOi2XjY=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-y6x9nQqkv3mW+Dvmm6Pvh+h0ixHfY0RLzrX6ZlktoG4=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-qu0hDOMug/SbTyvDCArFqmbyWUtIZW6ewsomFTsPmTo=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-fzXK/2BQ8C/lABKJC6dsV+cXmFHprEg2ICoPIqt6r2E=",
      "url": "_content/Radzen.Blazor/css/math.css"
    },
    {
      "hash": "sha256-rVLBtcwkha2PQ5Wy+ZkDJlzDWNZu3kpWw3QFCN7dkSI=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-wW+2Eei8ExpLmiApBFciKhnIm+srIAfL+Go+zcILNM0=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-mHh6OGo9cpMZlZptx+gUmbVAY28oSpRtDR7lsb98WKk=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-TjqNr8JLfhv7jiFYkwFNPke+bQkQEOQLFwnO+0t7gm4=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-tRcVAq9DGc0nyvTuxUpiBTY8PaxnC6deHLSE8Ri1PMg=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-1ARypMyu4wyySalAaYTargYaSll8vbBSAvkgCSD+C+0=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-9eA/OFwBHycmqnQL7NASxOMXUE8QHC916BhfHA5DIdk=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-2NxnHsJ1p7hp54u7yIVd7FTlccJ0pva8DFRseBUgyMs=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-HYNTnwNf3xj899KPdiKwmD1e5t3XRg9VaQgB1ZOvKeI=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-ijCqUV/NmJnx4I0HD2JosPwpVwGfiuvjr0GXRziiNM4=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GFU2mt0A9T8j9YMwMQqIUmdziKNDuPppDCn2o37LV2E=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-6SXtjzHKt3MITLXtm3YKGAubIblIlRCCFaUuA/iLeFI=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-+eSpwuS0Mx0DVjyuFo3DoQXiI+Mp+4I1MtdWSbDcZK4=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-jvdEwbPP9ySWwm0cTSiOqdIfO15rtDmoxKmiqmFQR/A=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js"
    },
    {
      "hash": "sha256-y7L+XtwoUJtcUnvXGeRLVrLj2uLMTgPyNKJlEJnFbpc=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js.map"
    },
    {
      "hash": "sha256-pCIEjwDATOwa31+YvucoW1WTxT4YiQVDFhw94hu6wx8=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js"
    },
    {
      "hash": "sha256-MTgEQwaemErPPoFSvy9/AvhoR7QaOAVkSgXh+Gs5jmY=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js.map"
    },
    {
      "hash": "sha256-la7lyIF2RfLmzbgQq451BnkJEU/wykMPE6pCn8Po4pI=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js"
    },
    {
      "hash": "sha256-HQWKRYNJ6U0CQ6cjuHiZNYzn9EyBxinvWwT2zctFdWE=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js.map"
    },
    {
      "hash": "sha256-YQqC+x+db2pnQw/gibR4ai58y8WWbVsaiM7Dg/5ZjmQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-YEIKzZHjTFrB0PdPq+MUTCQVa9BXJOk4GoWEv21FNno=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-eM8DTi6b6DvS8NIedSLSGsOM4Y0OGeQUae6fmc0F5HQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.map"
    },
    {
      "hash": "sha256-tmxVjsHcxYihEtmXEJz2gJejcMpa2tNP2K5IAMBUwls=",
      "url": "_content/Z.Blazor.Diagrams/Z.Blazor.Diagrams.ezdqu7jd9f.bundle.scp.css"
    },
    {
      "hash": "sha256-s7EEPdhBW2P8sjiCOtar0D9cqNeKSPOwBxqj89twi14=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.css"
    },
    {
      "hash": "sha256-tjG7h09kCbOtLws3pLFB95nmOYxMZl7c8jbGPTarGBc=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.min.css"
    },
    {
      "hash": "sha256-DPGv+cCxzPgtITUub8yFS2/hFYsTZvuV+MX2hT1/C58=",
      "url": "_content/Z.Blazor.Diagrams/script.js"
    },
    {
      "hash": "sha256-LgAw9yB0DF0MNdupxctpNfEU7NoB56YJnh9QpuwRcI8=",
      "url": "_content/Z.Blazor.Diagrams/script.min.js"
    },
    {
      "hash": "sha256-EntOrNcHrVMAVfWpFhvF7p3Dlm2ljQBZcZQoK9/ENig=",
      "url": "_content/Z.Blazor.Diagrams/style.css"
    },
    {
      "hash": "sha256-UKzIp+VqUElrrWqYXITbK2mVVp6d5hx2LP+pnMfozLA=",
      "url": "_content/Z.Blazor.Diagrams/style.min.css"
    },
    {
      "hash": "sha256-qbG0STeTRSjScVJ9SBP9y6zl4YpUsBt317lGajCmB8Q=",
      "url": "_framework/AutomaticGraphLayout.Drawing.rfmvbsf468.wasm"
    },
    {
      "hash": "sha256-G5FHc2TipvCo7po6ZTAuX5MXPHgkB4E+CcQNvwSgIvo=",
      "url": "_framework/AutomaticGraphLayout.xhitsgdb3e.wasm"
    },
    {
      "hash": "sha256-W5jAEh1BJpID2KOjfMO9vOPVsdrYaro2ijjK6RlgFTc=",
      "url": "_framework/Blazor.Diagrams.Core.z625myqj9k.wasm"
    },
    {
      "hash": "sha256-zGXooQdLm05nUxu/a1HW0N8h1onvcACfrPx+R+fpsFI=",
      "url": "_framework/Blazor.Diagrams.ckfoh8zkyc.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-fMK+NZ4d4f3Cu2k2Jb6c6p3x8UkoVOuL4PUI3X76ZKo=",
      "url": "_framework/DotNetGraph.cy7hbw1uck.wasm"
    },
    {
      "hash": "sha256-UUDdQpFUY9H2fvZxvGhWLfifbi0vztUkLr14L1HLE9U=",
      "url": "_framework/ExCSS.vo340561u5.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-EBslmZvfsvpTBdvOmv3rEOEg7Pc+HAABf7+3bJOokfc=",
      "url": "_framework/Fluxor.Blazor.Web.cl1oh36s39.wasm"
    },
    {
      "hash": "sha256-CBwb6mnXIjpbnXexXCi/0Vn5zSfHJ4EIS13gFgjF5yw=",
      "url": "_framework/Fluxor.wi21xylim8.wasm"
    },
    {
      "hash": "sha256-vWWYHbk3g3RAr1Cq7vLANE1X9injjsMCs/Q4SxpVro8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.tklmjzr5f8.wasm"
    },
    {
      "hash": "sha256-zrDlLPjjOdssPXYMyg2qZH4E54MvH3WHj5ZSO+LeoFA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.yn7k9dprxr.wasm"
    },
    {
      "hash": "sha256-gRw7dqRpQlr3HvHhYSfj0f4iQ8uXl/vRp2GmGik9wEU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.37srkioahm.wasm"
    },
    {
      "hash": "sha256-JJHYfTYiEzTS8Dg8pGCxdJ3q2RDwQN85e1ehztcSC/4=",
      "url": "_framework/Microsoft.AspNetCore.Components.gj2w22xgvl.wasm"
    },
    {
      "hash": "sha256-P+WNRqM0ARPiggU5hSm7DG07rnaZws4l2DTdAREyU/g=",
      "url": "_framework/Microsoft.CSharp.x4d1qy86v4.wasm"
    },
    {
      "hash": "sha256-SvqIqLTJFeFnn2GyYARDkqvF//mAgsCnCMAO0bMqo60=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.e7obn5k3m8.wasm"
    },
    {
      "hash": "sha256-X+g8Y9v8Xs3DURC3DvFf0BXk5Ll4hWN5k4Oc+3lBALE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.this79iyc7.wasm"
    },
    {
      "hash": "sha256-AfgiKXj2TZbhvV4OmBVd8zf36SdWtLxp9dIGGJ3QRbY=",
      "url": "_framework/Microsoft.Extensions.Configuration.zr9y6n6fms.wasm"
    },
    {
      "hash": "sha256-0WoAnNfRdnrALxIZp3CmEUiJp5kR67kjUYdR54QzJ1U=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.fo89paewjc.wasm"
    },
    {
      "hash": "sha256-rW0muBNtI+FY/WA4kKZ6KaamvExUL3czb1N7sbPc6K4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t4styidezf.wasm"
    },
    {
      "hash": "sha256-/lATVMaxjrO/7QTYnmE50qdHvr8l76pNE9v29HGzLeA=",
      "url": "_framework/Microsoft.Extensions.Logging.6vimitskgi.wasm"
    },
    {
      "hash": "sha256-Sd/QuJbpZ5HmPGlArfPAzwi54qMUSYlcnVrdjPuUyWk=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.rzz6x5zk3e.wasm"
    },
    {
      "hash": "sha256-JlbZOlMD9T0hxIB/BNOZkM3df8T/zl1Vit9HLhkk7+o=",
      "url": "_framework/Microsoft.Extensions.Options.q3i6x9nfzx.wasm"
    },
    {
      "hash": "sha256-L5NQ4Q3qCOQCVq4fdxJDVX9+tmbCgm5IufwAOUFf37o=",
      "url": "_framework/Microsoft.Extensions.Primitives.330fdynik0.wasm"
    },
    {
      "hash": "sha256-VIuo9yzkHH7EkT5ryVFVloZp6epJE77ziW4ST6gJzyk=",
      "url": "_framework/Microsoft.JSInterop.461vd4e7nv.wasm"
    },
    {
      "hash": "sha256-EzPimVxYUyvc5hlmFOvopAur+oDc/0DNCvYv9ReoU70=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.pxf5p9f275.wasm"
    },
    {
      "hash": "sha256-ROod9Fw/Ap3gSrU9ZoOSMEenSzZJRdo1E9ajrfY+K0k=",
      "url": "_framework/Microsoft.Win32.Primitives.gryb9urwx1.wasm"
    },
    {
      "hash": "sha256-nXYtOu6My3FCAyF4pCSILuX5UCe9ol/mt50IEN83i2Y=",
      "url": "_framework/Microsoft.Win32.SystemEvents.1jfsd79cfg.wasm"
    },
    {
      "hash": "sha256-l2qEfPM/BjYyiblhUW+zUgDUT7vciCSwbC6Vj2Klbeo=",
      "url": "_framework/MoreLinq.zdi2h46g68.wasm"
    },
    {
      "hash": "sha256-IAxYZiEZO7Ijq+jc3xlUE5nb6YC0h2MNanbWQ7FgWPI=",
      "url": "_framework/Radzen.Blazor.o2o1skva7b.wasm"
    },
    {
      "hash": "sha256-Se8bMhgDQ5CWRlH5UwIuyZAptfmT6xgmEn/qjvP5FWc=",
      "url": "_framework/Shared.jp2cwmwx54.wasm"
    },
    {
      "hash": "sha256-bpNazKDAF+g6GXbLmWNtHXIVFX1MKO7pRkLak9gjSs0=",
      "url": "_framework/Siteswap.Details.ma3r2y4sbt.wasm"
    },
    {
      "hash": "sha256-We9IOjmLmfPvlcieiRhANDdhi1mswhpp4VsbttTIK3M=",
      "url": "_framework/Siteswaps.Components.bjbddmteim.wasm"
    },
    {
      "hash": "sha256-9bDbDW0Wn/qBoYADyCd1Q8FTO0vq37g0N/VV6ua1kTQ=",
      "url": "_framework/Siteswaps.Generator.b0c96x0jq3.wasm"
    },
    {
      "hash": "sha256-JZxJZVh7bDH/N3KNN5tfG1TTpfcpKjqKYju2rXzRKRs=",
      "url": "_framework/Siteswaps.Visualization.7951v1rbhb.wasm"
    },
    {
      "hash": "sha256-DKKfshozscJuj8Bu3AMR1WMZ4zuzcZPVAEG84+uWxqI=",
      "url": "_framework/SkiaSharp.4utg70glsy.wasm"
    },
    {
      "hash": "sha256-+5lFYk11wwtJKUvTMwXiuQWKVngS/3Y0LQV5hARgV2Q=",
      "url": "_framework/SkiaSharp.Views.Blazor.rwyxjek1ea.wasm"
    },
    {
      "hash": "sha256-k46YDqsBQ84522ERaK6jUsIe7mlIJ4lIxsWnckhxyvw=",
      "url": "_framework/Svg.3wlfysmzyb.wasm"
    },
    {
      "hash": "sha256-mnGtUMBNvStqULzvqZhBxCYgBKXWHcsZGJ33qucDawQ=",
      "url": "_framework/SvgPathProperties.ebwgyay2jc.wasm"
    },
    {
      "hash": "sha256-dlXrJg3okoKNIaZOapkmbh+ASJzDN5QLeVGhjx/+Dvc=",
      "url": "_framework/System.Collections.Concurrent.u3g4kbyr3e.wasm"
    },
    {
      "hash": "sha256-cQT3+P4PKsyFA0ZuDM7eusgicxB0ef2822xgWCpT6es=",
      "url": "_framework/System.Collections.Immutable.7u1x4otnb5.wasm"
    },
    {
      "hash": "sha256-BwZuLD9Ui41t6IYvRD7T07BQuaYVdYrzgfPDgcTQLG4=",
      "url": "_framework/System.Collections.NonGeneric.j9v3pjixv3.wasm"
    },
    {
      "hash": "sha256-O6ztG7XdZnQJGSnWfQlNbM1gUUzVr/b14GG66puTPn0=",
      "url": "_framework/System.Collections.Specialized.ndtatzpr9m.wasm"
    },
    {
      "hash": "sha256-pjQQ468OIZuYz5dFu64H2QJyYczuzu4izr8mfahND7Q=",
      "url": "_framework/System.Collections.mll0qt7km5.wasm"
    },
    {
      "hash": "sha256-7b5SoHBgk2q2inZ+momF5mcWn2oY07jgc6BFKEsQsD4=",
      "url": "_framework/System.ComponentModel.34cfq3thtd.wasm"
    },
    {
      "hash": "sha256-HaSxRBG4WBLZcXwczD58ukSh1u04kjA8DRUza47TJpU=",
      "url": "_framework/System.ComponentModel.Annotations.nz6eho343m.wasm"
    },
    {
      "hash": "sha256-ReeBBA4ErgrjZ1jaBCrjvTbZVakIuS3b/xDcbpMk/0s=",
      "url": "_framework/System.ComponentModel.Primitives.3mqwy6dngt.wasm"
    },
    {
      "hash": "sha256-SvB/g9GopRG7zaADT3Ni+ZEzd/forVWXitybVDtHMMo=",
      "url": "_framework/System.ComponentModel.TypeConverter.ilziju2l73.wasm"
    },
    {
      "hash": "sha256-aMO22P+wKaA4GiitOMS3sOy3iX9g2E6eBh9+TGoPa9E=",
      "url": "_framework/System.Console.khnuxw71fe.wasm"
    },
    {
      "hash": "sha256-xmUv3t5mFWd59uMHTahq9vfPH175ijcVNTkCkFCu47o=",
      "url": "_framework/System.Core.u22lkxza3s.wasm"
    },
    {
      "hash": "sha256-BVnkehNBH7sFXRzMY+GXqMqeoulDYni9Trr+JcvXZE8=",
      "url": "_framework/System.Data.Common.ducwct7vqu.wasm"
    },
    {
      "hash": "sha256-+/Et4aS2nrSOeIRmVCWtkIIW/YLiKRwrx4kRes2H6LE=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.xt9pws0gyn.wasm"
    },
    {
      "hash": "sha256-owCZQc6aKR6NQ4+YLh98wWKlZvxtGMG0i+ek7Pt7s3s=",
      "url": "_framework/System.Diagnostics.Process.hzmkmyjqqc.wasm"
    },
    {
      "hash": "sha256-ITnZGrksGlk0gSO5xb8Y75xC6MjKs4fMsO0iiFV9mag=",
      "url": "_framework/System.Diagnostics.TraceSource.9eaayhmh8c.wasm"
    },
    {
      "hash": "sha256-mdzUh7RMZ22qXG3yfLxvSVJ99+ApAr48sDT3oCDJjSU=",
      "url": "_framework/System.Drawing.Common.bvw409irsb.wasm"
    },
    {
      "hash": "sha256-NpJYKVkeo796dxjxap5S3gQ14K0e/5U7HrpEd1u4WDE=",
      "url": "_framework/System.Drawing.Primitives.6sw9ser5lf.wasm"
    },
    {
      "hash": "sha256-Ej5CbdGQVpcK2/j+cvjvK5FkC46u1cBZCZyOxmX97SI=",
      "url": "_framework/System.Drawing.uta1xg9fwj.wasm"
    },
    {
      "hash": "sha256-FpSbbe5yTw4Pz8libdpmxWmir3V2BRC6dmu8q/OwMxI=",
      "url": "_framework/System.IO.MemoryMappedFiles.i9ki523fqv.wasm"
    },
    {
      "hash": "sha256-H1CHBmaAMS4PKAPtP+BRNwndUH6Sgof2IjdMGHxUFvI=",
      "url": "_framework/System.IO.Pipelines.j7hw5n5kz8.wasm"
    },
    {
      "hash": "sha256-imbveOy45Mc/JclDtsfLeytrY8PW7jWLOBVN1/Grz1M=",
      "url": "_framework/System.Linq.69wtuomas5.wasm"
    },
    {
      "hash": "sha256-ZBX4y7qqNxAG2D1pxGD0kUN3ABBDQEQP0PY+XFZ7Y1Q=",
      "url": "_framework/System.Linq.Async.ovfc2irvky.wasm"
    },
    {
      "hash": "sha256-3sfrcDaB+fesAMjPOTCHQmJTfmjKjVhL9H/MMhMaV40=",
      "url": "_framework/System.Linq.Dynamic.Core.2czhr4esfi.wasm"
    },
    {
      "hash": "sha256-TVQ+ZTKayD1Y0R0bSpV66m/JfvEMBZ/83PJdsO88YbQ=",
      "url": "_framework/System.Linq.Expressions.1rwime10hy.wasm"
    },
    {
      "hash": "sha256-N4fuwSdmib3egAOHVg5O2daWzk3Jx9g7JZkChvucKks=",
      "url": "_framework/System.Linq.Queryable.h6u8ijn56r.wasm"
    },
    {
      "hash": "sha256-ED9xD2A6oHxAkUnL6+jBQ1e29zxr2rNWXcN+8aGTIUo=",
      "url": "_framework/System.Memory.go6xr1sxv4.wasm"
    },
    {
      "hash": "sha256-W/6WeYgLach+A3gwKVXKU1QJ1xsy8k2zKTl+FhMx9X0=",
      "url": "_framework/System.Net.Http.fv3zs96lbw.wasm"
    },
    {
      "hash": "sha256-VqluKffy/OTxept04cce4C+kkbZ4i0cm7j+US0qVijA=",
      "url": "_framework/System.Net.Primitives.evghnwnikt.wasm"
    },
    {
      "hash": "sha256-S0SYAPCkMEFDPePXLi6UIEKhFm/ZUJ3TddNQskUkg3g=",
      "url": "_framework/System.Numerics.Vectors.3up6sc7zqw.wasm"
    },
    {
      "hash": "sha256-7zgdUgAjvacZsFzm0h+BQddy68dfHYn2mBtc1A/ZoYI=",
      "url": "_framework/System.ObjectModel.rp9jxcpeqm.wasm"
    },
    {
      "hash": "sha256-y1gdzXhi7Xjcon11VVTyE3oGzSScplNNUGSHil2U5iU=",
      "url": "_framework/System.Private.CoreLib.pz38dlov5q.wasm"
    },
    {
      "hash": "sha256-S+cWWBeXxo3sI5CXrsVrrXVRUAcxbpmv1d5MnBQxjmI=",
      "url": "_framework/System.Private.DataContractSerialization.l065je84kl.wasm"
    },
    {
      "hash": "sha256-4ZZgTj6DvwH3rqxOkFGLLojW2Nxi4aW4xW/1dnnrGKU=",
      "url": "_framework/System.Private.Uri.zrnnp60wy1.wasm"
    },
    {
      "hash": "sha256-Irf4xYVoAEqi6iSfC67O26uIi6AfavNHSrGBgCde4lU=",
      "url": "_framework/System.Private.Windows.Core.usphw36xy5.wasm"
    },
    {
      "hash": "sha256-yHk42iN8iUJ3tpWosW3h3NlciaIxws14P/UUuG8c7HM=",
      "url": "_framework/System.Private.Xml.8oy1koutyp.wasm"
    },
    {
      "hash": "sha256-8J94aUtantC/dC9hmzCTdd1CfPnltJypllYsN2OefO0=",
      "url": "_framework/System.Private.Xml.Linq.8uluy190cr.wasm"
    },
    {
      "hash": "sha256-RfDrWhdjtiAsDYFD5Br5Nu7jYO39P9ntzEDx13xHdoc=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.9fut57h00v.wasm"
    },
    {
      "hash": "sha256-llDXIDOP9fLl6LuVifvRfIhx3i4pRMBFkVR+Zypc/n0=",
      "url": "_framework/System.Reflection.Emit.ubotr9l6a5.wasm"
    },
    {
      "hash": "sha256-0ua9xDg10WJe7J9dC/uMzSCQ7WLJUQB8MjBWTT45jrU=",
      "url": "_framework/System.Reflection.Metadata.uhpb9qkca6.wasm"
    },
    {
      "hash": "sha256-2dV9S55cS+mv2Kd99hDd8lzWYmydkerhSvxZ2ZyRnjA=",
      "url": "_framework/System.Reflection.Primitives.rz67b88q3o.wasm"
    },
    {
      "hash": "sha256-GDrwjX61hECIM4UueXavVLdbkZMsyYxXAAce8mMLzjI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ow9vaesa47.wasm"
    },
    {
      "hash": "sha256-rL7X9HPs0DTRCQu2QmR4CgJ22bXL9kHUwD6tCZRTx74=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.gdnwb6cawd.wasm"
    },
    {
      "hash": "sha256-jfWnfr9dXvWUcxGg+/1hJ6C5q/ubFnY9A/HCTGw9TFM=",
      "url": "_framework/System.Runtime.InteropServices.r21g14zx38.wasm"
    },
    {
      "hash": "sha256-5gRzfc48mdpw7L9tqNpRCPZJGI+pTatIGYuIbVkZDPM=",
      "url": "_framework/System.Runtime.Serialization.Formatters.qzifjhyomw.wasm"
    },
    {
      "hash": "sha256-LiVbZjNw/NHKB1W/GAoXzAbRw+6LSbE7ppg4QqvrZ28=",
      "url": "_framework/System.Runtime.Serialization.Primitives.6z2vagv1ri.wasm"
    },
    {
      "hash": "sha256-/bFNewVHY2P/WBo89MVUPJOKm14yPFYZn7YqSoXD4bA=",
      "url": "_framework/System.Runtime.racz93dfll.wasm"
    },
    {
      "hash": "sha256-qVCDBZ6jOp/ssKhGDQmMDPE1z4wwSWdJ+shtJbGHWG0=",
      "url": "_framework/System.Text.Encoding.Extensions.f2wkw8djam.wasm"
    },
    {
      "hash": "sha256-W/fElxcslT1FEpmR4J9FKSB4MWZ1Y+iLDZstFPVpMso=",
      "url": "_framework/System.Text.Encodings.Web.zybfxjy0el.wasm"
    },
    {
      "hash": "sha256-cZGghgODlOPa+q2+lrOvW1fo/ccxKnfnmuS5FfdGjAI=",
      "url": "_framework/System.Text.Json.fwoaai0o6j.wasm"
    },
    {
      "hash": "sha256-blL7Dh7pAuUL5VXhhmvN9TlC2sKxDgDO3quqOm9oQWY=",
      "url": "_framework/System.Text.RegularExpressions.egiwh312pr.wasm"
    },
    {
      "hash": "sha256-5Vo2JyY9A38aje2w/OTBfqTdOVcVgagrI/w3kjq+3N8=",
      "url": "_framework/System.Threading.1p2l26g58d.wasm"
    },
    {
      "hash": "sha256-nNK2P0ZgxALZnHOAIqK/T14+l1vWUHHsqFCdiYEG/+Q=",
      "url": "_framework/System.Threading.Tasks.Parallel.ondldmr8un.wasm"
    },
    {
      "hash": "sha256-WwW3Z+U1e06mpW1bCBgkkQTIoZSYgR5L/Yg/zOrtS0A=",
      "url": "_framework/System.Threading.Thread.5wau8og4hb.wasm"
    },
    {
      "hash": "sha256-SgQ/zXmD8BOYD8kNihgN95V1KbAD6zMyH3Kdc2JBRo8=",
      "url": "_framework/System.Web.HttpUtility.uaj061biqj.wasm"
    },
    {
      "hash": "sha256-JuEj9dfBl39fqnbzXBS6GXngjNI7jj2ZEY6HaVcdW4U=",
      "url": "_framework/System.Xml.Linq.mglmvb8jto.wasm"
    },
    {
      "hash": "sha256-nvq07P4lODkr2JtwVCDqeaCa1bggHj6AmkUt8jgsc5M=",
      "url": "_framework/System.Xml.ReaderWriter.e40oorkpsg.wasm"
    },
    {
      "hash": "sha256-dKjajIWcksJppXmPBe+W8UksP5QNCZPT7CcYz1AxBdE=",
      "url": "_framework/System.Xml.XDocument.k4hbxztivn.wasm"
    },
    {
      "hash": "sha256-jdi196RMQvJqOZVnwRK7DGSWJifChhgNljcOjGeHSUY=",
      "url": "_framework/System.t8xd33e5pv.wasm"
    },
    {
      "hash": "sha256-GqbYZLBITO3dqqsJ4DPwOeElXCpYNCbHhlrTpj+c2wY=",
      "url": "_framework/TextCopy.m05mv6487u.wasm"
    },
    {
      "hash": "sha256-ULsvyv7nl6doDq/7V6xScA4P8bEScbsCcPFBlPnaS7Y=",
      "url": "_framework/VisNetwork.Blazor.4fraq2v2tj.wasm"
    },
    {
      "hash": "sha256-tZPOYQMOOrLetxwmh9SGVojFLlRLMcl8v+gj+emVaNM=",
      "url": "_framework/Webassembly.b4324f5unn.wasm"
    },
    {
      "hash": "sha256-SN60bO2LO8sJYLoZbujl7YTPmwBVsU04IRcloMCinEA=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wYjSscllRgsaXH0VUEf8zSZw/5lACwcJOUm+1THG5bk=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-j2x8diiDVUiHl6rufF2X9Vyih9vGFXC6JrbN4Vvaj3c=",
      "url": "_framework/dotnet.native.53woboh2wj.js"
    },
    {
      "hash": "sha256-z5AzDK0U+OUQsWsR/63smZV/duV7xVFVab8PtfNcryI=",
      "url": "_framework/dotnet.native.bp409g1ybl.wasm"
    },
    {
      "hash": "sha256-Isv/63htfX73xgn3/2cZMtk4S8xBcbmlXRgJMDv4mhI=",
      "url": "_framework/dotnet.runtime.ew19f13umk.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-0z/IGfhtSlE+7b1v0lA/Ly+Y8CUWaO66cQqLuflS8gk=",
      "url": "_framework/netstandard.bupwt6y37a.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
