self.assetsManifest = {
  "version": "tAt9JlLj",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-SrX+Bbcizh75L5tLmcr+J401S8ACtG/nRW8oj+Cjsg0=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-9e3QekpvXYp3fmUFoC926+SMc4M9QW1eltssRQLozPI=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-9t6EXWYnl/QKcjuT8/+OKfHA1pouuLwhKIYsHnsB1tA=",
      "url": "_content/Radzen.Blazor/css/components/_qrcode.scss"
    },
    {
      "hash": "sha256-SvvtNL+BRURq2uJ++cXIJEna8yZAQT+qry35we3777Y=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-oUqzDxYNe80U+p/qGo910JR5uFQIteOxLz1nRjlOAi0=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-5WmR8oii22XFtpq3PuwbC4fTo5IG4MT6IUq813sk+r4=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-RhD36F+3rClzlZdow4nlNc5DPKosHbMIkpV+eFXQOa4=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-lYiMLG73UrqjeD3Xr0zwkygnPDSAQXeAo1554Yjqjkc=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-hY8tseTOVuafuUx/Yae8W0/t2n5KkZQakQGah/rRxuY=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-8lJvu9RQDeTls27Xrf6LDyYEfyCDgCwI80RVKuT0OuM=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-e12TQpbc/kfMvZRBfGZH5JTW9GLAyeGEQinw3fL+eBw=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-+PA/TMpN+uUgTwqwLmA/nfoyXy9AzOtxFRb9Ejy0j6k=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-geclpTFDSVXRc6tb3JDx/ax3wPXY2ROLX/mdqfG0ZPI=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-J8kJYxpBFMrMjHMBSdDlq1lYqyntxOrDZ8AW5FrxH8U=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-GDqtExCjRSgbruzH359ZU4KL8iLpzr6QlE/hsH4Gjq0=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-UgeZSBJHYLOjTnzICVNcHOGaRNahUcZl2tW+CuTzPtM=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-FGCHh2TSBmNYR3/Z488SXVUGuCJ4PUZq2xafQw2O6Eg=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-mscmBJFsTrAe0H/SoknylPnukiQX2yfQ/zSnbR4B75k=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-0n4dAwnieEzTsFfVE/aG4ePZ81Tip1GGLRrJ0qm+7gE=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-y6x9nQqkv3mW+Dvmm6Pvh+h0ixHfY0RLzrX6ZlktoG4=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-IUNVz0UXO3XLmt5YgnL6L1fWZDN6rn9C8XbV286VedE=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-fzXK/2BQ8C/lABKJC6dsV+cXmFHprEg2ICoPIqt6r2E=",
      "url": "_content/Radzen.Blazor/css/math.css"
    },
    {
      "hash": "sha256-91YY/0V/CP+4/OR+RZ9i1mEc6+FcVPq5dpFh/xShlCU=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-zPLEsQxC4XDKsGkgNfONvCLjZVlutYm9gAxjBTTtX90=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-mHh6OGo9cpMZlZptx+gUmbVAY28oSpRtDR7lsb98WKk=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-2SAYjkTlDi0QENIXcZO8Ix5WG2p8ovYOAtcflpDteMA=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-tRcVAq9DGc0nyvTuxUpiBTY8PaxnC6deHLSE8Ri1PMg=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-kXBCAd9VCBjb/gIz354sfOaBNxe0LCEpbtW18h/xoPw=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-TtAVW9vOR1JVzSTvk9zs+zK11Fgy/35Nov98QV6rJvE=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-3r3V5Xt5Algg5bbJa8TAS39NakE8l/YTAeDrQq081jA=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-HYNTnwNf3xj899KPdiKwmD1e5t3XRg9VaQgB1ZOvKeI=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-1kbd42/7FpoXf+Z/HfjXiqPtNSsSQNhbn3Y+uOb3of4=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GFU2mt0A9T8j9YMwMQqIUmdziKNDuPppDCn2o37LV2E=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-6b1uXJFpDxW5gb8t/msm970yWztT2F4IGVPo0P6wlNM=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-YQqC+x+db2pnQw/gibR4ai58y8WWbVsaiM7Dg/5ZjmQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-YEIKzZHjTFrB0PdPq+MUTCQVa9BXJOk4GoWEv21FNno=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-eM8DTi6b6DvS8NIedSLSGsOM4Y0OGeQUae6fmc0F5HQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.map"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-cGOjPiVWWygaE8CFdoLZjcTpjW5SWN2gHBsKDExWBhs=",
      "url": "_framework/Fluxor.Blazor.Web.wcy6s9h87i.wasm"
    },
    {
      "hash": "sha256-9RYxaPKks/KG4cxWvALGkiJYw0HIkUce0so1m308KCk=",
      "url": "_framework/Fluxor.fj93ytimo8.wasm"
    },
    {
      "hash": "sha256-GwramdNValxXDHNdbCSc9Id2zb+FuK8rMJENH86L4BE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bkcm5vycx9.wasm"
    },
    {
      "hash": "sha256-cS1Y7Djgkfxlm9pPofjTfiBFj5PnLRnC1LF/Pmq2YPA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.9i66vy8k65.wasm"
    },
    {
      "hash": "sha256-uDQrYVeJdViMBWmltMJ8X4xqDAQXVVvIe8vLkBA6uL8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.srea20u5vs.wasm"
    },
    {
      "hash": "sha256-eEywwkTYVHdblTbVl2hGs4y7aYBoX6IurOFK0x16WKI=",
      "url": "_framework/Microsoft.AspNetCore.Components.gacpy49z6b.wasm"
    },
    {
      "hash": "sha256-6ZO8a62CdfigbEHCc4w55X+bQF692ehzKXGLgNY5uFM=",
      "url": "_framework/Microsoft.CSharp.jdr2dqyi3n.wasm"
    },
    {
      "hash": "sha256-pOED2iNDgbaIZdNUqih81BZOhvMp17gA7UYEE6dbly8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.opwbk83jqu.wasm"
    },
    {
      "hash": "sha256-aUL1p8N7BVpff4zCDZ0GloDhldubhgfQ+pTN+yP+NL4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.hui4iqxkm7.wasm"
    },
    {
      "hash": "sha256-aGCPTRRX+LpoEC0kHuWtr4WOAl74G2p0HGSMadHDYYo=",
      "url": "_framework/Microsoft.Extensions.Configuration.oovwwqf5qf.wasm"
    },
    {
      "hash": "sha256-Ag5ue5FhflZzkSagARpo7K3hUNpKi+3r+7uEVqTm/QI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.2gccglgj8h.wasm"
    },
    {
      "hash": "sha256-szm/4Fl/8ThZEyTKn0DjT10dLkwAN75iOLpPaT9MziE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.zg5wmkbway.wasm"
    },
    {
      "hash": "sha256-7X7PJJKHxEdgZ6cv+FBqggxsi4RAQCqu7p8M/xtI434=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tw1xngcqhu.wasm"
    },
    {
      "hash": "sha256-9pgOS8ezhH7cPoYYDzmudhB+iMPHY/CSqQhb77PHTTk=",
      "url": "_framework/Microsoft.Extensions.Logging.eva8yn2t8j.wasm"
    },
    {
      "hash": "sha256-OEvCP6Hpp2dMDGkoADEvJXNipXV0xRm3bOb7YoaPnPQ=",
      "url": "_framework/Microsoft.Extensions.Options.o4x2viz0vi.wasm"
    },
    {
      "hash": "sha256-4E9QgG80eMrFZtU2cQ3IdWiSy9K4odn43sch89M9Y9Y=",
      "url": "_framework/Microsoft.Extensions.Primitives.wgkaqcaqxl.wasm"
    },
    {
      "hash": "sha256-8OhBBOlF1LEum9DxKASCSKaN4s/gPCgQHp3iJz2kvKU=",
      "url": "_framework/Microsoft.JSInterop.0kqqspsajo.wasm"
    },
    {
      "hash": "sha256-1391UuW9RnaY9v+RXWFFkaN+3zIkFWK6F/i2rkesTxo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.dnug9e66zg.wasm"
    },
    {
      "hash": "sha256-l2qEfPM/BjYyiblhUW+zUgDUT7vciCSwbC6Vj2Klbeo=",
      "url": "_framework/MoreLinq.zdi2h46g68.wasm"
    },
    {
      "hash": "sha256-hV2fD4VybGRHDj6zzWJhjkJfNfl792Y9ZNX65yWPDGI=",
      "url": "_framework/Radzen.Blazor.hduvmniwdv.wasm"
    },
    {
      "hash": "sha256-GRNVzvSLBqHCJdoYH2rK3UM11pmuGyq1FmUFsWXty4Q=",
      "url": "_framework/Siteswap.Details.bj7bayapuk.wasm"
    },
    {
      "hash": "sha256-/YTXWfafnYvjpjGF1IMq7Nysz6NmE0fx46QJssNKfgU=",
      "url": "_framework/Siteswaps.Components.v18pe239do.wasm"
    },
    {
      "hash": "sha256-+wfvQ388sqzJFQBWMZ6A02P1XJaWW5jtjSbtYr++2rY=",
      "url": "_framework/Siteswaps.Generator.15pb8jr38u.wasm"
    },
    {
      "hash": "sha256-zIHcmfJgdhlWOu4/1RCLl08fYUJwqRNlZQ6F/Ks+wFU=",
      "url": "_framework/System.Collections.Concurrent.4q2oi7hu8c.wasm"
    },
    {
      "hash": "sha256-yprHP+ncYkZsZ3yHlw6YU0G/+SIvJYGyzG9tDrPaVHs=",
      "url": "_framework/System.Collections.Immutable.ufp49mk5na.wasm"
    },
    {
      "hash": "sha256-PZgthRPwqQL1YUZ+mWd9xBMgsG294hsDHSYrP0IyhoU=",
      "url": "_framework/System.Collections.NonGeneric.fdy3veaabs.wasm"
    },
    {
      "hash": "sha256-l7CExbyRQyEi6YXxYeZw1IX9N6OCAz7F+AgQyBjM8W4=",
      "url": "_framework/System.Collections.Specialized.v6efndz30u.wasm"
    },
    {
      "hash": "sha256-J0StpeoIRDMIdITilsYyZtfpUTKCLVkUYMfvDxy/fXw=",
      "url": "_framework/System.Collections.jh7lf7gxoh.wasm"
    },
    {
      "hash": "sha256-3n+PNdv52r6VO3yMqnwu7RODWnN5jfHUjQEtBGALcNU=",
      "url": "_framework/System.ComponentModel.Annotations.up416vtpn7.wasm"
    },
    {
      "hash": "sha256-iDEXM2UHqK0MytaDW4XAlQtnkanYFye5C4OG581TUu4=",
      "url": "_framework/System.ComponentModel.Primitives.oc4uk7npw6.wasm"
    },
    {
      "hash": "sha256-zLcuSVuYA/H/mtirUcjoucmutfJoYpz46gqw31slPbo=",
      "url": "_framework/System.ComponentModel.TypeConverter.ghcg1lpknc.wasm"
    },
    {
      "hash": "sha256-X3UhzHQ8oPw+1gIAtrUd6W8sed1kmYYoxOaMl2S3kZw=",
      "url": "_framework/System.ComponentModel.jzuedxd7v1.wasm"
    },
    {
      "hash": "sha256-dzm9ZWkiQ3mkj1Yn6fZmLU2TBcRomjGT005AyCOTQ5A=",
      "url": "_framework/System.Console.dbf051vv3y.wasm"
    },
    {
      "hash": "sha256-2dJumCDFt1mrdoA8nOGgWxtlAnPSbnYuA3oE9/6QwGU=",
      "url": "_framework/System.Core.zhyqkiijww.wasm"
    },
    {
      "hash": "sha256-foLcpU5GbXv+6yOYSvqCKHo3cxHUe0XMVgWcweAwjLU=",
      "url": "_framework/System.Data.Common.mbqxiq45q7.wasm"
    },
    {
      "hash": "sha256-20MnV/nj/3JiyysUpagXdQ2XWsHPvhmacVcYcP0PUg0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.n1y6icprwn.wasm"
    },
    {
      "hash": "sha256-nt78jec4GXB7MECLO4CnuUKETwn4cH1HjGcxjyijuXI=",
      "url": "_framework/System.Diagnostics.TraceSource.ukjif354b8.wasm"
    },
    {
      "hash": "sha256-E36ToiRNdAtxHxLuZxuj7ikjqLP++w690Sxr+ApNlto=",
      "url": "_framework/System.Drawing.Primitives.rapc7rod5s.wasm"
    },
    {
      "hash": "sha256-hMxejrj/Rhnj20rSRV7eyTCEvWgRRLQjjBr0ElDyCfY=",
      "url": "_framework/System.Drawing.cgjsay5uc4.wasm"
    },
    {
      "hash": "sha256-f/yygliqxDUVbK9P7/AvFVUPipAv34X76QkaPC61T6I=",
      "url": "_framework/System.IO.MemoryMappedFiles.rlfuqyvxkv.wasm"
    },
    {
      "hash": "sha256-F7eq3vfkNdyf7BI0RJMCuDGtdhNgu4qn1GGWK5FvVz0=",
      "url": "_framework/System.IO.Pipelines.hqvxmp1tnr.wasm"
    },
    {
      "hash": "sha256-ZBX4y7qqNxAG2D1pxGD0kUN3ABBDQEQP0PY+XFZ7Y1Q=",
      "url": "_framework/System.Linq.Async.ovfc2irvky.wasm"
    },
    {
      "hash": "sha256-R793lrSCpb82V1bBP90dTuKAOYEHfivWJ38M2/Bq4Gw=",
      "url": "_framework/System.Linq.Dynamic.Core.3l9j0qit94.wasm"
    },
    {
      "hash": "sha256-O/QaT4+NH7aP/OcGzTj2xzdLeZ3W3pxyPdR1J5EMRkg=",
      "url": "_framework/System.Linq.Expressions.l4ikf948cn.wasm"
    },
    {
      "hash": "sha256-1XCo1oRAsPE0iNPrdpobUxg1wa1CkFfvR1rpVza74MI=",
      "url": "_framework/System.Linq.Queryable.dyst5lyqdl.wasm"
    },
    {
      "hash": "sha256-tbnfBBs6l89SCKGLii6HZfky9F3FMWuQqIWDeJ8Xv+c=",
      "url": "_framework/System.Linq.h5jjyki2m9.wasm"
    },
    {
      "hash": "sha256-1aQtWAsFOnyv0iSp8sXIozV5TRVWg7q+Y2v5463QOak=",
      "url": "_framework/System.Memory.3q0uc4e4j8.wasm"
    },
    {
      "hash": "sha256-n9Wha9xInRM5+YTiiWVS3sVwztl2xXUsae2KbGfWK/g=",
      "url": "_framework/System.Net.Http.v8uyokm37s.wasm"
    },
    {
      "hash": "sha256-/FmecRu5Wfb7p4wjY3KDbGzMWRfNbwsnnAnzdbPF9b8=",
      "url": "_framework/System.Net.Primitives.gd20ym2wiq.wasm"
    },
    {
      "hash": "sha256-IRbBfRBVSUAe6j/GIBlmcfULQo2C++eWzgTXaN0y6hs=",
      "url": "_framework/System.ObjectModel.5f0c984ulo.wasm"
    },
    {
      "hash": "sha256-YfXux45+OAQBOjLH7jRn8MFH7yjl3aj62vYj31HQvY8=",
      "url": "_framework/System.Private.CoreLib.pys7vacvmk.wasm"
    },
    {
      "hash": "sha256-W19F378AXwzj+p9/zq2JImRoi3gzxXfG4v5yS9eZjWI=",
      "url": "_framework/System.Private.Uri.9na7zz0kfh.wasm"
    },
    {
      "hash": "sha256-PyhX+5YEJbYj/SkW3s1N7kwOyOyM0GoUZXmiasR2Bls=",
      "url": "_framework/System.Private.Xml.Linq.3rva94be1g.wasm"
    },
    {
      "hash": "sha256-F8qYJ6AFCwuFhIHsP1vF4G46YI/UetFavq74W7pmf50=",
      "url": "_framework/System.Private.Xml.x67moksrda.wasm"
    },
    {
      "hash": "sha256-eaSXM3blUnxvZl782W4MjWVc6LY4EzuVRKp4DvB5syk=",
      "url": "_framework/System.Reflection.Emit.59biff5lwh.wasm"
    },
    {
      "hash": "sha256-KYi+PGSfVWxFPkPLfr0oyfdnXIwSbXNMr8tbWTUUBCg=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.xehgkats40.wasm"
    },
    {
      "hash": "sha256-/eleRJPcRz951h7aI0bx0X3sCVYQt02EOCDZ1TUmUUI=",
      "url": "_framework/System.Reflection.Metadata.p5ry03whmb.wasm"
    },
    {
      "hash": "sha256-DsbZXTIkkpkVbx9luOz3EgU80fgg7jpxlhMIMr4HFAE=",
      "url": "_framework/System.Reflection.Primitives.mqh5dcggcu.wasm"
    },
    {
      "hash": "sha256-8v7jVijrzRlaTmvdds4+ZNyPL5DYfnYnzFYT2HtkqwM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.u9tzo6t7zm.wasm"
    },
    {
      "hash": "sha256-xbaenb4iwzQANJLwYU9qoLTSv6HDsQDdrqIQaqq42pw=",
      "url": "_framework/System.Runtime.InteropServices.pry7fjve8v.wasm"
    },
    {
      "hash": "sha256-4av7FPnozHHSXZ/NOWa+QVjZq9gokeCpvTOk1T5i96c=",
      "url": "_framework/System.Runtime.Serialization.Primitives.3zvl3n6b03.wasm"
    },
    {
      "hash": "sha256-VWTx6BTUWXxoSp6BpEMT3/z3R1cx50KJOWEcJJgtQFo=",
      "url": "_framework/System.Runtime.p31vp521xa.wasm"
    },
    {
      "hash": "sha256-hjVglgrlvpOc40vd2IsrMcsbJ+1Na/f1HhFFk9mtdUI=",
      "url": "_framework/System.Text.Encodings.Web.iezhd0tk44.wasm"
    },
    {
      "hash": "sha256-95YDPw3czptUOKPD/+t8yIX3e/ngnakHlhltmh8EW6Y=",
      "url": "_framework/System.Text.Json.v68qjeg0gh.wasm"
    },
    {
      "hash": "sha256-amlcBtYeYSd+Xf6hIG+ue6QfQPvixB94OEgdM2cagx0=",
      "url": "_framework/System.Text.RegularExpressions.2mt278izk7.wasm"
    },
    {
      "hash": "sha256-ZMJDC/9WimDvdu9HMEVL9fIZeVqAm4I9yayeMhMQV+0=",
      "url": "_framework/System.Threading.c8vusyibby.wasm"
    },
    {
      "hash": "sha256-0vRJc1ChCUo/RxctXpck4xrhb3wtxNX0yg1qdXxQFSE=",
      "url": "_framework/System.Web.HttpUtility.i4jctz2t2q.wasm"
    },
    {
      "hash": "sha256-UgDQgumqZj6p9gp1AxxwuF7FY0ittV25c4qrMW9q7XY=",
      "url": "_framework/System.Xml.Linq.62mgoxb9g2.wasm"
    },
    {
      "hash": "sha256-+3SlDJYDdc4lXEjSJad37pAH0sKgpRPXp4ECI08vsYI=",
      "url": "_framework/System.Xml.XDocument.vv4pg4jvzd.wasm"
    },
    {
      "hash": "sha256-fVP2BxRRKpBA0PmBbKxmO45bXDrAXVn1GthlDclLbeU=",
      "url": "_framework/System.t4d4s3f398.wasm"
    },
    {
      "hash": "sha256-ULsvyv7nl6doDq/7V6xScA4P8bEScbsCcPFBlPnaS7Y=",
      "url": "_framework/VisNetwork.Blazor.4fraq2v2tj.wasm"
    },
    {
      "hash": "sha256-yGDCuJycF1JQ1hBuZeqVpHpK59D7+DRLRbuL9pDHIik=",
      "url": "_framework/Webassembly.sr2byznld3.wasm"
    },
    {
      "hash": "sha256-isSk5X+eG3EVmqMr2Vvyr6nhV8pDZjfxekEu9BTn0A0=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-T1vT02oTgL1ZyvL5isJPjfUyEmsUizbUY23kldI8wZ4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-p9eEzXhQIsI0a5bBJhfzW15iRafgplTxT8XrO5FiH9o=",
      "url": "_framework/dotnet.native.noby4tlk4d.js"
    },
    {
      "hash": "sha256-Po2dalLvTpf5jAS+jt0TzuBYybYiL1F6qAacZJ8UAdo=",
      "url": "_framework/dotnet.native.qe75a9vfqn.wasm"
    },
    {
      "hash": "sha256-6QIZYgG+ftoT9N1H1EEJeXIhD/qbKqEcnmawDskiwdI=",
      "url": "_framework/dotnet.runtime.9o45ky8ejm.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-QgbESJCowzYw2aHU3CejgLKmnTajTogxoURFejra/l0=",
      "url": "_framework/netstandard.ai3qaawj21.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
