self.assetsManifest = {
  "version": "tQeMQ1vS",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-GqSSBCR5UcW0r0NY/YaS6MxPWFm0FmUO6R4WkS1eyFA=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-gZtzsjxzp60kqP2eKc3kYGKPXmb1j5y+DFIW181SWF4=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-sfc5mwVngvRl9e9QcjgftwwJWpsG42eF+5rsDBsKLnE=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-0sNWXG/51CPPMfO9Ct5cLdL8ueayhndflRDHSVouMp4=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-IWixdDNB9na7Szmo3I8IxY31M298jZOVzwZzlVzEjs0=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-6o3ORF1/ctQtmJpUgbEU1RoqqWXNokwP58LBD3W1OZQ=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-e7Qmt2bSaa2jHyuVu1+bJIrqWjS3a/bk8VNmcdeHk/4=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-mhTnyd+H1ZohVK2QqlcpN70DJSyjJgYlrzNyJETysc4=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-Bp3wqAqXBcfaHq2/jYwThtiG9udMXDYUrtWZ2Ofwlw4=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-/8i7WfZJ1rh2X9gIYnQS9pfzc9KZ8x4rsBGrT0zBvoI=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-VpAmnjRI3e3zYrgHiOIULuUxO6NJsy6vNRo8sB3Glck=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-Z+A3lj82DBbaC5fTpEennqLyb1DAacJtpcOhBsXHQ+s=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-mDEAgT/OKKF+xmbM7EW5p1gMrVAhM9LTFzPxmjVv60A=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-8ev23ZMMvHLWmVgFG1iNfGb3aviwW2Cr+DKu8lMXRxI=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-4vO80Q3VqokK6uJXz33k+gdroKVL3mg50E8iBXt9bnc=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-aqUddjHyzr9Fksa/LgI0ss1LtOdorKh+o0/7WqtHPhA=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-VaG8URZl5aIIYDyTB0lpDVngAbD6jiDFkauMgCq5xWg=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-hOwAUrokRWklo/acj0x3wEUaL5oz92MZwOr8n9nSn1I=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-2x5dXfnBz5zk+2jHtBOsEagtRI8ULQBk18J1BV0cwhU=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-R92ZfnnSQm8XywhUN41O7j0dEhH3Jq1+hZfsy5qqv+4=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-IZai8vIIT5FLVY2+77xe//pkqz/ZPjnlWAdfaff2msM=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-LSvEWDI2uUHkOkyHwDI6svNCYUa9vVHqfD/AWsRn6pk=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-f0uhXaNzSHCguW7IErTRjeiGQXPWEWl5p/eehMZkDdc=",
      "url": "_framework/Fluxor.9yjucuf12h.wasm"
    },
    {
      "hash": "sha256-DBC32gXCmb31ELcLWyN0VaYPespDZiNUhIL276D1X7Q=",
      "url": "_framework/Fluxor.Blazor.Web.4opwue5a6j.wasm"
    },
    {
      "hash": "sha256-o3yzkRskTjbdG3vrW+9EUEUnM5QvYSYgMLifbFx2K5s=",
      "url": "_framework/Microsoft.AspNetCore.Components.9xzixbz40d.wasm"
    },
    {
      "hash": "sha256-fN8aI1rwBBPSuJecA/m/RSBx9iYZRP2clb10FiQf1Iw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.kol304s5z2.wasm"
    },
    {
      "hash": "sha256-6El32tJoVmXG3CNUKHf8UHEAR7+IjSwC+ahW68iL1zg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.4le168hfvd.wasm"
    },
    {
      "hash": "sha256-J1Iw08TKthQGPCkWVWMls+Jwwg1gPgW6DyEMWaF1qxg=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nw5pcnmvxk.wasm"
    },
    {
      "hash": "sha256-8VWkF6ZWgTUscl5mQHrfSyuRl0XsPT3S0ztDz6kGCTw=",
      "url": "_framework/Microsoft.CSharp.dlfs0yp3nn.wasm"
    },
    {
      "hash": "sha256-6hXf1+0jOnIyn7nbcH6G9w70XHmpwHElQX2X7RI69VM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.2i2do85xgq.wasm"
    },
    {
      "hash": "sha256-d4x5KTkCLjfmeJYVNdU4tb3cS498XA5JxV6+PY05vhQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.xyejtlvkam.wasm"
    },
    {
      "hash": "sha256-jyjHQ9vrCGMfRhleUAaTJ2kZPzvV5QHufx3S9pZUSnk=",
      "url": "_framework/Microsoft.Extensions.Configuration.rht54gw9ww.wasm"
    },
    {
      "hash": "sha256-GhXmlZ0NaNgERZeOJvEDaFmmJYtsekuYDoqqEu4dkps=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.2m0gaxgl7m.wasm"
    },
    {
      "hash": "sha256-QsgwhDhrJEF/ZAe3g8gpfwuVUijeOiGVsPieEqZ8JnQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ioptpieykc.wasm"
    },
    {
      "hash": "sha256-5esdrs95o+Ws2LZoDwu/0HNcLarH7DIRxFHcKQ88Dak=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ndz4ow3f0w.wasm"
    },
    {
      "hash": "sha256-kNdE19KESLzGafHOVrpJwVwVsId70Sdi4LBHHToUVpw=",
      "url": "_framework/Microsoft.Extensions.Logging.kr59nrij6t.wasm"
    },
    {
      "hash": "sha256-j+0LL2qw8NRnft2uYZ8r1WKR5/+1JPWMr68qUKKQWz4=",
      "url": "_framework/Microsoft.Extensions.Options.rlk5anr5pv.wasm"
    },
    {
      "hash": "sha256-2hCO4H8mexhSknMrGLLyeFBenBB6+EyaF/GABYiSFwI=",
      "url": "_framework/Microsoft.Extensions.Primitives.yybdz8bjuf.wasm"
    },
    {
      "hash": "sha256-yag7tVo8E56T9ylg1QgwgZv8UPsi+2H3Ipp9ZSkm/uE=",
      "url": "_framework/Microsoft.Extensions.Validation.7s8js2cwj1.wasm"
    },
    {
      "hash": "sha256-cwR8EG01BGjctiJNl8rDA8n/Y+lCWTgaPq95qS4DElk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.h3txawygj0.wasm"
    },
    {
      "hash": "sha256-ntLCuckUAKMGmqoCCzBddXNeQ8SfeHsxgv4G/cq3BRY=",
      "url": "_framework/Microsoft.JSInterop.uoqah70s6u.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-dJ7BJ224yJra03jbRbwNlzVft9SYZZBd8fyEAWVqR0c=",
      "url": "_framework/Radzen.Blazor.gjlikobek8.wasm"
    },
    {
      "hash": "sha256-TxT7AmHc03lier94UXkXgOmHCPbIJxq8eiHokz8fxjQ=",
      "url": "_framework/Siteswap.Details.7etusy4qf8.wasm"
    },
    {
      "hash": "sha256-8A39QDmY6Tsxgg3iTIbw22BGIk6vZHlwrSWGrH1x2vI=",
      "url": "_framework/Siteswaps.Components.slu4qom2sv.wasm"
    },
    {
      "hash": "sha256-33wjVVTw6gd36W/e8Vn5iw5clDBSZPvfHyU76qhPF5s=",
      "url": "_framework/Siteswaps.Generator.Core.btck3fwe3f.wasm"
    },
    {
      "hash": "sha256-3o4XIjeLo4HCOGKUKICLVDMmpilV3aa4mzpHVFcAkqI=",
      "url": "_framework/Siteswaps.Generator.yo69nckiz5.wasm"
    },
    {
      "hash": "sha256-QtNQDl1G146IubTNbgjYbQoRbKzZLw21++nXIVBupWI=",
      "url": "_framework/System.6ata22n2ok.wasm"
    },
    {
      "hash": "sha256-RfcmEZWkb00wpNR1ZzsyATSymqcGRAGXvApoYiOkpw4=",
      "url": "_framework/System.Collections.5cl1duzhwu.wasm"
    },
    {
      "hash": "sha256-uXJ6eD8d2X0POItA4CtK/scKNf9umL+HHmcq1MHkzWM=",
      "url": "_framework/System.Collections.Concurrent.lhkkinskn4.wasm"
    },
    {
      "hash": "sha256-IzXnOaJOYWg48cSldVxsSXbSlQKWqokd97XGelZm6KM=",
      "url": "_framework/System.Collections.Immutable.f9h7ikg340.wasm"
    },
    {
      "hash": "sha256-5VAqFP9cKs176Ddjt2rV+hl6GRhtqmMyO1rzfdCZ91M=",
      "url": "_framework/System.Collections.NonGeneric.tywszinv1g.wasm"
    },
    {
      "hash": "sha256-kfQ6B4CklEacLw8I9g22XX6LvpnFNs7povHW5037RHQ=",
      "url": "_framework/System.Collections.Specialized.3riiwj98cx.wasm"
    },
    {
      "hash": "sha256-7CcopD3uYQrrMKxrILmrDmDT448VAzJOJ3tuq/G5R9s=",
      "url": "_framework/System.ComponentModel.0dwhii4s3k.wasm"
    },
    {
      "hash": "sha256-1x+IHcWB8uDZplgMrOZFEBmQO80M616A+mcKKisiEt4=",
      "url": "_framework/System.ComponentModel.Annotations.llmv42988t.wasm"
    },
    {
      "hash": "sha256-61DcQ6dXxWR88tHUmKEcHonS16xrcBynmBzQJOnBj4c=",
      "url": "_framework/System.ComponentModel.Primitives.zqa2a5fx9d.wasm"
    },
    {
      "hash": "sha256-jP2capwBtI+W6JPkwJ9b/lUBUdIlB79HyvVzWLX2IHw=",
      "url": "_framework/System.ComponentModel.TypeConverter.o3rt444ai4.wasm"
    },
    {
      "hash": "sha256-zYAt5lNwRlKabVp1y4anSOcrNDt70gMBoGN8bD72//w=",
      "url": "_framework/System.Console.zwhmzy3m18.wasm"
    },
    {
      "hash": "sha256-xyq7qheMIVj5zgqvw8Ej+osCJ+jroUJUJ9XhnFZ+xoc=",
      "url": "_framework/System.Core.dravlmwxis.wasm"
    },
    {
      "hash": "sha256-vidFoDXaGcdROZEOYDFDaMUwjqG60u1+qob7gtU/JRk=",
      "url": "_framework/System.Data.Common.2jpqwdbk1k.wasm"
    },
    {
      "hash": "sha256-MrqvkOiKTQ10RHE85PjvVkY80H73TmcCvIF3AdNNlM4=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ud4kfyjwtd.wasm"
    },
    {
      "hash": "sha256-PYpSbJy9Wb/OzgyhW8yNXIsGg+5bthPruwN1rB1Zr2o=",
      "url": "_framework/System.Diagnostics.TraceSource.zcfoqif5p8.wasm"
    },
    {
      "hash": "sha256-OoAFmqjnLxPK5+NFh4YMySljgPkHiwc7TxpcqIFTKH4=",
      "url": "_framework/System.Drawing.Primitives.6oeqre8h4w.wasm"
    },
    {
      "hash": "sha256-MKYTWSFzvxRXUf6Rdwwo3U9PMfUorUqLaNcD0QXyedU=",
      "url": "_framework/System.Drawing.oqn0att29t.wasm"
    },
    {
      "hash": "sha256-lIpTQujYOEfAK10Yd9BUpCpP8sQsiqnvgCX/5MSh85I=",
      "url": "_framework/System.IO.MemoryMappedFiles.k2xklrtp79.wasm"
    },
    {
      "hash": "sha256-wCAJsY8WvZZLTXO26iAFWH6+l6Wy5eDKp2HiRTjdnXA=",
      "url": "_framework/System.IO.Pipelines.8apfz8l6e2.wasm"
    },
    {
      "hash": "sha256-a8sIspKRsVcSOPusqEHzyr7IyaBGIEjgcq910v01os4=",
      "url": "_framework/System.Interactive.Async.juae56i6ub.wasm"
    },
    {
      "hash": "sha256-1N+duzbqmJF+gpcaxUR+zJfbVI4e2+mNUu3a0DC4Ae0=",
      "url": "_framework/System.Linq.8zuk2l932m.wasm"
    },
    {
      "hash": "sha256-+H+PL4ozZ167jwAlf/toNTlEoM7C9aiP8MPZ0kyllGQ=",
      "url": "_framework/System.Linq.Async.0udklamc7c.wasm"
    },
    {
      "hash": "sha256-5dub/TFmb7yk16oyzozh7Nxnm6CLSGmke2BY7evxKv8=",
      "url": "_framework/System.Linq.AsyncEnumerable.jyseq8u9e2.wasm"
    },
    {
      "hash": "sha256-QB/t+uYL9UedVTW4zO/5HG8oL5paKwdKTZW68+tSTrA=",
      "url": "_framework/System.Linq.Dynamic.Core.4vazbp99me.wasm"
    },
    {
      "hash": "sha256-KhWSXPEXQI2/GEC1rBTVck3Uf7ohL1PKGEoJn5Nc2d4=",
      "url": "_framework/System.Linq.Expressions.i9oc1ldslh.wasm"
    },
    {
      "hash": "sha256-B1YLNzt0+dXP498z8+xADs03TuYxfr2k8liwMcoLKhY=",
      "url": "_framework/System.Linq.Queryable.xqravcliuy.wasm"
    },
    {
      "hash": "sha256-SMue4TEgx4diAlja/xlcqbHxUXB++vvha12ESD+pSkI=",
      "url": "_framework/System.Memory.s7nrdox296.wasm"
    },
    {
      "hash": "sha256-GyKPDxZWQAYJ05C20FTDVn4Cew9AdNQEzLI0G9bYYEo=",
      "url": "_framework/System.Net.Http.v3trq3l3mp.wasm"
    },
    {
      "hash": "sha256-jXCHYRCkNxYuJIThLTmMXLYAU0jmpXlj3geNtLYRVzA=",
      "url": "_framework/System.Net.Primitives.5el1uo96ps.wasm"
    },
    {
      "hash": "sha256-+eY4wmmzEu2vGvlgNgkGDaxVACimOwxzvzLVx/cU9d4=",
      "url": "_framework/System.ObjectModel.70kj5aqw37.wasm"
    },
    {
      "hash": "sha256-UeJC9WUSWPbirr1u9CMlG/E1lrBOvAhjo/zh85JVORo=",
      "url": "_framework/System.Private.CoreLib.3zgj9uidtl.wasm"
    },
    {
      "hash": "sha256-oDS2KTCbtdo7kXgWe+OD9A/V7D2FhCYAwEcMRxo48iU=",
      "url": "_framework/System.Private.Uri.g0d7rbrlqf.wasm"
    },
    {
      "hash": "sha256-RYvYkFbG3SZ5Car9MFY75uiE5qNKE4kGitIwHbyKXpA=",
      "url": "_framework/System.Private.Xml.Linq.tmlfg0qve5.wasm"
    },
    {
      "hash": "sha256-OyAkgXi72jCROYYxttpT66qbHtiiigjzgIeKAS1gqp0=",
      "url": "_framework/System.Private.Xml.h1xu13pnke.wasm"
    },
    {
      "hash": "sha256-KUHEiMwmJQ3DN/mVCycKn9m3DC3HDTSVfbK2Zdycymk=",
      "url": "_framework/System.Reflection.Emit.3t4q053b6p.wasm"
    },
    {
      "hash": "sha256-r/Vbzbkqf5D783bczq75FccrjunYrrLgTBh0zeVGD3o=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.9ux4e6q1k4.wasm"
    },
    {
      "hash": "sha256-b/fcWhP/vdEUKa5n8sNb8DHokGWv0cjDp4OFe12jG2Q=",
      "url": "_framework/System.Reflection.Metadata.vgdpvuj0bi.wasm"
    },
    {
      "hash": "sha256-2RqebgZoWjcJ4ncNeRQUGmFwT44moAsWL9SBlf6Yt0M=",
      "url": "_framework/System.Reflection.Primitives.pkjf2eh7rf.wasm"
    },
    {
      "hash": "sha256-Atkv6JEKDMOhZXO6GRTKu2vOTN6vIKT0UYGqzGapS8E=",
      "url": "_framework/System.Runtime.InteropServices.6qlw9m7rax.wasm"
    },
    {
      "hash": "sha256-Jr2L5GjxUYLiIlOE41CoRQKYHc4xB13loY9XH9Dmr7I=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.26w8i3zyp9.wasm"
    },
    {
      "hash": "sha256-yEwrc6Xh2qvEQMY1+EFeaIyv2HyB2AffKIMK519O+yY=",
      "url": "_framework/System.Runtime.Serialization.Primitives.80n342t68d.wasm"
    },
    {
      "hash": "sha256-DDJ5lJmn615OyE4geTUsFpduxz4pzs33+eYSTlKvzrk=",
      "url": "_framework/System.Runtime.wn3yzubg35.wasm"
    },
    {
      "hash": "sha256-j5zcQYBOuEDBHJgiX4Pngv/z0Tr2d1zjv2bqI2vmJaY=",
      "url": "_framework/System.Security.Cryptography.9u7v6xghh0.wasm"
    },
    {
      "hash": "sha256-fbNXmn/ud0Lc1+OMb3KA651j3Zk9nv9sU4LcL4d81Vw=",
      "url": "_framework/System.Text.Encodings.Web.f111t1v341.wasm"
    },
    {
      "hash": "sha256-siaH+MdTYzkdkD0WPj0mIn6THwpCBxpo05bigWQ93rk=",
      "url": "_framework/System.Text.Json.aergg65g2c.wasm"
    },
    {
      "hash": "sha256-ZLUvF6NOh40yyRa51Lin8QL94sBEu5728vk+MCxC5dM=",
      "url": "_framework/System.Text.RegularExpressions.cmsulppw1t.wasm"
    },
    {
      "hash": "sha256-dwt9aEQfFu83sY6w8TU+gyvjWppueA4uyc6jIUSkZ4Y=",
      "url": "_framework/System.Threading.f2244tx0ah.wasm"
    },
    {
      "hash": "sha256-NHNvagLuv3o7KReVJoFsUquhcyMpmzDNqBcDTYXZsj8=",
      "url": "_framework/System.Web.HttpUtility.cennlyq8l7.wasm"
    },
    {
      "hash": "sha256-zHSjsZ+N3XJB4tEgn77t39yrqKsvyqjd+MYIZvpYDmE=",
      "url": "_framework/System.Xml.Linq.g7kebn3ts5.wasm"
    },
    {
      "hash": "sha256-QNQELauZKykE7+9Ot+gHnuztzfeUzZ7+u/P3Mbrwisk=",
      "url": "_framework/System.Xml.XDocument.wos4age0sy.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-NRm9moAHDkFltZ1R1iQhdBMYmVxq7zdS3qMZp7i+Ml0=",
      "url": "_framework/Webassembly.d6diqf9ash.wasm"
    },
    {
      "hash": "sha256-1xlHuu1iNOJiMMz2BCq95uekwHf6pdpTcgVNKVBboPs=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-l6ZRIZBAiUQmcnL6s93NWmFDNvY+C3oeCCp58mNVgEA=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-aJwLUD2vv0raNJG99oAMaJywMttC38WeESpiYl+ZD18=",
      "url": "_framework/dotnet.native.88bzwcrr8m.js"
    },
    {
      "hash": "sha256-ycHUkx4eUYMIEM2L2sXR+cOqVORktQGJ23mvxHTF20o=",
      "url": "_framework/dotnet.native.djxc1j03l6.wasm"
    },
    {
      "hash": "sha256-j86bNQPKznxC4epcftZFbThfaMXvIRmSeHo8PdvTrdA=",
      "url": "_framework/dotnet.runtime.f4b1oiwlzh.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-709AA3+0Rb3EY4NbZijq5NNR+8CnkdEP+luKOqKgRG0=",
      "url": "_framework/netstandard.pmynd152j3.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
