self.assetsManifest = {
  "version": "iQMcTLCF",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-tJCgu5ELmzA2XHgcePj8LX3QXMHQGyglzlY/66Lr/N4=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-z+X+dG5UyqqngwfUpSBk7xnunjafy3H7xTyJvw3Wp6k=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.puij8nbrfn.bundle.scp.css"
    },
    {
      "hash": "sha256-83Y3VqGBsLcjg5Utw3RDNG+auv6zqH4/PPwavI4QwIA=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingPage.razor.js"
    },
    {
      "hash": "sha256-o25z5uysRrF+qMuOVpDgeBLWXM3QNnTM7HO4fyvughg=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingThrowChipRow.razor.js"
    },
    {
      "hash": "sha256-rWswo2OSS3ji2dvr19DmobleNULxHesPHT25kC7AG48=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/Controls/DualRangeSlider.razor.js"
    },
    {
      "hash": "sha256-lh2MEHR0WF9aZGtQjFkebCbG2xjz2nxN7sGOrJapDtg=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/WizardPage.razor.js"
    },
    {
      "hash": "sha256-oIr4oEdzBG5eCZDd/S+zoVGIgJ7sHsnpi+z3aVPFpkc=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.k7dz5ec6ww.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-Ei9xUUNVuLD49lEsXfW8TX8Kxmt8+bo+tZyR75qHecE=",
      "url": "_framework/Fluxor.Blazor.Web.q1j6vb2ay7.wasm"
    },
    {
      "hash": "sha256-ASpfANUD0+QbO1vvg5xO5SqBbTNDW8FZd1jd/lQlFgY=",
      "url": "_framework/Fluxor.dlg0eaereb.wasm"
    },
    {
      "hash": "sha256-QD7GyqXzHBSIxkuh9WMNB0lt6Khp+EbB4f4pkclEO+k=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.8munvqi61d.wasm"
    },
    {
      "hash": "sha256-6Yn3pezwXm+cZHIJmwXztIaQSUddSLX4W4TBm+J6yWA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.bvjid1nkc0.wasm"
    },
    {
      "hash": "sha256-pStVOoyEA8xS+b0sgFy9eqLdSaeNFmF/ta2iJhUGU2g=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.x5xvamdlpr.wasm"
    },
    {
      "hash": "sha256-RBsQ69xqtTWrhBahmkNaSqdEzCc2tlln3kGVjJHlY4A=",
      "url": "_framework/Microsoft.AspNetCore.Components.sk9123hjpl.wasm"
    },
    {
      "hash": "sha256-LRrW/S2jAmMqf71EuwOxgMbVdrDu7QppjlK8PjiYgAU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.phvn7pjmsp.wasm"
    },
    {
      "hash": "sha256-5bJobl2CmVmcJLLFnz9CCdj3xIaEyZ6a0VAD0d5/IkQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.jygd6wn873.wasm"
    },
    {
      "hash": "sha256-1aGbfOlRd6kBdGEEqlYjVobtmuQdh5hT1QGpwzeuYD4=",
      "url": "_framework/Microsoft.Extensions.Configuration.t6ukke4ckb.wasm"
    },
    {
      "hash": "sha256-d6lEFD/IVLtWxCVMIxcNqclomc5lDC6mo7CTFAjWNnM=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.39rq5qhzej.wasm"
    },
    {
      "hash": "sha256-ht/VSVGIg52S9EeiMIr7tp7vRGEj0EUMNgGe2+LCKy0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.6xhfcjuuuh.wasm"
    },
    {
      "hash": "sha256-VKkl1lJIOJKz4ZqkWG+Iu0cP6tB09ZwLM5OsOmgCt4I=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ccbly20228.wasm"
    },
    {
      "hash": "sha256-WIs2gQwJpzko0z40K/OtaX7Mfz0fcG47i5BdAqiuhO0=",
      "url": "_framework/Microsoft.Extensions.Localization.k16rwtcb1u.wasm"
    },
    {
      "hash": "sha256-SA3D3CbUaqNyLwqDF/ZYOCwqymX9e/CfQDfA/Fr26ZE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.w2uony6n45.wasm"
    },
    {
      "hash": "sha256-JXHmg5fR3RpxHRcGNyzSfoq8wkSILgVx4J/lVHa13y8=",
      "url": "_framework/Microsoft.Extensions.Logging.dy5gfgwl7j.wasm"
    },
    {
      "hash": "sha256-D36q/cad1vAbTXK6ZoXyZfvoSeT2Z4XzkfaFrQOJ824=",
      "url": "_framework/Microsoft.Extensions.Options.n2bsjd9ih3.wasm"
    },
    {
      "hash": "sha256-rv3r6coMKuvow6Hc6OAxeNvyB7RbniAzC9Kjjvs0zPs=",
      "url": "_framework/Microsoft.Extensions.Primitives.ic9wbsf5sl.wasm"
    },
    {
      "hash": "sha256-CUwN0UEngVN3nal+jQtEX6uTejg/tFi0raGAfpTxz0c=",
      "url": "_framework/Microsoft.Extensions.Validation.1igmz3eei4.wasm"
    },
    {
      "hash": "sha256-rCqRR1uovyMtEUZWreQRHObzOIBt/Tb6+4Hr1hjrJiM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.cok88e5v83.wasm"
    },
    {
      "hash": "sha256-0SCYxPqYztG582ZQwrHmilH1C1tf4dOAhxSNv453SO8=",
      "url": "_framework/Microsoft.JSInterop.fgyrcbeaao.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-VKcGr4/m2LFkPksqYoWwv8NdU+tOSehrmx17KrvZq4Q=",
      "url": "_framework/Siteswap.Details.w1l3efnlw2.wasm"
    },
    {
      "hash": "sha256-niCckpo2YTtLisaciCXwZCsgIjnfyi5IWWSWI1hOoHY=",
      "url": "_framework/Siteswaps.Components.aphop2bgji.wasm"
    },
    {
      "hash": "sha256-ZJF4mi6HA+/wZBvwHKjLoAmzM2Z8kGdiL6UxeK09ZTI=",
      "url": "_framework/Siteswaps.Generator.4uu2mk4aam.wasm"
    },
    {
      "hash": "sha256-mfcLhC0yqWf1g46ItKYJHLVeP5I12jYjC1/5sdvgwFs=",
      "url": "_framework/Siteswaps.Generator.Core.jts2awgh2a.wasm"
    },
    {
      "hash": "sha256-y7NnWh8z8gPuKAQI4hhBL69y2e7NlYbHZDvyDbFBTHI=",
      "url": "_framework/System.1h5i8a3bq8.wasm"
    },
    {
      "hash": "sha256-yw6s30xkQHE0n9IHDzZ3pepXyZs1IHySPCkEdhCAY/E=",
      "url": "_framework/System.Collections.Concurrent.f3dqq8hfca.wasm"
    },
    {
      "hash": "sha256-wr01q70Hi1K60wf1fN7RykvigzBI2s8HBk4YdZ4GOUw=",
      "url": "_framework/System.Collections.Immutable.uga5qpmz0h.wasm"
    },
    {
      "hash": "sha256-YzZ8Y+2PrhOsXXmuC2K+9s8YP6gqJmrVAB+ZR6iWM9c=",
      "url": "_framework/System.Collections.NonGeneric.5uafpbq6yt.wasm"
    },
    {
      "hash": "sha256-3IemN0ygZN+3jc69DjlWdNuWEJ59pXYMHGRwgj2sC1M=",
      "url": "_framework/System.Collections.Specialized.o3ia62rlxo.wasm"
    },
    {
      "hash": "sha256-cfOi03DhTcp9Uv9si3xofKR6dIxQVkuLuJw6CO/Jgfw=",
      "url": "_framework/System.Collections.lfcel67t0u.wasm"
    },
    {
      "hash": "sha256-MHAAPKphH8675035NIlf6lwfA5exRddE1K9KlUqLxR0=",
      "url": "_framework/System.ComponentModel.8ywkccv6di.wasm"
    },
    {
      "hash": "sha256-2tW6U2yXCBObTwSCcm++JmVY+Z4Tpn/DncZi4//Rj5g=",
      "url": "_framework/System.ComponentModel.Annotations.idghhzacf8.wasm"
    },
    {
      "hash": "sha256-K9hAnxcj2EIf0yqaMTaPmux6Xe1yPWw8EzHRrbwWZUQ=",
      "url": "_framework/System.ComponentModel.Primitives.jy1dplypfh.wasm"
    },
    {
      "hash": "sha256-D7JoXWL24GiMZhGd3wJEyYmjt8JKtE5ogQZGnqYh3Pk=",
      "url": "_framework/System.ComponentModel.TypeConverter.tleoyfz707.wasm"
    },
    {
      "hash": "sha256-UQ1m9CYNiUZCVzJOAEmqPcSOqws9rViLYX0xpzwyl2o=",
      "url": "_framework/System.Console.h0w93kh5av.wasm"
    },
    {
      "hash": "sha256-ZLplpLrhBAeMauhvkkOg7TKuGdn7UJuZtay+ABBaRRo=",
      "url": "_framework/System.Core.4yhjksec8v.wasm"
    },
    {
      "hash": "sha256-hGEG5z/RpOcjnpj2yyK/w8RL4tc1K/KFHa5iPKq+QBg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.gpjrhhbi40.wasm"
    },
    {
      "hash": "sha256-YW/C2G8MWLqUJVbhk9iXoePkuRTNwUYyP0Anv/zwfWA=",
      "url": "_framework/System.Diagnostics.TraceSource.z7k1sy14li.wasm"
    },
    {
      "hash": "sha256-if5QryK6FsVqRnl5ztMG+CJjyP8vkfHINuHnTF1N2V8=",
      "url": "_framework/System.IO.MemoryMappedFiles.9gghxwlw2n.wasm"
    },
    {
      "hash": "sha256-YUHUP3fb8mUiEFOdfQqM/stc3OxmfyDdEIl8P1n6F5o=",
      "url": "_framework/System.IO.Pipelines.9azjszgsci.wasm"
    },
    {
      "hash": "sha256-a8sIspKRsVcSOPusqEHzyr7IyaBGIEjgcq910v01os4=",
      "url": "_framework/System.Interactive.Async.juae56i6ub.wasm"
    },
    {
      "hash": "sha256-XuQlKhbxrcLIODSzGssGxOA984Ue0ugW0JTJq2omdao=",
      "url": "_framework/System.Linq.6rhjjuhczy.wasm"
    },
    {
      "hash": "sha256-+H+PL4ozZ167jwAlf/toNTlEoM7C9aiP8MPZ0kyllGQ=",
      "url": "_framework/System.Linq.Async.0udklamc7c.wasm"
    },
    {
      "hash": "sha256-roJSmTZfyrJs5FpDqtyt9a7kWcCnBJ0HRcf80Z0DvCo=",
      "url": "_framework/System.Linq.AsyncEnumerable.uk0valzids.wasm"
    },
    {
      "hash": "sha256-gGPmfZIowoY2Wr2QIrt34PKngwwLTbUIx6oLsb4AOZw=",
      "url": "_framework/System.Linq.Dynamic.Core.spqx2v4wpx.wasm"
    },
    {
      "hash": "sha256-6fftyUe0YhFIqWKhR6jPkYuFplQ1I6NXBOdVQBBe9EA=",
      "url": "_framework/System.Linq.Expressions.lpxdku059p.wasm"
    },
    {
      "hash": "sha256-VhMrIZStQf0SBROpLeK5kE2QeqSFyfEk9wHPXZoZA5Q=",
      "url": "_framework/System.Linq.Queryable.a7lw4f8p1c.wasm"
    },
    {
      "hash": "sha256-SuvOTcwYBcFt+kXbTMZn8xiayXd2OzU8OSBV7jLgloE=",
      "url": "_framework/System.Memory.qs4kypzs9m.wasm"
    },
    {
      "hash": "sha256-Wr7uYK5IAEEBz//fnLFv8YNhN9O4z269rzOcImH8Yqk=",
      "url": "_framework/System.ObjectModel.2ue58bdwtg.wasm"
    },
    {
      "hash": "sha256-iFL9j6jcFIiD1+vziZkOuTjFYj+mRvvNiUDXIiomDbY=",
      "url": "_framework/System.Private.CoreLib.wumf0n5eoq.wasm"
    },
    {
      "hash": "sha256-I/z/edKpTtj3865iH7tTkzJH6Mr9+OHoDODiPfMeHCY=",
      "url": "_framework/System.Private.DataContractSerialization.hfjm0al1je.wasm"
    },
    {
      "hash": "sha256-/OGOjiKwzngUg/Ha35+ZamTPPGTmoP+fVa+GWYye1yg=",
      "url": "_framework/System.Private.Uri.0vuzzuy0dq.wasm"
    },
    {
      "hash": "sha256-sZo91GdtMtybvMdGplnAG9j9TLearB2bg9sJL/Tak+I=",
      "url": "_framework/System.Private.Xml.Linq.ny7sizhudl.wasm"
    },
    {
      "hash": "sha256-5i5urgPuEf572dqG/qD3RmrhIoKlgaWv+hBq1apeFt0=",
      "url": "_framework/System.Private.Xml.yd376rh08a.wasm"
    },
    {
      "hash": "sha256-tSZkfqHhL3cp1jV/7Hl2isJTbQmn+hrYNVYaD2wReh8=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.lcfca9whbz.wasm"
    },
    {
      "hash": "sha256-spEky7ucfnPhx86EslLAHneskWKV+oSfzdkN1lIti5w=",
      "url": "_framework/System.Reflection.Emit.yfh0uqdfku.wasm"
    },
    {
      "hash": "sha256-U9lpfug9B0ik4UoPBUomtZK+t0CCInwdJI3cROs0lW4=",
      "url": "_framework/System.Reflection.Metadata.h7q8gcbmz9.wasm"
    },
    {
      "hash": "sha256-61WD7O+lDGJR/LMFu1GV0BaKpsZeqFt3ZJ6ZdbbTYBM=",
      "url": "_framework/System.Reflection.Primitives.vjaepo5b5z.wasm"
    },
    {
      "hash": "sha256-pGYNj0GobLeGcJ171gYL46dLUm4II/UNtKByEtRPIyI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4euq9hr5ei.wasm"
    },
    {
      "hash": "sha256-x//xU3DJi0E2+wKgW33NmbmW27iQNlteF/foR9IR6RY=",
      "url": "_framework/System.Runtime.InteropServices.ng7gmszazu.wasm"
    },
    {
      "hash": "sha256-BzE3RJQP+Sd5jgPl56W/2JR5hUdKfMSmVZypvKEV4qk=",
      "url": "_framework/System.Runtime.Serialization.Xml.vej3kihmjy.wasm"
    },
    {
      "hash": "sha256-HyD7q1VQfwSdz5NpzxTzbC840yxNdNuqvxsIJbcSLMg=",
      "url": "_framework/System.Runtime.tlxn29h3yx.wasm"
    },
    {
      "hash": "sha256-9oHjLDAHVcIqywd/PNY5orqmLFtxqM3BXwnhHntnvjQ=",
      "url": "_framework/System.Security.Cryptography.2lkfgnu7ed.wasm"
    },
    {
      "hash": "sha256-n6Fx/gDIIxu+xNYkF7EHepd28xRp7T5RHALzXdn82FU=",
      "url": "_framework/System.Text.Encodings.Web.5r90xnj60u.wasm"
    },
    {
      "hash": "sha256-LZ3L6l1CjKKxPRDDNVHz/9+2fHLAk3HfJ18F0U4D2oI=",
      "url": "_framework/System.Text.Json.n781j05t87.wasm"
    },
    {
      "hash": "sha256-8cOewo62JabI7r+eH4RQZ3TvapiE5DoopzV3oDmliAY=",
      "url": "_framework/System.Text.RegularExpressions.jvqcdnghra.wasm"
    },
    {
      "hash": "sha256-Krwkp7ALo94Ce4zfsZBwTx2Ejv4SJyDRTwJPpvWsVLY=",
      "url": "_framework/System.Threading.q8v88l37pm.wasm"
    },
    {
      "hash": "sha256-v/J46xJbooJcUOgV2PQgJQyrxxbI+ZjOwr71mUQB3es=",
      "url": "_framework/System.Xml.ReaderWriter.3z5ex3nrmg.wasm"
    },
    {
      "hash": "sha256-rd7mKqoWO+i1WQrAUWNrqH55FP43Ha7M7RlG6BCV+Mo=",
      "url": "_framework/System.Xml.XDocument.nbnxh7shja.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-M0+pSwFRiMwwwFbsF2Zh9hFrq+1cFiPKP/MFYYnJr/o=",
      "url": "_framework/Webassembly.jcbb14pisq.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-/489QwPJjdVCzoD83KQGGBFXvqD4oyiMh1DFCsDE2YE=",
      "url": "_framework/de/Siteswaps.Components.resources.jby9mlf91k.wasm"
    },
    {
      "hash": "sha256-KbZV03mso9fW90oHpJcOGR+SDPUFy5/56X87eLXBxJg=",
      "url": "_framework/de/Siteswaps.Generator.resources.vm2mjkhfdf.wasm"
    },
    {
      "hash": "sha256-rRE0qVsQ+UZxIRnnrOfCbYhghTj8NugyDPYQ+srjN5s=",
      "url": "_framework/de/Webassembly.resources.5acatmaj2t.wasm"
    },
    {
      "hash": "sha256-n+Ml13koDKOKiD04G+vYRQcW9YxZVqc8GeO4ktj5Uw8=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-la6Xd16JyahKKUWA0vO10B5Bc6DZcFIHgs98/7yWHvU=",
      "url": "_framework/dotnet.native.dquka3ub0e.js"
    },
    {
      "hash": "sha256-NjuwUuXw4V6ogB6S3OVLKg2OEob8bxUwhUZ0OiPUJQo=",
      "url": "_framework/dotnet.native.ia1lb84mka.wasm"
    },
    {
      "hash": "sha256-MZMguyke9CroSQl+L/SHIGFkPTD+LtYGXkXjAvwWx40=",
      "url": "_framework/dotnet.runtime.zbexyp8zrs.js"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-6BidRMoiuOn1+sAXrB0wI2h6ynb7APwUbe/LCer3R8Y=",
      "url": "_framework/netstandard.ktniyj1sm0.wasm"
    },
    {
      "hash": "sha256-FiwvmTHh6RK0qtUUS2i5dh+OLlMw0UEge01a4o/iEYE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-gCw01Fy6keKtd8KJAutkwfkLjCTKoFwYY5Mc/FxbJyM=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-7+tPbT7PbyQ/jsoE2CnO4GZ6P2EWrzc1WLN/XbQMURg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YD6ZiRS11HFkE5RK4pa+gbg41BfrL4EajQZj9w5mnJA=",
      "url": "images/brand/fav-icon.svg"
    },
    {
      "hash": "sha256-U2muwLEwJsqjmTr6KQoRrr9sb3PCPIW6T6nTLz640Co=",
      "url": "images/brand/passing_zone_logo_all.svg"
    },
    {
      "hash": "sha256-eOdi7ENvIhNj2dWYeCGdYaVwe0N26k2+LHPWF1FrTVU=",
      "url": "images/brand/passing_zone_short_logo.svg"
    },
    {
      "hash": "sha256-tz6SDxMqEsAxYtUYPlLCS9Cnz980buGBmlS2y+9S1n4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-xZxX3HCGv1TLpxU7++crUesr3lmj99urJcP0hjSTGHY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-AqMy6ms/HeOdXV/Q6pY4gNPNQoU0LYrAb0YdM+OkIPA=",
      "url": "pwa-install.js"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-icJjkY+OZgTWDhLfFupwPt4NS/3HEV4Xht0V9Ygu5xU=",
      "url": "sw-registrator.js"
    }
  ]
};
