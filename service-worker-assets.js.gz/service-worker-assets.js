self.assetsManifest = {
  "version": "b8OK72dV",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-wFQy3YZ5B8tDE7SVlSyd9DbC8XstJj9OyCDgmF82L18=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-z+X+dG5UyqqngwfUpSBk7xnunjafy3H7xTyJvw3Wp6k=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.puij8nbrfn.bundle.scp.css"
    },
    {
      "hash": "sha256-4WxQOlUyppqr8kLmbIRxdsocHLK9+f3eRHUQLKOtIMg=",
      "url": "_content/Siteswaps.Design.Fixtures/Siteswaps.Design.Fixtures.zvqgbbndl7.bundle.scp.css"
    },
    {
      "hash": "sha256-83Y3VqGBsLcjg5Utw3RDNG+auv6zqH4/PPwavI4QwIA=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingPage.razor.js"
    },
    {
      "hash": "sha256-o25z5uysRrF+qMuOVpDgeBLWXM3QNnTM7HO4fyvughg=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingThrowChipRow.razor.js"
    },
    {
      "hash": "sha256-rWswo2OSS3ji2dvr19DmobleNULxHesPHT25kC7AG48=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/Controls/DualRangeSlider.razor.js"
    },
    {
      "hash": "sha256-lh2MEHR0WF9aZGtQjFkebCbG2xjz2nxN7sGOrJapDtg=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/WizardPage.razor.js"
    },
    {
      "hash": "sha256-oIr4oEdzBG5eCZDd/S+zoVGIgJ7sHsnpi+z3aVPFpkc=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.k7dz5ec6ww.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-FpAhVpaw9UJbej/kZuE9tEhHu6MMEafaUZ/Hv8zf8nk=",
      "url": "_framework/Blazored.LocalStorage.e6jo5xh325.wasm"
    },
    {
      "hash": "sha256-e5XY5HktztH1G5D+ivPnTci++hOmoHdvObQeIJGYtNk=",
      "url": "_framework/ExhaustiveMatching.pvh0005fqb.wasm"
    },
    {
      "hash": "sha256-h+4NkBcGpMpryz24i57eMNFypbX1JxWaAF1ski048XQ=",
      "url": "_framework/Fluxor.Blazor.Web.rfh5ngd69g.wasm"
    },
    {
      "hash": "sha256-kmFR937gjSMYaugBUj01ICEI99F6HFm/q+iaZQMcH+E=",
      "url": "_framework/Fluxor.qq9ltcdeo2.wasm"
    },
    {
      "hash": "sha256-sTbr5pym1Z/C3mJ9yoP+XEATsUjw7lbIeHFON+h1sms=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.vw7x7bvjv1.wasm"
    },
    {
      "hash": "sha256-6UECy2Seqt0TrYfGKznaUSaEkHg/DiPeS6j94f/0Emg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.1qghzse0o4.wasm"
    },
    {
      "hash": "sha256-8mK7hgJyBpE4ftjblkCC1xZZi5jcRcW7BSbdFd2K/Ck=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.isjvd0g342.wasm"
    },
    {
      "hash": "sha256-r5it75bbKDtLBIY/MU/JhD70sYb+nwmkiLrK302AhII=",
      "url": "_framework/Microsoft.AspNetCore.Components.jn6ox4tlc6.wasm"
    },
    {
      "hash": "sha256-l8xuMPBIytDlsVipKcny4/V0zbAjJckJxqbtWJcncis=",
      "url": "_framework/Microsoft.Extensions.Configuration.1ezpgdlkhk.wasm"
    },
    {
      "hash": "sha256-wqcgisCDM/xgZcR5dt9DEfXgCaHtDH6DcgrNqXpbTOk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.e5gc7lfkix.wasm"
    },
    {
      "hash": "sha256-yLeqa+N7rj/oA+/DuzjYNyfXd1ErXM5krBAglzElmtc=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.svkmtmeo3a.wasm"
    },
    {
      "hash": "sha256-aBvQ/hjvWjNCG089D7owVJIUPazDqP+mw4FMH7xN0Js=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.sfzkvj0etu.wasm"
    },
    {
      "hash": "sha256-v91VUX92cAv4dZv4bAaHqpfBKqm85BOZfRa+vHRU79I=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.1c907rw5yn.wasm"
    },
    {
      "hash": "sha256-Rg8PdVvAN4koIJa8pDEq6txL4gbV9K21DdRvtIZyAmk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.ip3icowt8y.wasm"
    },
    {
      "hash": "sha256-UeCFfphZTLnuOZrMtn8mDJUrtlO27Xb42IiVAMGeJrs=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.na3kulwyx1.wasm"
    },
    {
      "hash": "sha256-zbB736aJ7w57K//Fi5jka+QJSJ+SwI9omdlKrcfv/h0=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.tgbvdusdia.wasm"
    },
    {
      "hash": "sha256-TtCYJURVhlO9cWgiY+HbyVUD+33l2Hu20VGphQ4mtrQ=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.exg0uvu9gy.wasm"
    },
    {
      "hash": "sha256-Eg9BbHp7owM8vj1uN9pIGgfaauETqGCijD5s7YHUfGo=",
      "url": "_framework/Microsoft.Extensions.Localization.28r9tszzb3.wasm"
    },
    {
      "hash": "sha256-uMeDMd0qS3mI/CdS7eCG6mKIYBTFA/uzTIQx3JtVGxs=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.szsqjwv7n8.wasm"
    },
    {
      "hash": "sha256-tA6FujJGXoXMLA2ZzRfywB+4hOHShyj7vrraJHaS9bg=",
      "url": "_framework/Microsoft.Extensions.Logging.89kvhi8fnr.wasm"
    },
    {
      "hash": "sha256-j27cPgrp1+zPOrwQDTR7kI9X4lB4hK8F/qtnkuRDYT8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.hog8zqir49.wasm"
    },
    {
      "hash": "sha256-+osI/gCu9kDT9nU7DllHvXgrFumud0sahvYQlnRxgcg=",
      "url": "_framework/Microsoft.Extensions.Options.qbq3kqlp37.wasm"
    },
    {
      "hash": "sha256-ByXFhEQEVtKbJdCZFhwmrLGnwG/AzTkDNM5Tf7zxeKg=",
      "url": "_framework/Microsoft.Extensions.Primitives.trtlxojstx.wasm"
    },
    {
      "hash": "sha256-dTpn8r+xR2+7XDCQYr4b6TPjcHe5MaZLlIlYy/5hdMs=",
      "url": "_framework/Microsoft.Extensions.Validation.j23g6nh3wp.wasm"
    },
    {
      "hash": "sha256-VEB/4YtP9ySU4p2RtiTB5X0jKnexUUDF9ZO492ISjxI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.grtk0vdldj.wasm"
    },
    {
      "hash": "sha256-SXxZknLsjuJ2srBnwQWrVPOYNnagXR12cbBxU6/Lh7Q=",
      "url": "_framework/Microsoft.JSInterop.ha52dy43a4.wasm"
    },
    {
      "hash": "sha256-D2aFO++J+d2eE9RGg/gBdqcJunjgMz7Yu3Hw2YCzBrE=",
      "url": "_framework/MoreLinq.5njmhjv7yd.wasm"
    },
    {
      "hash": "sha256-AAza9Qwq/LaJhuVQ+HmhNA3VYgwwzzgIUQx/GWEGeB0=",
      "url": "_framework/Siteswap.Details.wcf5v6c030.wasm"
    },
    {
      "hash": "sha256-6Ir0mSBwl5sW6qshFjosLFM+6hDNbhWGrrqHq30mSXc=",
      "url": "_framework/Siteswaps.Components.0ujim8ui22.wasm"
    },
    {
      "hash": "sha256-pr8ishCH5sds14pX2dNDP4E+QfruuNxbcNPJHJ3Ts6U=",
      "url": "_framework/Siteswaps.Design.Fixtures.60ef71kq2u.wasm"
    },
    {
      "hash": "sha256-qeln+DCbPFSy5WOvWTknbk+7LL8iAbccYkuth5RfhDA=",
      "url": "_framework/Siteswaps.Generator.Core.74ss9wjdl7.wasm"
    },
    {
      "hash": "sha256-j0X06sFWm6QvIoI2I6fHzqSUJ7x1nXzRTE5UZTUcNHE=",
      "url": "_framework/Siteswaps.Generator.fc9l7nc16h.wasm"
    },
    {
      "hash": "sha256-1B3P8IBqQgdTExD+7EHNhg+8w16cl03kVaTYu025AYE=",
      "url": "_framework/System.Collections.4k0g74k20f.wasm"
    },
    {
      "hash": "sha256-nroqypJO5/RdNDgqcoCMbpmESQ0MZN/BpMbi8iK6LUY=",
      "url": "_framework/System.Collections.Concurrent.uoy07t1wnx.wasm"
    },
    {
      "hash": "sha256-J+kji5yumfxyS3uphuvTcPVIcFxTtzqqlLXS9ZJDl9E=",
      "url": "_framework/System.Collections.Immutable.ztvc1v0t6t.wasm"
    },
    {
      "hash": "sha256-73+6zBVfUGYV/P0tr4PlEySs41h5wCXIdIEUbTXg9So=",
      "url": "_framework/System.Collections.NonGeneric.jjnn51mq5n.wasm"
    },
    {
      "hash": "sha256-57gVJVGgQie/M33XL5xrZdBYs2P4T34Jw7p4MnwPXGU=",
      "url": "_framework/System.Collections.Specialized.55i5gro6ek.wasm"
    },
    {
      "hash": "sha256-ce3LhaVt81R2EmYaZ4bOLLcBxsqUlD4Tci+ZYT0wmmU=",
      "url": "_framework/System.ComponentModel.Annotations.pi1vgdzdp8.wasm"
    },
    {
      "hash": "sha256-lvJavgfEP70dbymeMAhhrXmmH2AJfW2XAg7hKu1wkLU=",
      "url": "_framework/System.ComponentModel.Primitives.m0khbmvyj4.wasm"
    },
    {
      "hash": "sha256-zjIq2l30MpzAC51W9YboQQP2HIoruAAkbUMZwGGHysY=",
      "url": "_framework/System.ComponentModel.TypeConverter.y010o8xedh.wasm"
    },
    {
      "hash": "sha256-11gZOzIcWSMxAn6Xx3wSgkmfzE2kj6kel7xSdUAKe5o=",
      "url": "_framework/System.ComponentModel.nsdkaboc5r.wasm"
    },
    {
      "hash": "sha256-E8ZGwZA9MbHmSGrNFTaC8KjrCRV5XCvo931+Tbm8YmI=",
      "url": "_framework/System.Console.x368d3pbdx.wasm"
    },
    {
      "hash": "sha256-xnj/nN65C6wcVbdd6dvUhGL1Q8LjHkng5S4J1roXao0=",
      "url": "_framework/System.Core.i93xiipuno.wasm"
    },
    {
      "hash": "sha256-KMSz6xTnLc2DROuDvZ1OxJyhjk2PSJFBNxqa+lePS00=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ogkt767a8x.wasm"
    },
    {
      "hash": "sha256-hM4Kv3NXDp+HdGrNgYBpkW6+evN8ISwc+8btHjpqfVg=",
      "url": "_framework/System.Diagnostics.TraceSource.8h1s360ayd.wasm"
    },
    {
      "hash": "sha256-s3o2kRwnydAuCKoBmXSEBGk5ca7Eft/PurEgwInNlg8=",
      "url": "_framework/System.IO.MemoryMappedFiles.nfgmy3bmgs.wasm"
    },
    {
      "hash": "sha256-95SuLWYCWd1dHJs4mJWMFjPZnLe3u2vFx6DHa8FARUA=",
      "url": "_framework/System.IO.Pipelines.ztwn7ujnlo.wasm"
    },
    {
      "hash": "sha256-0Ava9QEAZzvicw6huLI/Lwt3mkFEbYYYmYgqguN6Ov0=",
      "url": "_framework/System.Interactive.Async.47zcrvq9fy.wasm"
    },
    {
      "hash": "sha256-8rh0I8ytJ9YuI3d/UO+1qGTWyvfj8FWSzw+ujwASSUg=",
      "url": "_framework/System.Linq.Async.20jndnhczl.wasm"
    },
    {
      "hash": "sha256-xdSuXCTdirg5NvizG67yvIDRY/kIrxZjd1WWdfVqwpY=",
      "url": "_framework/System.Linq.AsyncEnumerable.9zptcgu8y9.wasm"
    },
    {
      "hash": "sha256-C1CP17yev2rIvnfo/+4/NwsOrr2Ejg3d3i5xmdltfPU=",
      "url": "_framework/System.Linq.Dynamic.Core.hhsvivqloy.wasm"
    },
    {
      "hash": "sha256-FelE0ySDgsgYvBIuci6qzzES/KcqN5hZ5ijX1NW1EPw=",
      "url": "_framework/System.Linq.Expressions.1lamqsckz3.wasm"
    },
    {
      "hash": "sha256-SrW2YLOdY8Rp8TjVjZjf7bBWMlUsv7jVLQS3C5yF9hU=",
      "url": "_framework/System.Linq.Queryable.ujcn6gd5ng.wasm"
    },
    {
      "hash": "sha256-QKreTH94YuJYl6QUe27H2Nov2S4oXFGp1/KGF2hcfFw=",
      "url": "_framework/System.Linq.cxlp3bkx70.wasm"
    },
    {
      "hash": "sha256-LxQI78TvZvP7w4kWaZrGz0ARUgn0pRijUqFA4hOACng=",
      "url": "_framework/System.Memory.x4y85ufdfu.wasm"
    },
    {
      "hash": "sha256-9hr4G/qbrjAWNCXe3sxcyhQa3qnjLU6i/TrWCj8mArM=",
      "url": "_framework/System.ObjectModel.21letrjwx0.wasm"
    },
    {
      "hash": "sha256-C6Yo7QJAyrJGkiw8IE/oLZwpxjfCMj1rb1FyPsbyVZI=",
      "url": "_framework/System.Private.CoreLib.j23imsw8yy.wasm"
    },
    {
      "hash": "sha256-TFREbKTkv8nLXcXkm9jesqL4aQesn67cHKICShWc/7E=",
      "url": "_framework/System.Private.DataContractSerialization.g57y3c46lg.wasm"
    },
    {
      "hash": "sha256-6nryBFNVdqd4h1rSLP7CgxFQ0kidiRCqmSahhj4ZjPw=",
      "url": "_framework/System.Private.Uri.e3zphzqt77.wasm"
    },
    {
      "hash": "sha256-zddYNvDQM0dVtHW1A7ZeOQGxBzdjdnwKLQ0V8tFRo0s=",
      "url": "_framework/System.Private.Xml.Linq.5e9hecxo3f.wasm"
    },
    {
      "hash": "sha256-YZ1NbBctGnt5VvBU9TxTqdTXb4p+L8piJgcIOwNbYzo=",
      "url": "_framework/System.Private.Xml.lvv4nj4dhb.wasm"
    },
    {
      "hash": "sha256-fmSniS3/D+SPO8TvGBgCyhRZLo/CbYIalQFCBognEMk=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.i0nco5p739.wasm"
    },
    {
      "hash": "sha256-b1a+LTYQnJE55OiDzpIsQnViEa+9ct//VhReJF+PZ2A=",
      "url": "_framework/System.Reflection.Emit.zzilnbw6ty.wasm"
    },
    {
      "hash": "sha256-yjQe8I06VjKeOql6hKUw6te+q+0gyZMJMKc2Uy+L2kM=",
      "url": "_framework/System.Reflection.Metadata.af1o2bu6f4.wasm"
    },
    {
      "hash": "sha256-zRwrVoy1VTh1Z13VxBtUmtk51UMOKmxDbnCtjmeFbvk=",
      "url": "_framework/System.Reflection.Primitives.5exv6zj0cv.wasm"
    },
    {
      "hash": "sha256-RAKqMWRjS2Zs6nwGm/e4YehZJIIupOpqcU3MTJ6Zzmc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.kotgcvu3u5.wasm"
    },
    {
      "hash": "sha256-m6v6HbpjylbD0JZJVexGDIUIjNwCl9pAgCANotwMjuM=",
      "url": "_framework/System.Runtime.InteropServices.tqagiqox49.wasm"
    },
    {
      "hash": "sha256-fHABe5rFUAh3gZHdanDCpemgWjpnRzDwDHUGcwRgrqk=",
      "url": "_framework/System.Runtime.Serialization.Xml.o1smlpkrb9.wasm"
    },
    {
      "hash": "sha256-Shh6f6aK9kKKSMydNDkPaX31WllYTvyRm3ihnmKKZ/E=",
      "url": "_framework/System.Runtime.ar6uu3i2k8.wasm"
    },
    {
      "hash": "sha256-81mcuVkdTa0wNa6oWyNx2e+TULvl3DElpPuQgzQIiQQ=",
      "url": "_framework/System.Security.Cryptography.3kehqjfuy7.wasm"
    },
    {
      "hash": "sha256-d5W3ZQnUucJ4Ecu0mUrsTQ++LN4r8vg5QV8KdJY8Plk=",
      "url": "_framework/System.Text.Encodings.Web.rrhyfm4tzi.wasm"
    },
    {
      "hash": "sha256-R9CBLwYSWx3IA6a0dtFFDmmlZ2lk5GPeFoc/XsE744A=",
      "url": "_framework/System.Text.Json.9o9n378vg9.wasm"
    },
    {
      "hash": "sha256-MWZ8BgzpGcw86JGUeqUUu3zqvP+Qy2NcAM26NTe69go=",
      "url": "_framework/System.Text.RegularExpressions.5j84ywk55x.wasm"
    },
    {
      "hash": "sha256-MVfylGqGm/6TnVPMckQSgQL3RtyC2po6gbnt4Ld4hdY=",
      "url": "_framework/System.Threading.nyf8qz2b2j.wasm"
    },
    {
      "hash": "sha256-BlmkPHT3qp8CtGSLPpZx+im7YSdwpEeCpN3LP4L9wic=",
      "url": "_framework/System.Xml.ReaderWriter.2haclx8jnl.wasm"
    },
    {
      "hash": "sha256-qAFJHYY2+EW8WjbUVGxMDjTK2iXl8QnIJPWumKkqx/M=",
      "url": "_framework/System.Xml.XDocument.0e6s7u9zyh.wasm"
    },
    {
      "hash": "sha256-/AJHUhWl90NIWuzv87fyxTX8Y2CWuwPRMXkSLcsjmCc=",
      "url": "_framework/System.sgq05azvfl.wasm"
    },
    {
      "hash": "sha256-uTsVV+qbYMaSHuOJA+8uehV657M9oR2RmgmRhWAwjyk=",
      "url": "_framework/VisNetwork.Blazor.nwvjgzqmt4.wasm"
    },
    {
      "hash": "sha256-3LQlISGjNLN22YpMAZZvwkSSfnt0Ej/J6SI7kRqw1Po=",
      "url": "_framework/Webassembly.4a39o57e6v.wasm"
    },
    {
      "hash": "sha256-xI+0AYBllEcYNYZeds+rgnJ8l9AF245ZsJTBUmm+7RU=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-XtzVQt8vk5A9LDqJQcUAK4ukFgix9LUQ0R4ojl3LkjU=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-cmTjZ6pzk/ak8bWpvYyAjAy5mwlzMQoXCU3wrly/q10=",
      "url": "_framework/de/Siteswaps.Components.resources.yriq6hdl07.wasm"
    },
    {
      "hash": "sha256-+KfqClhMxE+DiXJTj1fQ17S39mrJlNeP2yM9L6GIXps=",
      "url": "_framework/de/Siteswaps.Generator.resources.ktucljtkem.wasm"
    },
    {
      "hash": "sha256-JGGIoB2j+s9nVKh4i5N2YYGP/fQRu1Hfa9ArdCqLeoo=",
      "url": "_framework/de/Webassembly.resources.koboctnaq3.wasm"
    },
    {
      "hash": "sha256-4HWRzniqzugm1yR3hzjVXbTstsQeGi1A4ew1N9xO4ac=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-3zC2I0wED4femrcGVGhEFHPykCT8hL/3Sg842NRdruw=",
      "url": "_framework/dotnet.native.ljm8vr27sf.wasm"
    },
    {
      "hash": "sha256-noxCWauS84fQ5hdEzOWG5S+pOgClQMs65b5n5xH+AQQ=",
      "url": "_framework/dotnet.native.y0glj3tiqa.js"
    },
    {
      "hash": "sha256-CHJJM/ZgtVetJLyVfm7XXfr1VQfR5EEU6T/EgGPi+Fc=",
      "url": "_framework/dotnet.runtime.gqgh3r3nhq.js"
    },
    {
      "hash": "sha256-5BfhzgOGQRjWj996AOsK8ZD97vgGxXD5Ucoy9h+kBH8=",
      "url": "_framework/icudt.g3en5r9teb.dat"
    },
    {
      "hash": "sha256-BDg4UalHjpETNlhtDALJgxsLTB3vSD9KI3ZS0nfxUqw=",
      "url": "_framework/netstandard.kkigaj8ui3.wasm"
    },
    {
      "hash": "sha256-FiwvmTHh6RK0qtUUS2i5dh+OLlMw0UEge01a4o/iEYE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-gCw01Fy6keKtd8KJAutkwfkLjCTKoFwYY5Mc/FxbJyM=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-7+tPbT7PbyQ/jsoE2CnO4GZ6P2EWrzc1WLN/XbQMURg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YD6ZiRS11HFkE5RK4pa+gbg41BfrL4EajQZj9w5mnJA=",
      "url": "images/brand/fav-icon.svg"
    },
    {
      "hash": "sha256-U2muwLEwJsqjmTr6KQoRrr9sb3PCPIW6T6nTLz640Co=",
      "url": "images/brand/passing_zone_logo_all.svg"
    },
    {
      "hash": "sha256-eOdi7ENvIhNj2dWYeCGdYaVwe0N26k2+LHPWF1FrTVU=",
      "url": "images/brand/passing_zone_short_logo.svg"
    },
    {
      "hash": "sha256-tz6SDxMqEsAxYtUYPlLCS9Cnz980buGBmlS2y+9S1n4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-xZxX3HCGv1TLpxU7++crUesr3lmj99urJcP0hjSTGHY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-AqMy6ms/HeOdXV/Q6pY4gNPNQoU0LYrAb0YdM+OkIPA=",
      "url": "pwa-install.js"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-icJjkY+OZgTWDhLfFupwPt4NS/3HEV4Xht0V9Ygu5xU=",
      "url": "sw-registrator.js"
    }
  ]
};
