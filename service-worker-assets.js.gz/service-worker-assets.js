self.assetsManifest = {
  "version": "EUJtmoxW",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-wG+HNcHW8FeIzrM2Y8R4Znc3lkBFvSB0MrnW1WMS/nw=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-uU7kH/IifR2a+WqFyZHRSEU55Q8OMOfLIZvjODGOKO8=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-bgNx+gXlnOKL/NDd9k4bEbguYrgkB16a6TzvQSS7sLw=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-MmW2yJ4dhleWIs0gnGOafDtxdfp4nYl4tGTEY++ynV4=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-nCqEQH5+mBP1zOnmxPRTQD1RR6zUV6Nk43sZXPwI++Y=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-5nZ/VtAxPYNDoDt73q3blzujApCMcAKlxLHa/fdCFyQ=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-O2aDYPrjaZ8AxGC3ixYqpdnCwlFNbye6+lXfxBvwi+4=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-KbaPLt8BnLsoPLfKps0jMutXAWN0y8K4Pd1sgLFBgHc=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-bTJTL5DJ3C6O0RZOAC1Q7kGa2A1wswV0ZUfkkC5Ai7k=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-uwl5yiMIvHW8bIY77GVapZP+uqSh2KjQHHCW+Tt9IRo=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-VHS3yA/BLNsft+lY3bwgCFx8wUAPupo0Q0JTSBIW91I=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-zRI6D2bxd3dvh6IbdRk3HRJDq2++G/wByasoLWXUBHU=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-LlydGe3R1hXyL5Qe9xnl7lAL0LvWudt9AycA0M65bGk=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-WBZRnDkUNAfwhcCce63eupS6vXfL3nu+NR5Mya4HV40=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-WFtYDPoyh7Z8jblli4rdfKcF6MY77Xj3qZ5x6fjcMls=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-izrmAXL2txQ+ESjVUjAGWcDATeTQgYU/qw1KSJdcfr0=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-04SnNP12uh1HH2cEZuSc6yJwsAvZUTBsBBjAHliKuQU=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-5hcrYcjBsI3OdK6pqg1/sKovfRmLbKxzC6z6zJ3PTp0=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-qpUdtpupRCYfRBjdIFAdB8kt3C3SFz9d9ffG/WdAi+c=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-AmS8vETRV5dhPeUVCrSnBL9rfKdqYvSOSjWE8+lsERM=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-cpCxpuoGIFq8CiggBbWZh2Y9e9EJT246Fy7JnjawOwY=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-jbIuu5swDebXCfHRcruBXev2I8b/lvaD2emptPMOdQc=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-f0uhXaNzSHCguW7IErTRjeiGQXPWEWl5p/eehMZkDdc=",
      "url": "_framework/Fluxor.9yjucuf12h.wasm"
    },
    {
      "hash": "sha256-DBC32gXCmb31ELcLWyN0VaYPespDZiNUhIL276D1X7Q=",
      "url": "_framework/Fluxor.Blazor.Web.4opwue5a6j.wasm"
    },
    {
      "hash": "sha256-x4OZ34vzk+smNBTVDO0X1fONp0vYPzg/TpNplBGcXrw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bfujbirxhp.wasm"
    },
    {
      "hash": "sha256-gqkUy66t3eWa6R+puuqCUwZqGGChovxYRS1xbKXSFTw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.mm1t5p4t7f.wasm"
    },
    {
      "hash": "sha256-zry26eJypYx4o2K3qfwApszsPt3SOYnZkZ2jtvYs2sM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.qdmy7cs13p.wasm"
    },
    {
      "hash": "sha256-VakU9JmNqyrvt4EQCQI+4Lg4ZDXNWPt425QyZxF2TfM=",
      "url": "_framework/Microsoft.AspNetCore.Components.f7ascurvon.wasm"
    },
    {
      "hash": "sha256-Eyi5Q485y+WsguDtNILM4JNQ5m0gyZ04o338dG2p7dM=",
      "url": "_framework/Microsoft.CSharp.h7eww69hut.wasm"
    },
    {
      "hash": "sha256-LOBBULi/XW4t2ARw193f39bYefcOCpZQu9Pnx/xG6+M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.4ascqjkgzo.wasm"
    },
    {
      "hash": "sha256-VlasUHL3ewmPDatuOzkCrOTyTwPkIVd24650+2CW75g=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.iitlxos134.wasm"
    },
    {
      "hash": "sha256-Y630CXldwUrJGf3O/yGiTNE/FOC4PhRpBYK+w5He9Kc=",
      "url": "_framework/Microsoft.Extensions.Configuration.xnovko9l24.wasm"
    },
    {
      "hash": "sha256-REUC3Flk7UFExEWikuLNxQdtV8wQHG8JvtuD/eSSyOg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ofhwh548wt.wasm"
    },
    {
      "hash": "sha256-cz1Zot0busqSISH6LUmoeZwyy3joC96syZfHS2R1g9I=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.pdq83eroqe.wasm"
    },
    {
      "hash": "sha256-ED3btvQNynKkxhlZtG5I2E+X1528YLLk4sDWh80texw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.4vhiktfaqi.wasm"
    },
    {
      "hash": "sha256-fED0AC2P9vox8e6kgxvz0ISVfhAlQhsZX33zoA9Zk8I=",
      "url": "_framework/Microsoft.Extensions.Logging.grenq3p3q7.wasm"
    },
    {
      "hash": "sha256-AQhhfhLMv+vwCiCQeW4MP+PDX6zfp618jfAvEhlGEzc=",
      "url": "_framework/Microsoft.Extensions.Options.rpe6kdgyiy.wasm"
    },
    {
      "hash": "sha256-ZBy3LVR1MRfpTzx1Oh4qiMpv0ZdTFGJwv8GsPfK9U0E=",
      "url": "_framework/Microsoft.Extensions.Primitives.072etlnfwu.wasm"
    },
    {
      "hash": "sha256-cgmXidzz7CoeFsl5yxjG5f+5moq0I8EiKUGIXMx2018=",
      "url": "_framework/Microsoft.Extensions.Validation.u5qkcvapwo.wasm"
    },
    {
      "hash": "sha256-f+I2R08bHmRaAE3/piqZWaqWiQb6TBqG7lPslmC9YXU=",
      "url": "_framework/Microsoft.JSInterop.37wmaf32t8.wasm"
    },
    {
      "hash": "sha256-KBkrmyz1+94H8YEVvIm+A6GPyvHKGGl8MFQONEwpVkM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.cbdj3f5i9f.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-NdujAyF0/6lWwFxiA1A+S6S6vYFqbbO4knWQZ2rqldA=",
      "url": "_framework/Radzen.Blazor.54mlsjjiax.wasm"
    },
    {
      "hash": "sha256-cLHWgyhIEb9NXzk6juuszAtyTbKFxjyE8BwGg+6IACo=",
      "url": "_framework/Siteswap.Details.wcm12qm14o.wasm"
    },
    {
      "hash": "sha256-WdLbfD/xMkfFDNJYdOnBhVR6aaKUYWy0Qq9MnOUQvN0=",
      "url": "_framework/Siteswaps.Components.rbg424bqfr.wasm"
    },
    {
      "hash": "sha256-PqdtlMQUfAPOCAJeSFzV2qVN57JNtLDVm+KHmjnp0Qo=",
      "url": "_framework/Siteswaps.Generator.Core.ycjzgr7h0t.wasm"
    },
    {
      "hash": "sha256-oKLeL+p80FLTuKnjrHC9BSa+rP7C1GCV40KJLvEL7fo=",
      "url": "_framework/Siteswaps.Generator.c5asnd35td.wasm"
    },
    {
      "hash": "sha256-k8JGGFDRrMAx42E3BlpYHCU8Hrd+Yfyt7bo4lNpKBGc=",
      "url": "_framework/System.Collections.3wlncml0wf.wasm"
    },
    {
      "hash": "sha256-zR1EZqb2b1ZrhtmeGdIAWUu7mtbpAsLXFufEauLssms=",
      "url": "_framework/System.Collections.Concurrent.pl8dpegs19.wasm"
    },
    {
      "hash": "sha256-VIiAPw3ciMXiC2+qd2Jx6PrIUOZhqPB15gG28QUzmy8=",
      "url": "_framework/System.Collections.Immutable.4264wgykhk.wasm"
    },
    {
      "hash": "sha256-P5gtiHeu4cuSaG8YqGoa+pADbBlEclko3pTn2dPYfFM=",
      "url": "_framework/System.Collections.NonGeneric.d11ao732kn.wasm"
    },
    {
      "hash": "sha256-LL7KvMdnUtJTgCDezCeryS476W354UC2WYpSaQ+99Q0=",
      "url": "_framework/System.Collections.Specialized.8t57h19bfh.wasm"
    },
    {
      "hash": "sha256-w8kjX6l9HfCvAhekRkmt6Z5Ke2CxPOenDWyAhZX/iiM=",
      "url": "_framework/System.ComponentModel.9h13ohdho8.wasm"
    },
    {
      "hash": "sha256-C8QWl6GcRoEZ6KERbYIzmxyG/BIEh4o+Fl1uk5tce8o=",
      "url": "_framework/System.ComponentModel.Annotations.frzgj6usxk.wasm"
    },
    {
      "hash": "sha256-GAjEEIIwEqwhgtKRtPRd09w529qeD+Uvonm7p9wYzXU=",
      "url": "_framework/System.ComponentModel.Primitives.oww2xlwvp4.wasm"
    },
    {
      "hash": "sha256-mVG72Dn/D2OZTI20Uv3FQEcvg+ZbX54byQJkrWj6G30=",
      "url": "_framework/System.ComponentModel.TypeConverter.3p6upy7pbr.wasm"
    },
    {
      "hash": "sha256-FO29NUMRTXXmStgwPYKsCwB7poC+l7CVHaGLJ07POfc=",
      "url": "_framework/System.Console.keu0xmq0qa.wasm"
    },
    {
      "hash": "sha256-v69fvMyRw2MLYdCm6c8qEDEkwXngA3Mc83Q+EdySs3s=",
      "url": "_framework/System.Core.vkph4sefmh.wasm"
    },
    {
      "hash": "sha256-e9zprSYr73ZjEg3RA/warz+T2HKCMKf4R4FC2EJzOSA=",
      "url": "_framework/System.Data.Common.b4ukzlhiml.wasm"
    },
    {
      "hash": "sha256-Exr7usKEpZTKszlznexb503jWxdm+6JRTx4YuWLWkIU=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.d0y3j5rtmf.wasm"
    },
    {
      "hash": "sha256-2Q7B6W4m2O4h8dciPeHR5e5guawiK2T30gbrbvLHQiE=",
      "url": "_framework/System.Diagnostics.TraceSource.trb9bwc5w4.wasm"
    },
    {
      "hash": "sha256-f/OUjzpoXORRiy71/4AVWxsGxILDtvZWdv6ArOEs6qE=",
      "url": "_framework/System.Drawing.3viw894b88.wasm"
    },
    {
      "hash": "sha256-Tllbj1f53qkjrwPuo05qu2UUb+nBv7sOvoJTNyHgJQU=",
      "url": "_framework/System.Drawing.Primitives.2ja0kwddtj.wasm"
    },
    {
      "hash": "sha256-Xgr2o8RGZxCAE8qbnz53i5VxyPQXdv9EDi1nZi+hqgA=",
      "url": "_framework/System.IO.Compression.a2pn7gfual.wasm"
    },
    {
      "hash": "sha256-kEPU5H/i+7iJmo975f5GKaaDlfZEh56IuRA+jOZTxQQ=",
      "url": "_framework/System.IO.MemoryMappedFiles.oilugtpbul.wasm"
    },
    {
      "hash": "sha256-7N+scuN8nmiU+QbLyZpP/FeRS5FYzMOKMTSW7NAJetA=",
      "url": "_framework/System.IO.Pipelines.s624opig07.wasm"
    },
    {
      "hash": "sha256-a8sIspKRsVcSOPusqEHzyr7IyaBGIEjgcq910v01os4=",
      "url": "_framework/System.Interactive.Async.juae56i6ub.wasm"
    },
    {
      "hash": "sha256-+H+PL4ozZ167jwAlf/toNTlEoM7C9aiP8MPZ0kyllGQ=",
      "url": "_framework/System.Linq.Async.0udklamc7c.wasm"
    },
    {
      "hash": "sha256-wMKXfOyiX1n4kXOA/v6gdP16MV3AVhk1AYBd14WuDVk=",
      "url": "_framework/System.Linq.AsyncEnumerable.4vapuzjryo.wasm"
    },
    {
      "hash": "sha256-QB/t+uYL9UedVTW4zO/5HG8oL5paKwdKTZW68+tSTrA=",
      "url": "_framework/System.Linq.Dynamic.Core.4vazbp99me.wasm"
    },
    {
      "hash": "sha256-U2bapK6IoYj+Jmyu7ReuPYMPaff5Zym+3ffM08VXqNU=",
      "url": "_framework/System.Linq.Expressions.p5yf3bdaaz.wasm"
    },
    {
      "hash": "sha256-zc5KGlP1rAJ6kJJrlLLHHU8z5pyIHq6hIvBhiIcChcs=",
      "url": "_framework/System.Linq.Queryable.1b4s6p00v9.wasm"
    },
    {
      "hash": "sha256-QAU1ee052SRus2JcoASHru/WsnU8stWaYe3ZcRPXNlk=",
      "url": "_framework/System.Linq.ctysavw5h3.wasm"
    },
    {
      "hash": "sha256-nrKYE5t5K9UQrg7oRbyAufOy1isxDOp6UwsmLYnZbZA=",
      "url": "_framework/System.Memory.qtn0ennx4i.wasm"
    },
    {
      "hash": "sha256-aII0tnCFopEmE8/2ffzi1FWbJ1E23Gh6MJl4i2Sw2Aw=",
      "url": "_framework/System.Net.Http.kpptf7vy52.wasm"
    },
    {
      "hash": "sha256-wAP39lrPxd24Aksv911Fc9QeQhlMtivWi6RANnW+0+Q=",
      "url": "_framework/System.Net.Primitives.g0joan8ok8.wasm"
    },
    {
      "hash": "sha256-A22CuO+w3YChYU41RLgPOy8cLwrZiA4ohhtghcp9v7g=",
      "url": "_framework/System.ObjectModel.9hlx0ya5a9.wasm"
    },
    {
      "hash": "sha256-0KbeyCTPBWRRj7eEuz/WZdxafVqP5/8ugREiM8/h6J0=",
      "url": "_framework/System.Private.CoreLib.goidn4oi7v.wasm"
    },
    {
      "hash": "sha256-KWzpZPUlXfFtVVDVnZJLrx0eWikHXgBa+Wy6g1ynwnw=",
      "url": "_framework/System.Private.Uri.pkwpbgdsoe.wasm"
    },
    {
      "hash": "sha256-6z8lce8tbvUtxQytk//tFEb4zvwoQW+o410nV98Dn30=",
      "url": "_framework/System.Private.Xml.Linq.7lfk4gjb3m.wasm"
    },
    {
      "hash": "sha256-YpXvqZsRTkTblckoBArRgofQgNqsdf7BwUkWDnHgTBU=",
      "url": "_framework/System.Private.Xml.ivf571we58.wasm"
    },
    {
      "hash": "sha256-zVbZkkJtsHWToL2kAtYti7gd5tRpRCW+DicEwBlMcRI=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.jsj4oxfxpz.wasm"
    },
    {
      "hash": "sha256-AJ0FKJ9ZDsQrHBfyUVp6H2SFeCvAQ7b+CO5o/1gEdtM=",
      "url": "_framework/System.Reflection.Emit.st9tuyayjq.wasm"
    },
    {
      "hash": "sha256-EIGVcgztm7VFFRIESiwtW4brgz4MHsIni8jnSqXeZzU=",
      "url": "_framework/System.Reflection.Metadata.oekbduy325.wasm"
    },
    {
      "hash": "sha256-lvQRu8HVW0Oi/FFIOhFbm8Rh91NbibGtoCWYsjtHfho=",
      "url": "_framework/System.Reflection.Primitives.65rsbezu43.wasm"
    },
    {
      "hash": "sha256-ZfAcYWaKT8njqCN+ej+03s70EaBAKBHysq/sBvPyXuw=",
      "url": "_framework/System.Runtime.3ipyy6udar.wasm"
    },
    {
      "hash": "sha256-Cp2bQOeRFVxMIA/IQbNc6pVyPdKopwM4EnwXZAse2KM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.uzoakn3mog.wasm"
    },
    {
      "hash": "sha256-hRKk/mTbKOvEiiMNlxO5KeZXI1qIZfVKPN5bbnFRTUI=",
      "url": "_framework/System.Runtime.InteropServices.v3fgp5l84q.wasm"
    },
    {
      "hash": "sha256-0Ft8otSyBLY3Xf1wCa28JH48CeCqnc1LVF55TTXbifc=",
      "url": "_framework/System.Runtime.Serialization.Primitives.g04uo13c1r.wasm"
    },
    {
      "hash": "sha256-HnS/9IpB+A1FgSDEhjOPc8CeSERzxybLnnZzuURlBQc=",
      "url": "_framework/System.Security.Cryptography.mys2dehdm7.wasm"
    },
    {
      "hash": "sha256-531D008FjDTjPr0whjckTfggKHSkkJHZL7PB12VuHMM=",
      "url": "_framework/System.Text.Encoding.Extensions.1uq5f7gico.wasm"
    },
    {
      "hash": "sha256-grMY4M0k8p9y9MREo8l+5RNL6efy7B8EG4ymwcIG62U=",
      "url": "_framework/System.Text.Encodings.Web.q6hehx1i4q.wasm"
    },
    {
      "hash": "sha256-OzNMTH1bIycOBMvaKZSnk5Fe9ap/l+pWD8JNJyeST5Y=",
      "url": "_framework/System.Text.Json.bg3r5xya7t.wasm"
    },
    {
      "hash": "sha256-wbussSlB/uMj5knqB0o9YQgCqUc5/x9g9tI4b0F1h3o=",
      "url": "_framework/System.Text.RegularExpressions.1cl3dw4xy1.wasm"
    },
    {
      "hash": "sha256-tD0l8jkHGArxjxeVQBljWjCbOFmMS0giqeAQ9574Nek=",
      "url": "_framework/System.Threading.0bgjpol6rw.wasm"
    },
    {
      "hash": "sha256-/c3k4DddsfTkctWfiqSEupb8ygRAN4IPO7uZ1kjzYH4=",
      "url": "_framework/System.Web.HttpUtility.v92a8shsad.wasm"
    },
    {
      "hash": "sha256-T+9RdfUBfnlvro21wk8VmmYe3ZDfKiYEBbJPCfLiuds=",
      "url": "_framework/System.Xml.Linq.7qmldn65vo.wasm"
    },
    {
      "hash": "sha256-7s+Y2fGy4QxxhJjZYfXTWWNhVA+kZcBRMiGtSjPjRHI=",
      "url": "_framework/System.Xml.XDocument.esr11nnruw.wasm"
    },
    {
      "hash": "sha256-TbXBiQa38E2TrjWSwZYk9l9sTztp8pQ4MLJyVPBpaEk=",
      "url": "_framework/System.nnqvudo0vd.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-qMY5yDjrxhk5/l4Ji1ugxQmty5iD44HsMFncZhmkPLA=",
      "url": "_framework/Webassembly.czb4t9jum8.wasm"
    },
    {
      "hash": "sha256-A59Tr9HqEhHMu8kU7kruLI9ayw5MRS6Lvc6z7jCbghk=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-1X4yihWWh/8nvh/6h0vCKVIqeKPnXviRiO98x9sIV78=",
      "url": "_framework/de/Radzen.Blazor.resources.5405rh9yeb.wasm"
    },
    {
      "hash": "sha256-LqqUIzDo3PC7ZQ17xPvNj3hNfrRdLIDV6YWY+ZrDH7Y=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-fvhQ6Y0uyX3ZytxlvGWfheC7SpkHfViQhmLCfahQn7M=",
      "url": "_framework/dotnet.native.6zpoa1sn15.wasm"
    },
    {
      "hash": "sha256-gXwUFytQWX5e5jpvb2EjW2Tj5EV/HOJY/II20+77fz0=",
      "url": "_framework/dotnet.native.hs4lpa5w7s.js"
    },
    {
      "hash": "sha256-7i3usfTrnzC/9qWO4si5Bw4w7D9fUSnSBdhQ47blX2M=",
      "url": "_framework/dotnet.runtime.a6jcqbs390.js"
    },
    {
      "hash": "sha256-eqi8Nl/CbY+KJgiPsEUpk78aOPfZJuIiv8rYEhuxTqo=",
      "url": "_framework/es/Radzen.Blazor.resources.eatht30ij7.wasm"
    },
    {
      "hash": "sha256-RnlFCjy8ILhP8CsyWhx5+qyAHbzTAGWArrsLk1NV+Ms=",
      "url": "_framework/fr/Radzen.Blazor.resources.ilgp1iryfo.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-ZkpVBOMM1gGSh4M6vg/xgY80BovgV2eTvjR8BCit1XE=",
      "url": "_framework/it/Radzen.Blazor.resources.u3hkuhe6eo.wasm"
    },
    {
      "hash": "sha256-2+BB64ZQrptMwQifp2lcwt861Hj+3i1q3L+wdUX3j0A=",
      "url": "_framework/ja/Radzen.Blazor.resources.fz6emo1m0v.wasm"
    },
    {
      "hash": "sha256-PNRSb+2oX7p+klGjBFqHih3dxBSgjzEsT2YI4+LQCoA=",
      "url": "_framework/netstandard.ke7vpdx679.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
