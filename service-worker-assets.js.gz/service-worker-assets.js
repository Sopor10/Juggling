self.assetsManifest = {
  "version": "3VHz+n5E",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-bO6I4Ih5q/1HBmBeDnGLoRK0f4qIt3+5t0ZkYIVxnmQ=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-5lWsKb4Puj9NRBXYy159P5dlKPXTbRM2d0xr5wps8CQ=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-9t6EXWYnl/QKcjuT8/+OKfHA1pouuLwhKIYsHnsB1tA=",
      "url": "_content/Radzen.Blazor/css/components/_qrcode.scss"
    },
    {
      "hash": "sha256-YVOvEQpafIYbQ1C1wHpTmvQmix/J7IIM/s6bR15xzeY=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-gkui+AFMoSJ/CZpSzxAiT7olmWjNpYUjIBWOJI6wuMc=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-twSJ5g1IeBzpsxmHR3FNu7ItID6H3XbU1HZ/qJSWRFg=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-9ZPFj82lGG387S9bKduzkwVEZO4fdwo027aodi4LNVo=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-YmGG8kk6j+Dwd+oz9V/6BjCSaUsYklsZsy/ikfZnS68=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-vty/la3MXjb8+NihPQEMF9ijro+NPHFHsJOXoK4Mh28=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-4tmVJXuCBk2/QRsIy7dLf1bN3X2OolRLRGYmKeVi0zk=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-teD7Xp9KoEEbG4QaoWzAqntOrbHPWNULM3dsFVROfkE=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-F6ZGl/o1vaNUJUGMCDbYnYCswD583tEqbu+LSy+/0ho=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-4ZMduw+tDam6nGA8fEuuPFi23JFfcM2y2EDh3/5rKAw=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-VId/LOwa/fiUtA67BmPAvXp5phlsSyykd0Lw/Fc2DAM=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-h2e1Huh88KqwXtlPMXfdyz7KuPmGwRQ4mlMmmDB0ttM=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-fzXK/2BQ8C/lABKJC6dsV+cXmFHprEg2ICoPIqt6r2E=",
      "url": "_content/Radzen.Blazor/css/math.css"
    },
    {
      "hash": "sha256-wJ3Lb9vVJtckdL66r8uyArmsd8F8WDFB2tVJR17TJ/M=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-FC48ZdritMsdzEs4DD6VfaM2i2mQenOOvjOe4CKSJCU=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-tkEpeRJs4pAczrvwgj5NEuwRXunsC9lJYbx/prqb+IM=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-BR7Qlv0MDGLSKU4dbtBeCRDWQRHGoA4xs+85cVsXI2k=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-3zReFg9ZAhiu8VOEA3fk2vRjYcKthwM+mh8/Xs8S/tw=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-ioPJnBiXjLVLzXAmSiBh6j7e9/Z+OtdZ4+++6sqTfmY=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-6/nVMSZPj5TQ58+geQrVD21/1z5mCK1ktWtneQZzvaY=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-U9HViKHLkZ5sWC6DzhKOGlAyxEQWJKRSkwzvTPi63/A=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-f0uhXaNzSHCguW7IErTRjeiGQXPWEWl5p/eehMZkDdc=",
      "url": "_framework/Fluxor.9yjucuf12h.wasm"
    },
    {
      "hash": "sha256-DBC32gXCmb31ELcLWyN0VaYPespDZiNUhIL276D1X7Q=",
      "url": "_framework/Fluxor.Blazor.Web.4opwue5a6j.wasm"
    },
    {
      "hash": "sha256-XQUHUs/koGf1zpxogmNrEkTaN0F9/0r6y4lKA9Zo6iQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.nnpv7o2u2x.wasm"
    },
    {
      "hash": "sha256-GT/95TQR2WctbARBrDEnLbDBcSPqzRbmEQNmdeqlPP0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.tnso0yph78.wasm"
    },
    {
      "hash": "sha256-X0ItT3XoPFOii3DJOUsWW/oaU9rerCJcgbhyEMX3+cE=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.dl61m4o0q4.wasm"
    },
    {
      "hash": "sha256-kZxEhxSe2DHpnwrrRxEfLL2L5OgHoSvActLcSmGzkXU=",
      "url": "_framework/Microsoft.AspNetCore.Components.rlumjf9sek.wasm"
    },
    {
      "hash": "sha256-Xc4HveiiH0ZEfrQmjeuyMy9ZVYc7tGf051LR4TqUwx4=",
      "url": "_framework/Microsoft.CSharp.hfrivl4h6j.wasm"
    },
    {
      "hash": "sha256-DF5ZQPnsimHgu/OhXI14ihBGcEBOY9jXNikZbJl7ouk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.gdtptxu0m1.wasm"
    },
    {
      "hash": "sha256-WQurBbuDtkPNdWdC7Lbk07OTfLLaEGN9l68/4BxEU7c=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.3ped9ou2lc.wasm"
    },
    {
      "hash": "sha256-W7mtMnscYp8Lm6bOFiNQIzi2jmhPwTSt+p55NOguXJk=",
      "url": "_framework/Microsoft.Extensions.Configuration.rg826fsozh.wasm"
    },
    {
      "hash": "sha256-LpQmbklEyVW7kl6AHmU8xeAJp0f0JdjvJbjG8ch7qNo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.exyg7cghz5.wasm"
    },
    {
      "hash": "sha256-rEG3da6BrNUeO3KbBWBg2CeOLGPbwAhaeQkynbC3XMQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.scyrntte5w.wasm"
    },
    {
      "hash": "sha256-fefb8H5+iU8LW/l65CVpUyT48MRdof4AjjvSu0n4L3M=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.dwfs4hw9iu.wasm"
    },
    {
      "hash": "sha256-Qa4/Z0kdUZSeM/AH6VqMRzUW+WiiYzKP4SfIVpkTH3M=",
      "url": "_framework/Microsoft.Extensions.Logging.vgeqi1hit2.wasm"
    },
    {
      "hash": "sha256-d7HuWvA9vLeZ31zMZ1zSI77tayFgOLfVjTOdy4cOCCg=",
      "url": "_framework/Microsoft.Extensions.Options.pw7q4gm2az.wasm"
    },
    {
      "hash": "sha256-H31NJrVFPp2OG96Xx3ncGsD6GKT7dPmJqzg7vrTmgLY=",
      "url": "_framework/Microsoft.Extensions.Primitives.p672mzndxd.wasm"
    },
    {
      "hash": "sha256-jyCj0FXEPC8tSTyFwUJmED4+KOGNxFY1gvM//ZXXDuQ=",
      "url": "_framework/Microsoft.Extensions.Validation.76ntqv5qki.wasm"
    },
    {
      "hash": "sha256-4I+0kHd4SomBH7+AYwAomyTpYchOHG0eb6kHl9ZrDTk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.0o8pok1eno.wasm"
    },
    {
      "hash": "sha256-i+Nzi3IT+19b/bW/QU9fD44E6OS1NVQW4iYt/nLFkfM=",
      "url": "_framework/Microsoft.JSInterop.nlw2istrp3.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-jA1/p2WMOQuMVN6RrabWGmv8oaZa9ZKfngXOqdcOMuo=",
      "url": "_framework/Radzen.Blazor.wxrwdgre8z.wasm"
    },
    {
      "hash": "sha256-LPqyPqai22fv9fMkhAhPYZySOQan3OAaAXN2jYxGOI4=",
      "url": "_framework/Siteswap.Details.0lq5wkk3gq.wasm"
    },
    {
      "hash": "sha256-DgM73Gp9K2lH4GkXqkQRoNxyWUZpzAS8TMUsDFZt1BI=",
      "url": "_framework/Siteswaps.Components.2bcrsgb8we.wasm"
    },
    {
      "hash": "sha256-TaLVTtyxh5w1ZpPaYJZyu0bVb17n3KGV+f8g7RsJYmY=",
      "url": "_framework/Siteswaps.Generator.Core.hnworj4ytm.wasm"
    },
    {
      "hash": "sha256-39n7hwtzd8QT50jHKuNgvePWWUpPM0O1/XbZrBsnhrM=",
      "url": "_framework/Siteswaps.Generator.z358yfdh5h.wasm"
    },
    {
      "hash": "sha256-cwWOZaOlWiAEvO+KvJwrGbZmVGU/y9yYgansWdR1DsQ=",
      "url": "_framework/System.73436igil7.wasm"
    },
    {
      "hash": "sha256-r2jWBsgZtiamnvWf+qktGzTfrnvLe25czxhKIr/KRcM=",
      "url": "_framework/System.Collections.Concurrent.pe8fbtksk4.wasm"
    },
    {
      "hash": "sha256-jRw4RtPSnMEKndIKqYeiiNWekWwUWxpakl4/YdLz7Xs=",
      "url": "_framework/System.Collections.Immutable.dwwwmilcyp.wasm"
    },
    {
      "hash": "sha256-ZputDHfVFsgdZPGUV0Kghd5N/OcDV7F+jrVMKXic664=",
      "url": "_framework/System.Collections.NonGeneric.eydvnb85pr.wasm"
    },
    {
      "hash": "sha256-7cabz/S5WDUykWzw7zESZQK+N9jYIUB15FS7puBW2wA=",
      "url": "_framework/System.Collections.Specialized.dcv9gg789v.wasm"
    },
    {
      "hash": "sha256-SYdcm67NLzJkXtJXjEePXCnRk0RZE1AI7gqK2ZTAYhs=",
      "url": "_framework/System.Collections.hqdrpwxrq2.wasm"
    },
    {
      "hash": "sha256-VK58rJ82fvZ5LoPWKrz1eCSl9qP/iGuEMPkkQ9Ag3kA=",
      "url": "_framework/System.ComponentModel.Annotations.cicswsfm76.wasm"
    },
    {
      "hash": "sha256-IpwpTjo4MECHqsxeZrNI92EAVhFYod5IqTbmHUOiSXI=",
      "url": "_framework/System.ComponentModel.Primitives.u4njgmo7b3.wasm"
    },
    {
      "hash": "sha256-/KWWXBv4aD7fDSjb2/E5z/l19wlOQpOMj2CBsVwXZ6I=",
      "url": "_framework/System.ComponentModel.TypeConverter.4gcccd71ju.wasm"
    },
    {
      "hash": "sha256-vgMb/PhAL6mZxeP1IhCz74r4EypDGJU0+tZ4Sq6EvXI=",
      "url": "_framework/System.ComponentModel.udxh9kg35r.wasm"
    },
    {
      "hash": "sha256-/0wudcSZI5RPcG3fDzFCYoCeozHjyeP+Fbiu3z2rz+8=",
      "url": "_framework/System.Console.jzc58p3l3e.wasm"
    },
    {
      "hash": "sha256-cEFphYHMZ+cBCmpoo71Dgeu741t4ZMlJE9SI9akH+aM=",
      "url": "_framework/System.Core.oqfjfnse12.wasm"
    },
    {
      "hash": "sha256-9uu3s5VtixnsofUcS7vXR3OBqo0EfcFod/QoNOMC4kE=",
      "url": "_framework/System.Data.Common.im2j4j13gc.wasm"
    },
    {
      "hash": "sha256-mYmzuk03Y33Smysre50fxaCGhBjIpdVFH17vcIxQnF4=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.vuddzflgup.wasm"
    },
    {
      "hash": "sha256-T9E0ySmLCm5tEvTO8eTrRGCjVB9xUDTkpHxyN6XRHug=",
      "url": "_framework/System.Diagnostics.TraceSource.newd8lnk78.wasm"
    },
    {
      "hash": "sha256-31ipxq7jdgrOvEJ/a1U1FI7+Y+K9Imthm1Lfgc4gNTs=",
      "url": "_framework/System.Drawing.Primitives.18c918ghu8.wasm"
    },
    {
      "hash": "sha256-u+Kr729B5SpLx8FBMDSCzkjkUzR/jFa8+fLUc/7AK3Y=",
      "url": "_framework/System.Drawing.j2qbi6e2vm.wasm"
    },
    {
      "hash": "sha256-Xr+Q7Dh3UcmDZfCsUqhR7GRCwGjH5mb2gVCpWFtZSUU=",
      "url": "_framework/System.IO.MemoryMappedFiles.q2smtnx4p0.wasm"
    },
    {
      "hash": "sha256-YETgkYsSCpN1j8iN/kykAr/xvo1Wj21YdTdxzCtB1LQ=",
      "url": "_framework/System.IO.Pipelines.4f8vg2rcxi.wasm"
    },
    {
      "hash": "sha256-kCn05pitMJb4HeHW8//LYoOnmmVre2ARo/2fCjaKzd4=",
      "url": "_framework/System.Interactive.Async.w4ccatvl43.wasm"
    },
    {
      "hash": "sha256-e7f/b+XuYlL7gnMn3ZSLldZLWLhnjmjnS9e/lc9nFhI=",
      "url": "_framework/System.Linq.Async.9ng5pnnqa8.wasm"
    },
    {
      "hash": "sha256-JaRWIrdT99BRTH1238SEiAa/tW0iu4c1rkdKjaDQvUo=",
      "url": "_framework/System.Linq.AsyncEnumerable.d2tkciwnfz.wasm"
    },
    {
      "hash": "sha256-5mMcR6Lmx8cWJWZek6QwlfKvlcYMgwRBLA5/5KeAVes=",
      "url": "_framework/System.Linq.Dynamic.Core.yt3i0kvfqy.wasm"
    },
    {
      "hash": "sha256-fbx6mi9+vJJeC2pcr9Q2wkwAbLe2L99Md6N49vnhpdo=",
      "url": "_framework/System.Linq.Expressions.tkxi6jp79l.wasm"
    },
    {
      "hash": "sha256-jPKtDETtY62NUXpFwjS4gp3ILndHH6LcT4ENusouuc8=",
      "url": "_framework/System.Linq.Queryable.0pfw2dqvgj.wasm"
    },
    {
      "hash": "sha256-+UIfzGkHXSpknDlwUsz3iNlVKSEtrZQUF6r4n6OSGZ0=",
      "url": "_framework/System.Linq.xm8h5mku0w.wasm"
    },
    {
      "hash": "sha256-CEKu+2fw1N/1FHogBLr21L5PSVlbaz1tsk5YML8+Kn0=",
      "url": "_framework/System.Memory.02vvr91tvv.wasm"
    },
    {
      "hash": "sha256-VWcuttg9s5M5wTp/ibol4X7S5g102+AVfkBafN7HCzs=",
      "url": "_framework/System.Net.Http.t2f0362d26.wasm"
    },
    {
      "hash": "sha256-kn6kJMwrlaN2imzvhbWyN5hzKH/sWXEjTLFfu6UNyH0=",
      "url": "_framework/System.Net.Primitives.6b4z6magly.wasm"
    },
    {
      "hash": "sha256-6J0fZPJGH7WMdbokI7b5ooCSGDSA6btydVlzL9jzKt0=",
      "url": "_framework/System.ObjectModel.w2bcbpb4pj.wasm"
    },
    {
      "hash": "sha256-1hbDZPlGhXgWR4EPC/1330tuyCXnrsInY7mYxIuChC8=",
      "url": "_framework/System.Private.CoreLib.6ofatr2kyu.wasm"
    },
    {
      "hash": "sha256-WyqjFoPBHQj0ZsbGqFwq6O2O11SY9h29mhpsoy8EfEc=",
      "url": "_framework/System.Private.Uri.taic2zs6tp.wasm"
    },
    {
      "hash": "sha256-cLgxegquqY0ZRbO/n10DOxMDfmxXmGB8W2ZmUL9tJIQ=",
      "url": "_framework/System.Private.Xml.Linq.wksj9muolp.wasm"
    },
    {
      "hash": "sha256-b2axIp7IsmghSNDqqOD/iJp6mxhbmYDb7T7jPlXr5g0=",
      "url": "_framework/System.Private.Xml.na3fw67p9b.wasm"
    },
    {
      "hash": "sha256-0E4TQ7Ba5l1ZVAEWwJ5Pduywsu30OFG6sHsgnwMzuRM=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.cdfcab6n7b.wasm"
    },
    {
      "hash": "sha256-Yi1EKRIrltBpPeo925NvnhrfFMn5CpOs0Krt2XZ/QpU=",
      "url": "_framework/System.Reflection.Emit.ep5aaaceuu.wasm"
    },
    {
      "hash": "sha256-h8l23/KLt3MRZPapJHm/NGuwjVkMg2/zppGoeGAbxHs=",
      "url": "_framework/System.Reflection.Metadata.bz1ucydll8.wasm"
    },
    {
      "hash": "sha256-2NaObkwoP7Agp2ayvIKSgzJtWIeWP1z5fp4koewJLPA=",
      "url": "_framework/System.Reflection.Primitives.gep9eginc1.wasm"
    },
    {
      "hash": "sha256-W9ESzMNrB0Cjt1YZL39Yb4daAPwKatQUst9AmVjw0M8=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.50ez5m42lb.wasm"
    },
    {
      "hash": "sha256-4AahbVd0BTYOs/bAARMGgsUpKWeV2oSRJWllis9AkAM=",
      "url": "_framework/System.Runtime.InteropServices.kzyvk071y4.wasm"
    },
    {
      "hash": "sha256-Hs3stwjUpWzRQiu/pHTVF/KYGpAJLB69lEbRub/ALAc=",
      "url": "_framework/System.Runtime.Serialization.Primitives.mzyrxqu4w0.wasm"
    },
    {
      "hash": "sha256-8d9qGf3jEbU5ut0T9SRL4oiLchtwxmH0quPnPVk2Nng=",
      "url": "_framework/System.Runtime.pab7nh5c5u.wasm"
    },
    {
      "hash": "sha256-2moma+Q/JRBY6Q172/lkRsN7/ZJ4sSFm1DFbCKsVvJs=",
      "url": "_framework/System.Security.Cryptography.yyjjz7spvh.wasm"
    },
    {
      "hash": "sha256-oQO0Z768rirnNE30DlQt5ehYJ4cmyVklvoNBeFBAbe4=",
      "url": "_framework/System.Text.Encodings.Web.jvvwvp5f3j.wasm"
    },
    {
      "hash": "sha256-gls1ZMf5VaegXuSnO9bdy/NmqavitsfKuc916Qm0fNE=",
      "url": "_framework/System.Text.Json.66ejue00ng.wasm"
    },
    {
      "hash": "sha256-NVJ4PEk+Sm5GTND7Qe7fxiTcRALkmAOAMlB7J7YpGqc=",
      "url": "_framework/System.Text.RegularExpressions.503o5281nx.wasm"
    },
    {
      "hash": "sha256-PV3WzTHHaAsOoaBqa1+o1qdkpJBL6xlcDxVoB9dJOLU=",
      "url": "_framework/System.Threading.to4italqdb.wasm"
    },
    {
      "hash": "sha256-I/nbynXab7pFShghQV3SYWi8V2HhHJtFIJtY6uSHoq4=",
      "url": "_framework/System.Web.HttpUtility.nf3z95m7ga.wasm"
    },
    {
      "hash": "sha256-msiP+hhmOL4pxMsH0pIsueaLh78LNDe1D7Gz60N0jvk=",
      "url": "_framework/System.Xml.Linq.ezielfqkzx.wasm"
    },
    {
      "hash": "sha256-kC+S1vcaYEQdoTsnc1g0OazN7tQMMgnTJmO0fJfRNjQ=",
      "url": "_framework/System.Xml.XDocument.oa9qusb4qv.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-TgluJwmiUiI/eX8Qq6vNxxcQJK7NN4J/hX/iJ8vxrmo=",
      "url": "_framework/Webassembly.y7vhlrx730.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-nQhXtBfvBlC9C1/gZAy7bhza4t5Zsg86UuiBH0/yveE=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-Sg5IQBL3BaxSjZ/S7RVTcyowY/QaRDW1WTuHVkdS7aw=",
      "url": "_framework/dotnet.native.mx1aabdn8a.wasm"
    },
    {
      "hash": "sha256-Y1zXVGb6EmJ2ruGX00S/yeenBSi4HApGHJ1ZLCOtsco=",
      "url": "_framework/dotnet.native.nnd5snryqv.js"
    },
    {
      "hash": "sha256-jCsbbdXoVd1zzGc0fQT2sz4mKuv0ANdurPVGo5Sc2jg=",
      "url": "_framework/dotnet.runtime.0j6ezsi0n0.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-JQxUjc3PKXLLCdoMK5gIaztkuigwM0/X4c9YlgzsgvY=",
      "url": "_framework/netstandard.vjx069kaqn.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
