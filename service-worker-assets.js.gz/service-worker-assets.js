self.assetsManifest = {
  "version": "BVHgA104",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-R0hL6c7qhiPdbnE9VZ0t2vrT82R40yO7UULBvJJWkyI=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-PSNvnV24ag+SGg1IqoZFElEhYwFbJesli8dTjeVrRs8=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-GUGE4Ic53vgY1z+S0Tjuyq3nNLZuPHhrn2WIUADyKqY=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-EqekAACIvGn+BzEQNyKtrBnMxa4TJKka4nvfJCxWI1s=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-oT0AFvDMScxXr9NJOSkkExxIjxdlCW54rFaObRj8168=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-ONPJMnz+8ymywSQcf2SNu1/JyLjZ82vh63Aw4W837XA=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-e+ez+HsLmQBtb1rJ/dmNL5wzbeRwbKdfvhwKqSWI7aI=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-0l/BVYcWLkQUmSombv/xeg/2EID0oor31p+4I/GETW8=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-EYr43ww4zQp88+PiLhoJiz6WhsP5Etm4YPxX7ukp/ZA=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-LUkl9GDNHWfNm5WKFHPAMLGKtrMdSQYO2FCmGz0VOSw=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-G1vX7rSefBwvqDj8sQkCb2s/AMzSPRsrpvhZ50fv3vk=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-W3my/u11XGlNQgdRGAB9SfHGevH8Tz8JJGOGF18lp8I=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-GH+pZhFw/ttZyUlYERg5MymsNmdCDxNHlRxc0Zg/XvE=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-RrbfvEKPx2i+7DwnVAwIawaNmNdY16z+2opp+wyYy+A=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-IbXcLhCGLLiwfZP0XoE4LwogjxJpuCsxt2bLxYtsK1U=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-FQFhpNMcxu6iJB48WEAOIbI54wb4GZw8eUS5jc5ZS9M=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-IqebHpObFfJwt35zLUkNRhwRRPu43+GjGYwuuv80vsQ=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-7Ybjf86BTTZE8vtvQDMit4Qziy+JgVQWaaTvnizcl2k=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-J3xX0NyH4GX7TFMBl2jv3+YQCKaS31liM8LIyElsYlU=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-ES+IU6suO8xnaTREbUqzWHMFfHJ9OTq4m9QIWqffK5k=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-KgNWfaF1iIh/HoGqRO2a+o1ljg8JZRxQ+JNQjHbZeNs=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-4yq2FvfFqifIk1NPw343s3q2ZGM0dHNJrH4fux869Uc=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-sRLBWmFIh1BpCYWUffUu/wQPvd4HqTzuBTc6ATVYdDI=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-rPFt31Nz3YLxz2ZTMLo6U2TcuzEy0+xbB0xz2ohED0o=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.k47xs0d8no.bundle.scp.css"
    },
    {
      "hash": "sha256-NtN1cBwAJHhoZFSDeeI0mmZ9ah2dyoPOE45Gy7f22cA=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/Controls/DualRangeSlider.razor.js"
    },
    {
      "hash": "sha256-nZKhD6qbjSNv8xdtFizZF45l+9hNRjXhAWECjvBhjys=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/WizardPage.razor.js"
    },
    {
      "hash": "sha256-KHt9b18+V2ENOdpBdvrnHoNpjukVENVDaxqjHxeJT4s=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.0ub9rjzqfi.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-Ei9xUUNVuLD49lEsXfW8TX8Kxmt8+bo+tZyR75qHecE=",
      "url": "_framework/Fluxor.Blazor.Web.q1j6vb2ay7.wasm"
    },
    {
      "hash": "sha256-ASpfANUD0+QbO1vvg5xO5SqBbTNDW8FZd1jd/lQlFgY=",
      "url": "_framework/Fluxor.dlg0eaereb.wasm"
    },
    {
      "hash": "sha256-wZnMQrn+SRg7cqSG1uYLSv+7Dlxl3S6Kriaxy7n+XAo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.hgvye2jeyo.wasm"
    },
    {
      "hash": "sha256-kl+EBlamfkEXNIS30KTmMRb0RWKU/13l7rpS2RJV+NY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.q2rqw54nor.wasm"
    },
    {
      "hash": "sha256-zry26eJypYx4o2K3qfwApszsPt3SOYnZkZ2jtvYs2sM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.qdmy7cs13p.wasm"
    },
    {
      "hash": "sha256-P7S5LzjpFTzOWrrAqqqTeH820T1CzOuqE32msJqq31k=",
      "url": "_framework/Microsoft.AspNetCore.Components.xgytsf078a.wasm"
    },
    {
      "hash": "sha256-WOUKwVNbG1UIFwNoB7vMYc73RWFPQgAmQrrGyw3IGYg=",
      "url": "_framework/Microsoft.CSharp.49h0y3oz7g.wasm"
    },
    {
      "hash": "sha256-LOBBULi/XW4t2ARw193f39bYefcOCpZQu9Pnx/xG6+M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.4ascqjkgzo.wasm"
    },
    {
      "hash": "sha256-VlasUHL3ewmPDatuOzkCrOTyTwPkIVd24650+2CW75g=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.iitlxos134.wasm"
    },
    {
      "hash": "sha256-Y630CXldwUrJGf3O/yGiTNE/FOC4PhRpBYK+w5He9Kc=",
      "url": "_framework/Microsoft.Extensions.Configuration.xnovko9l24.wasm"
    },
    {
      "hash": "sha256-stbWh1W3WqYIv51GP2P4ObMyHAHxV0ZgVrPznpRpsTc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.mjjrzu4ryp.wasm"
    },
    {
      "hash": "sha256-cz1Zot0busqSISH6LUmoeZwyy3joC96syZfHS2R1g9I=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.pdq83eroqe.wasm"
    },
    {
      "hash": "sha256-ub62KMUVAzMKQyIL8dSyQHgsfwkeF3DllfZtUNlYggc=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.xipeuqgnq9.wasm"
    },
    {
      "hash": "sha256-GjjVFRcxwwgJCCe2eila2/slVEmcse8hZwTEGygAEwM=",
      "url": "_framework/Microsoft.Extensions.Localization.u7c9autpa7.wasm"
    },
    {
      "hash": "sha256-ED3btvQNynKkxhlZtG5I2E+X1528YLLk4sDWh80texw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.4vhiktfaqi.wasm"
    },
    {
      "hash": "sha256-fED0AC2P9vox8e6kgxvz0ISVfhAlQhsZX33zoA9Zk8I=",
      "url": "_framework/Microsoft.Extensions.Logging.grenq3p3q7.wasm"
    },
    {
      "hash": "sha256-AQhhfhLMv+vwCiCQeW4MP+PDX6zfp618jfAvEhlGEzc=",
      "url": "_framework/Microsoft.Extensions.Options.rpe6kdgyiy.wasm"
    },
    {
      "hash": "sha256-ZBy3LVR1MRfpTzx1Oh4qiMpv0ZdTFGJwv8GsPfK9U0E=",
      "url": "_framework/Microsoft.Extensions.Primitives.072etlnfwu.wasm"
    },
    {
      "hash": "sha256-cgmXidzz7CoeFsl5yxjG5f+5moq0I8EiKUGIXMx2018=",
      "url": "_framework/Microsoft.Extensions.Validation.u5qkcvapwo.wasm"
    },
    {
      "hash": "sha256-f+I2R08bHmRaAE3/piqZWaqWiQb6TBqG7lPslmC9YXU=",
      "url": "_framework/Microsoft.JSInterop.37wmaf32t8.wasm"
    },
    {
      "hash": "sha256-KBkrmyz1+94H8YEVvIm+A6GPyvHKGGl8MFQONEwpVkM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.cbdj3f5i9f.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-gRqidccyOGLar8/gvj+n01eKP/Tmhp1FuhZgJtIYW/w=",
      "url": "_framework/Radzen.Blazor.nuvdnvvzj1.wasm"
    },
    {
      "hash": "sha256-sypqYXb/XKuPcQaQQyEjP+xbuKH/CM+TibfNHB09jio=",
      "url": "_framework/Siteswap.Details.1fbe0x0qmp.wasm"
    },
    {
      "hash": "sha256-kMnStnodFYKTnPYkF6FUZi0BsVWIgqU+mv/VaCHWiuI=",
      "url": "_framework/Siteswaps.Components.0gj8ykbdkq.wasm"
    },
    {
      "hash": "sha256-flD1sUe0xhx5LB9K38NeERFTKwmNFpamO/IWQ6omu2I=",
      "url": "_framework/Siteswaps.Generator.Core.qpusarb6ea.wasm"
    },
    {
      "hash": "sha256-0i0TAgZB/mJTMqQhrDp/amVmOmPe1QfpAhgIlj/MUJc=",
      "url": "_framework/Siteswaps.Generator.q2ng9v9htc.wasm"
    },
    {
      "hash": "sha256-y7NnWh8z8gPuKAQI4hhBL69y2e7NlYbHZDvyDbFBTHI=",
      "url": "_framework/System.1h5i8a3bq8.wasm"
    },
    {
      "hash": "sha256-XKEo5oycu854zWPIdFYNgSkCmFePukbB7dhgDs5qK1o=",
      "url": "_framework/System.Collections.Concurrent.opc4g6m516.wasm"
    },
    {
      "hash": "sha256-UWa1VoaG+p8mSCZRnJ5Re+lN984R26Dv3lbyex+kQVo=",
      "url": "_framework/System.Collections.Immutable.d5d3d1nj6r.wasm"
    },
    {
      "hash": "sha256-W/lZbyETADBnytTidvHZiIhp0jmwc4M6CbXfbLVAkgo=",
      "url": "_framework/System.Collections.NonGeneric.bwdolqk6j5.wasm"
    },
    {
      "hash": "sha256-nhFXamcfJDz+dkLlOJFOLSKcyW+QWuzoFqrxqXVYXXc=",
      "url": "_framework/System.Collections.Specialized.mntpkqhtgh.wasm"
    },
    {
      "hash": "sha256-xEnO1KfD2U1LXRODt2BLOlhmTDzhDcwwLtwCSnMGuJA=",
      "url": "_framework/System.Collections.wp243oaisj.wasm"
    },
    {
      "hash": "sha256-MHAAPKphH8675035NIlf6lwfA5exRddE1K9KlUqLxR0=",
      "url": "_framework/System.ComponentModel.8ywkccv6di.wasm"
    },
    {
      "hash": "sha256-53QYah3gnqmD5JebVL8KfATAfkPEPAs28I/AnZjzoZc=",
      "url": "_framework/System.ComponentModel.Annotations.p4rn28sqeq.wasm"
    },
    {
      "hash": "sha256-FwpQIsZ33RLxWqcISvz8FBNNsSdda+gA8zijiyxVAJQ=",
      "url": "_framework/System.ComponentModel.Primitives.55f99u6gh1.wasm"
    },
    {
      "hash": "sha256-rBU6qe0gPFcUAg229ZDPFy42/tV+9RIrZm9/KEND6ck=",
      "url": "_framework/System.ComponentModel.TypeConverter.4qw4bvppe2.wasm"
    },
    {
      "hash": "sha256-RGXdgIeOKF3eWACl0Sf0eyMZR5gw06M4KTkipamVDIQ=",
      "url": "_framework/System.Console.o57a02txb8.wasm"
    },
    {
      "hash": "sha256-ZLplpLrhBAeMauhvkkOg7TKuGdn7UJuZtay+ABBaRRo=",
      "url": "_framework/System.Core.4yhjksec8v.wasm"
    },
    {
      "hash": "sha256-Tf3NrOIp5KiS2xyAI8OyqEjKjOASXm1JlbllJ8xRxu0=",
      "url": "_framework/System.Data.Common.f92pnp3eg9.wasm"
    },
    {
      "hash": "sha256-hGEG5z/RpOcjnpj2yyK/w8RL4tc1K/KFHa5iPKq+QBg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.gpjrhhbi40.wasm"
    },
    {
      "hash": "sha256-YW/C2G8MWLqUJVbhk9iXoePkuRTNwUYyP0Anv/zwfWA=",
      "url": "_framework/System.Diagnostics.TraceSource.z7k1sy14li.wasm"
    },
    {
      "hash": "sha256-/E0NaWsA/Tar+SDyiRRNgXZkKUc4jdx1azgfhmZGZMo=",
      "url": "_framework/System.Drawing.Primitives.4wcrcv1zsd.wasm"
    },
    {
      "hash": "sha256-5mD8snGwdKAGpTVBMDLCUQCRAGEMA9bJNOwg5Rkioj0=",
      "url": "_framework/System.Drawing.y98c8dpfuo.wasm"
    },
    {
      "hash": "sha256-0rCEspC8JEPkX+0PUIMYm6Lh1XwfPlCNcahGtE6qLww=",
      "url": "_framework/System.IO.Compression.yroz7o2cyl.wasm"
    },
    {
      "hash": "sha256-if5QryK6FsVqRnl5ztMG+CJjyP8vkfHINuHnTF1N2V8=",
      "url": "_framework/System.IO.MemoryMappedFiles.9gghxwlw2n.wasm"
    },
    {
      "hash": "sha256-YUHUP3fb8mUiEFOdfQqM/stc3OxmfyDdEIl8P1n6F5o=",
      "url": "_framework/System.IO.Pipelines.9azjszgsci.wasm"
    },
    {
      "hash": "sha256-a8sIspKRsVcSOPusqEHzyr7IyaBGIEjgcq910v01os4=",
      "url": "_framework/System.Interactive.Async.juae56i6ub.wasm"
    },
    {
      "hash": "sha256-XuQlKhbxrcLIODSzGssGxOA984Ue0ugW0JTJq2omdao=",
      "url": "_framework/System.Linq.6rhjjuhczy.wasm"
    },
    {
      "hash": "sha256-+H+PL4ozZ167jwAlf/toNTlEoM7C9aiP8MPZ0kyllGQ=",
      "url": "_framework/System.Linq.Async.0udklamc7c.wasm"
    },
    {
      "hash": "sha256-roJSmTZfyrJs5FpDqtyt9a7kWcCnBJ0HRcf80Z0DvCo=",
      "url": "_framework/System.Linq.AsyncEnumerable.uk0valzids.wasm"
    },
    {
      "hash": "sha256-gGPmfZIowoY2Wr2QIrt34PKngwwLTbUIx6oLsb4AOZw=",
      "url": "_framework/System.Linq.Dynamic.Core.spqx2v4wpx.wasm"
    },
    {
      "hash": "sha256-RujvQYvNZKwXNolOpMehS67BfE0S6RKFc7VW4ptQleU=",
      "url": "_framework/System.Linq.Expressions.6ouwx94bel.wasm"
    },
    {
      "hash": "sha256-VhMrIZStQf0SBROpLeK5kE2QeqSFyfEk9wHPXZoZA5Q=",
      "url": "_framework/System.Linq.Queryable.a7lw4f8p1c.wasm"
    },
    {
      "hash": "sha256-k5oBrRF+vMI3d0bq5j3UKTiRwfdT3IsawK1+/nPDXiw=",
      "url": "_framework/System.Memory.bikruznpie.wasm"
    },
    {
      "hash": "sha256-libXq+/BL0rWKby5DDKJwwJc4BZfXc3/qMHvRH5sjmM=",
      "url": "_framework/System.Net.Http.m9xwp4y499.wasm"
    },
    {
      "hash": "sha256-JOrd7O2wESUYge/PRYjeu3ooB6yZ5l36eXhcHdPe6xs=",
      "url": "_framework/System.Net.Primitives.cmknywwdix.wasm"
    },
    {
      "hash": "sha256-wy5uG/gne2N5aNFaoDKPnvf6vyO5IJETudKD1C0L8ag=",
      "url": "_framework/System.ObjectModel.rakgglin2s.wasm"
    },
    {
      "hash": "sha256-MXWlphykIFHIPK3VPDQiB5VlpY22ie4JHJPuVEAleDg=",
      "url": "_framework/System.Private.CoreLib.7qe51cmszw.wasm"
    },
    {
      "hash": "sha256-I/z/edKpTtj3865iH7tTkzJH6Mr9+OHoDODiPfMeHCY=",
      "url": "_framework/System.Private.DataContractSerialization.hfjm0al1je.wasm"
    },
    {
      "hash": "sha256-8vIW2T74wwl/EMnfkDeYG7ZZ3repovDCD+TaSgT0+ug=",
      "url": "_framework/System.Private.Uri.ethnhqi3cy.wasm"
    },
    {
      "hash": "sha256-nCkmI46zAQ6JhPavuTvW/+xfCcquxUMoczQsjd8yPec=",
      "url": "_framework/System.Private.Xml.8fcmal7rkb.wasm"
    },
    {
      "hash": "sha256-HfRaiesij7CdnRTeQILvTAW0FupXibJ11PuD77urjq0=",
      "url": "_framework/System.Private.Xml.Linq.jcmjw15cqu.wasm"
    },
    {
      "hash": "sha256-tSZkfqHhL3cp1jV/7Hl2isJTbQmn+hrYNVYaD2wReh8=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.lcfca9whbz.wasm"
    },
    {
      "hash": "sha256-spEky7ucfnPhx86EslLAHneskWKV+oSfzdkN1lIti5w=",
      "url": "_framework/System.Reflection.Emit.yfh0uqdfku.wasm"
    },
    {
      "hash": "sha256-U9lpfug9B0ik4UoPBUomtZK+t0CCInwdJI3cROs0lW4=",
      "url": "_framework/System.Reflection.Metadata.h7q8gcbmz9.wasm"
    },
    {
      "hash": "sha256-61WD7O+lDGJR/LMFu1GV0BaKpsZeqFt3ZJ6ZdbbTYBM=",
      "url": "_framework/System.Reflection.Primitives.vjaepo5b5z.wasm"
    },
    {
      "hash": "sha256-XLtdhMi7EQzrQoevUYcRMJ88Gq8t3ETfFKhUyqNHviY=",
      "url": "_framework/System.Runtime.44hok59ucb.wasm"
    },
    {
      "hash": "sha256-lf8bNUBMbJYeAqYxKK6pKywcrKELO2tVs32xlLoJd/M=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.l4nao9l17b.wasm"
    },
    {
      "hash": "sha256-x//xU3DJi0E2+wKgW33NmbmW27iQNlteF/foR9IR6RY=",
      "url": "_framework/System.Runtime.InteropServices.ng7gmszazu.wasm"
    },
    {
      "hash": "sha256-BzE3RJQP+Sd5jgPl56W/2JR5hUdKfMSmVZypvKEV4qk=",
      "url": "_framework/System.Runtime.Serialization.Xml.vej3kihmjy.wasm"
    },
    {
      "hash": "sha256-1nvlPrs3hElQeGZ84Q45fY8lgvsweCmasJxEcEqlzsA=",
      "url": "_framework/System.Security.Cryptography.6celw455t2.wasm"
    },
    {
      "hash": "sha256-ltFMk/yJTGbUpMFV1fX+T5ZaWLUXSKiDR9otoHs+45s=",
      "url": "_framework/System.Text.Encoding.Extensions.qgpyxewjbz.wasm"
    },
    {
      "hash": "sha256-C649gvMfcAtD0+N+wjoiyTeQCHtSS7VKoxXZQQXK65k=",
      "url": "_framework/System.Text.Encodings.Web.ro59ltab9j.wasm"
    },
    {
      "hash": "sha256-qRaJmNrRGmr1BYEvm5WEVDxtLwV2s/KJI9sHiX+5R30=",
      "url": "_framework/System.Text.Json.jdzlj4o554.wasm"
    },
    {
      "hash": "sha256-kXzvgZwhtpWlZ5sT3rt4EepOhboO/cmlYU+TqyEl9ag=",
      "url": "_framework/System.Text.RegularExpressions.zvjjszt35v.wasm"
    },
    {
      "hash": "sha256-Krwkp7ALo94Ce4zfsZBwTx2Ejv4SJyDRTwJPpvWsVLY=",
      "url": "_framework/System.Threading.q8v88l37pm.wasm"
    },
    {
      "hash": "sha256-SieElvux5c61Gq6IlW8eVs0uaECbv7PmejJLRhzkj9w=",
      "url": "_framework/System.Web.HttpUtility.2l0neyapwk.wasm"
    },
    {
      "hash": "sha256-CtCEVMVCGg9HoHtIFvGwAiLGJrg+KgImS+oc8purBE8=",
      "url": "_framework/System.Xml.Linq.224i7l5jfb.wasm"
    },
    {
      "hash": "sha256-v/J46xJbooJcUOgV2PQgJQyrxxbI+ZjOwr71mUQB3es=",
      "url": "_framework/System.Xml.ReaderWriter.3z5ex3nrmg.wasm"
    },
    {
      "hash": "sha256-nOx3xfDntJgvXxVoVjIRTNYVftjOVw2T8GmPhBcS6lQ=",
      "url": "_framework/System.Xml.XDocument.s4v8ds8kxx.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-VFRifHgLJnLKIziP6jCYnbBgD+DoCFwjohAuGkkfT4k=",
      "url": "_framework/Webassembly.w328v0z57c.wasm"
    },
    {
      "hash": "sha256-A59Tr9HqEhHMu8kU7kruLI9ayw5MRS6Lvc6z7jCbghk=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-HD/OmJ53zTm/e3gyifk5zM/pryCB/1lAipQIfjritHk=",
      "url": "_framework/de/Radzen.Blazor.resources.4c731qz8g4.wasm"
    },
    {
      "hash": "sha256-+dZ6PdqKNRnTTg6PdGnA2CRu92pXWkAwlZUeJZfEYfc=",
      "url": "_framework/de/Siteswaps.Components.resources.3hakvuw07p.wasm"
    },
    {
      "hash": "sha256-XFMhMvxxHrP3sq50BKP9VCLrOihtAczGZWHZTjdTJ/g=",
      "url": "_framework/de/Siteswaps.Generator.resources.8n685pfjyb.wasm"
    },
    {
      "hash": "sha256-X9W+NOqk9ePqj/N6igxpwEhXadtUKHuOBe2FT366fSM=",
      "url": "_framework/de/Webassembly.resources.x82h1lnuit.wasm"
    },
    {
      "hash": "sha256-Sr9tGVosbkMC7/0QOzUvLOVFyDsh4OqGfr27kvucOaA=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-ZZRyEgeK+Tor9hXUrbtEFMPDD1Z3Bc0SslTKtlPcIAE=",
      "url": "_framework/dotnet.native.93blxiyga2.wasm"
    },
    {
      "hash": "sha256-la6Xd16JyahKKUWA0vO10B5Bc6DZcFIHgs98/7yWHvU=",
      "url": "_framework/dotnet.native.dquka3ub0e.js"
    },
    {
      "hash": "sha256-MZMguyke9CroSQl+L/SHIGFkPTD+LtYGXkXjAvwWx40=",
      "url": "_framework/dotnet.runtime.zbexyp8zrs.js"
    },
    {
      "hash": "sha256-s7M+jKkQFrYLmAuNW97btq8KSDSsMVt5hWxTx7kR+Bw=",
      "url": "_framework/es/Radzen.Blazor.resources.fxwseozrwx.wasm"
    },
    {
      "hash": "sha256-sM9Zv3PE6mgB30oaWeHeSbeIfRWZ85p5xB8xoR0+Juo=",
      "url": "_framework/fr/Radzen.Blazor.resources.wkgzljbii5.wasm"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-YrqzI4lwcMAXMapOMAUtYLe0u5JIkQYYPvmWUbsYCSk=",
      "url": "_framework/it/Radzen.Blazor.resources.uxasw152tn.wasm"
    },
    {
      "hash": "sha256-mD6oELsmEMrc5VmbQIZ92qJ2Z1FMuVgye0ZhsMNbQQc=",
      "url": "_framework/ja/Radzen.Blazor.resources.802p324ynn.wasm"
    },
    {
      "hash": "sha256-6BidRMoiuOn1+sAXrB0wI2h6ynb7APwUbe/LCer3R8Y=",
      "url": "_framework/netstandard.ktniyj1sm0.wasm"
    },
    {
      "hash": "sha256-7SyvdmJLuUTyvUBSusE66hPUkgZj+m9sb1I8Dy/IXTA=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-gCw01Fy6keKtd8KJAutkwfkLjCTKoFwYY5Mc/FxbJyM=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-7+tPbT7PbyQ/jsoE2CnO4GZ6P2EWrzc1WLN/XbQMURg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YD6ZiRS11HFkE5RK4pa+gbg41BfrL4EajQZj9w5mnJA=",
      "url": "images/brand/fav-icon.svg"
    },
    {
      "hash": "sha256-U2muwLEwJsqjmTr6KQoRrr9sb3PCPIW6T6nTLz640Co=",
      "url": "images/brand/passing_zone_logo_all.svg"
    },
    {
      "hash": "sha256-eOdi7ENvIhNj2dWYeCGdYaVwe0N26k2+LHPWF1FrTVU=",
      "url": "images/brand/passing_zone_short_logo.svg"
    },
    {
      "hash": "sha256-K5NTyzNF/sxOK0XNSOy3W5A4cL7/VQC9WPGJxJ6ZEI0=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
