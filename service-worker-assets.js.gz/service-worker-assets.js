self.assetsManifest = {
  "version": "ive3uQEU",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-46vm6VbMgu3sc42FwTpkQwTjme+Po77GtioZK6YVlSk=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-ZwfLTBSCfMVDl+CeYuZ7AZl6QOeWtiEDsMNH1s/Ixdw=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-GULhKD5PINDJd/OPX3yj8H303KGZXJBBb783jLCKgSo=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-oUqzDxYNe80U+p/qGo910JR5uFQIteOxLz1nRjlOAi0=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-veyUOeT5TxeUOUlI06w8gHeU6191B4Quv2wJnT1fKPA=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-Zs32I5vhzuKRXRr4yPLVmNqHMe8Puc/z0m88G6d9ra8=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-lYiMLG73UrqjeD3Xr0zwkygnPDSAQXeAo1554Yjqjkc=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-Zau8BejdxX6Aig0Bc/WovOamuonDtmg/WW+Y1aIkSuU=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-R2NA/p3Oqmezpj6sYTnspXJtDkPjveYt8y/Jc+ODNmg=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-QYflUVxBgLxR3DE7itR92NMrE/rP5QyK8gKa/R/lgNs=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-+PA/TMpN+uUgTwqwLmA/nfoyXy9AzOtxFRb9Ejy0j6k=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-sTk3OMfTvdbGaRfKOF4i+vk1tO5OaXA9NuyvccCCQDk=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-J8kJYxpBFMrMjHMBSdDlq1lYqyntxOrDZ8AW5FrxH8U=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-/XhAh5uwu9jLLftE0d0uQBhdtFMsIlOC17sqbXYURo4=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-f0TQiqIBNg73f5XBY+9FGeLwoMzclRjJzXQp3gMgqMA=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-ijDwWRMxGG7/80sB6BInfdABDQWePHnCA+HTL8fcA04=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-mscmBJFsTrAe0H/SoknylPnukiQX2yfQ/zSnbR4B75k=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-GvevBHkQdgZjwifO4s/SmWJRh3ZjQRoOBfNIDI2oh1U=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-y6x9nQqkv3mW+Dvmm6Pvh+h0ixHfY0RLzrX6ZlktoG4=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-zy1lENb9R7JlwZYjnnGHvLdfzp6kwHpd+MPfJj8bfGo=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-fzXK/2BQ8C/lABKJC6dsV+cXmFHprEg2ICoPIqt6r2E=",
      "url": "_content/Radzen.Blazor/css/math.css"
    },
    {
      "hash": "sha256-2S1C0w/NDCDKePujIyqr2e9QV9KkU/vC80d+RWYe080=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-g40MMhZnQusZtaiivDdp3hql3/KwZhLhrreoK2saRYQ=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-mHh6OGo9cpMZlZptx+gUmbVAY28oSpRtDR7lsb98WKk=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-elAwYTeIFPifUlqcJr6Ci4MhCJyzJrVK793EdpgCsfI=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-tRcVAq9DGc0nyvTuxUpiBTY8PaxnC6deHLSE8Ri1PMg=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-kD4T9W2wg/80SzAeobJp47zpnik/vqb4RNTljHyftNs=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-MDw8asWAwuNV1RDmFK7GEAf5nyxeK6SCMFng10R3GMs=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-w+u5dJ/mdzBhZEhwULqfrrJuBuRCiLXeLLKqRQ3QA6Y=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-HYNTnwNf3xj899KPdiKwmD1e5t3XRg9VaQgB1ZOvKeI=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-WFJ1U8nTZcDc4+Y11+tGTXIaJirBYauRpgm1YDC6FRk=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GFU2mt0A9T8j9YMwMQqIUmdziKNDuPppDCn2o37LV2E=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-sHZWuJsAJXLz696mlvnAKHKfbGn7ivEi1ehiEFwtSIY=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-+eSpwuS0Mx0DVjyuFo3DoQXiI+Mp+4I1MtdWSbDcZK4=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-YQqC+x+db2pnQw/gibR4ai58y8WWbVsaiM7Dg/5ZjmQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-YEIKzZHjTFrB0PdPq+MUTCQVa9BXJOk4GoWEv21FNno=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-eM8DTi6b6DvS8NIedSLSGsOM4Y0OGeQUae6fmc0F5HQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.map"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-cGOjPiVWWygaE8CFdoLZjcTpjW5SWN2gHBsKDExWBhs=",
      "url": "_framework/Fluxor.Blazor.Web.wcy6s9h87i.wasm"
    },
    {
      "hash": "sha256-9RYxaPKks/KG4cxWvALGkiJYw0HIkUce0so1m308KCk=",
      "url": "_framework/Fluxor.fj93ytimo8.wasm"
    },
    {
      "hash": "sha256-MZZTpP2g9lt3OcfLxg1njwUrYdFpdiftU6DWllfokjI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.10rq3ezq5u.wasm"
    },
    {
      "hash": "sha256-4mFj/D5nn7bl1TMBlf30KoA1XN7ZaD4UN4hoWoN8Q2s=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ecue9ddhja.wasm"
    },
    {
      "hash": "sha256-TlOuuQBdOh6PGDny6QONqfLWLWfzCdK/FdJiyi/QJe4=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.uhnbpujl8a.wasm"
    },
    {
      "hash": "sha256-hUvmS2x72bh3Fgl1vJ9kHBaQugC9zGDVFJhvBPS7GIo=",
      "url": "_framework/Microsoft.AspNetCore.Components.d622k0c6mh.wasm"
    },
    {
      "hash": "sha256-sFJMf3KqPLKxfiBbVp3BfqgfVNp9N8mdR8zGBjBZb9I=",
      "url": "_framework/Microsoft.CSharp.w0z0897npz.wasm"
    },
    {
      "hash": "sha256-3ADlF4CLU1Q+dQbj0MnPVnEJPiA4q4Jv5xxmiGEvBks=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.85u9862gz3.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-fN4AyqImDQ+h3H7tFeF4ZSkjIHJ7qWgbKL217x6P53s=",
      "url": "_framework/Microsoft.Extensions.Configuration.cyz6aj3end.wasm"
    },
    {
      "hash": "sha256-6drtlTHI8XI9WzUnd+O15o+mEiQ1mr3Ngql5grlAYlY=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.hu2mbib0r5.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-cu9McVVbOKAj1QR3DGHFGaaUGQ1EgpBYXjWMqgJsMA0=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.6vt5169ngc.wasm"
    },
    {
      "hash": "sha256-I/euMiwOKn2U2Y1vqcUjYWEG/7zWmvDiTlHAoPLRHQ0=",
      "url": "_framework/Microsoft.Extensions.Logging.p9svcbtg1a.wasm"
    },
    {
      "hash": "sha256-ZhMP66Xdwsxg3woDGMbE/PrgYbF1Ok/Fju/43KlNEtI=",
      "url": "_framework/Microsoft.Extensions.Options.684cvt6ofy.wasm"
    },
    {
      "hash": "sha256-WXYpl64HUqc9+prJOz6dOEVvB8PFJhTdfqUMB3ZGRGA=",
      "url": "_framework/Microsoft.Extensions.Primitives.5pxr7nzxwe.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-eoY1xfVgWFPBStmS/9YW1VtHmZDVUN/Zwr4tEbhI0RQ=",
      "url": "_framework/Microsoft.JSInterop.ea103878px.wasm"
    },
    {
      "hash": "sha256-l2qEfPM/BjYyiblhUW+zUgDUT7vciCSwbC6Vj2Klbeo=",
      "url": "_framework/MoreLinq.zdi2h46g68.wasm"
    },
    {
      "hash": "sha256-d16U1yI8YpNiSO10W4XzZOv37r/A8dJbvt9/04LPsU4=",
      "url": "_framework/Radzen.Blazor.b38uiux5qw.wasm"
    },
    {
      "hash": "sha256-QwX452cQMTnQJ8L9gJuKS2xIiSrjSPnJWm2D76wlWOw=",
      "url": "_framework/Siteswap.Details.1v2tzp0tfj.wasm"
    },
    {
      "hash": "sha256-9cb4dAemqz9H1p0h1kamnwsIhBIZxf5xZWY5SnIrPpc=",
      "url": "_framework/Siteswaps.Components.d2ujcrx7ri.wasm"
    },
    {
      "hash": "sha256-1JrhDlcYKwNAy/UEMY1iHftjQfkaFjeeoX2X0ySCBi0=",
      "url": "_framework/Siteswaps.Generator.g90e6n6jsd.wasm"
    },
    {
      "hash": "sha256-2KRQ+WHaA+rmVwTXTGRWW643RVnHBvkdG8H2EuKFg1Q=",
      "url": "_framework/System.Collections.Concurrent.4x8sfgpk71.wasm"
    },
    {
      "hash": "sha256-sTqqPYVN9EuU0r3vCu16+5e0j4vnPmmewEW0Yr7TVOQ=",
      "url": "_framework/System.Collections.Immutable.jjp4vvxkw4.wasm"
    },
    {
      "hash": "sha256-j/cklUL5zX1IVEJ4XWFPBWtXjUFG39XuzwNZnefVxLc=",
      "url": "_framework/System.Collections.NonGeneric.negywkkpeh.wasm"
    },
    {
      "hash": "sha256-5INFJuIASejzsbDDN4w24YNHHhErycxZ4UuMxwQ5iyo=",
      "url": "_framework/System.Collections.Specialized.0zjwz3ab72.wasm"
    },
    {
      "hash": "sha256-GfI/vs+hYpEpiace+MiBjJ2++ZRB5nMRI5knZvgNO1g=",
      "url": "_framework/System.Collections.h6b25ujj6b.wasm"
    },
    {
      "hash": "sha256-/TUgJRG3EZB5Bcfo9BEFJ61DIJLAJRTXeLYB1vnMd1Q=",
      "url": "_framework/System.ComponentModel.5y3o4qq5pj.wasm"
    },
    {
      "hash": "sha256-XfJqDldttAlEZxkNwTHqY1PufSRZjnXT++c4joJAhvQ=",
      "url": "_framework/System.ComponentModel.Annotations.to6e12rlkr.wasm"
    },
    {
      "hash": "sha256-DC/lb36dqhGbAGiVPhJXceOk50FXfuCMsR2vndDEp4w=",
      "url": "_framework/System.ComponentModel.Primitives.c2yudbh2e6.wasm"
    },
    {
      "hash": "sha256-67EudP/fK0U3AJ/kwPxt+epEU5h5AZW4zOZDi9IJiOg=",
      "url": "_framework/System.ComponentModel.TypeConverter.vrstjysw7p.wasm"
    },
    {
      "hash": "sha256-yUNPI0GU+dD+Xpp0XPhkcnxISP+rbQXwCp3ohgqz2Sg=",
      "url": "_framework/System.Console.rf82tqs2p6.wasm"
    },
    {
      "hash": "sha256-kh4hWB30Fm3u3oP8n59f5LFE0lS6vqtyU8IQzKs5oO8=",
      "url": "_framework/System.Core.mi5id249j0.wasm"
    },
    {
      "hash": "sha256-UZ2mQKWAtIhekNOwStxi4J/EnqnXzP4wyYHoTSodsDw=",
      "url": "_framework/System.Data.Common.d9oim7g41w.wasm"
    },
    {
      "hash": "sha256-WTIaO9jlWp1gc+GNRs9kw954huS0bEbief4H1pIS9wY=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.dzuuublwen.wasm"
    },
    {
      "hash": "sha256-AXwnt+5cZFr6Wg57rjU/truJK0B1mrE3TyjhPtjxGeA=",
      "url": "_framework/System.Diagnostics.TraceSource.3zxs12stau.wasm"
    },
    {
      "hash": "sha256-loiXSFF1+Zo5TBlJtfBil42YyTPVd8LYEkutf9ZnakE=",
      "url": "_framework/System.Drawing.Primitives.ipk39d478j.wasm"
    },
    {
      "hash": "sha256-oiiMus6vWgrlohxq9qh1XosItYfnyEecLBjVPRvbLHI=",
      "url": "_framework/System.Drawing.ewphiunpcg.wasm"
    },
    {
      "hash": "sha256-DwRKnw5ILypzfWLA/IWBIEe0G+Grqv5iPyvnrSxgBgY=",
      "url": "_framework/System.IO.MemoryMappedFiles.bldxlntun7.wasm"
    },
    {
      "hash": "sha256-ltKNH6AL0soduarPfzy6T90WE3rPgr3GhVxWtFvIglk=",
      "url": "_framework/System.IO.Pipelines.mslxeuynkl.wasm"
    },
    {
      "hash": "sha256-ZBX4y7qqNxAG2D1pxGD0kUN3ABBDQEQP0PY+XFZ7Y1Q=",
      "url": "_framework/System.Linq.Async.ovfc2irvky.wasm"
    },
    {
      "hash": "sha256-IKzUWIY5VCkFQ27F/0OYYmkEqv0RHDHE11rHrB+yjwM=",
      "url": "_framework/System.Linq.Dynamic.Core.0sriz3qbeh.wasm"
    },
    {
      "hash": "sha256-xqNyMSRmAEeluupce5QGehs8H/NQUtSSo+FBTlYUGWs=",
      "url": "_framework/System.Linq.Expressions.u7mzdh7mf4.wasm"
    },
    {
      "hash": "sha256-Bu1Uqi9sybnwYHQ8YoE6AApmBOGEgwM4PZCGmFWAYIc=",
      "url": "_framework/System.Linq.Queryable.ya780ngu8n.wasm"
    },
    {
      "hash": "sha256-p3iWVZ3sgaC6h3FaARMj4NCRYU3rqQOK6i7kfxhuaPM=",
      "url": "_framework/System.Linq.x660cb5anw.wasm"
    },
    {
      "hash": "sha256-P1sR18gJFiZR099QPZ+/NJvf/NBv202v7FhVSJSIPlg=",
      "url": "_framework/System.Memory.7yrz34v2p6.wasm"
    },
    {
      "hash": "sha256-oINZpqYuCBCTsAIxxrel3Km9MUTXmI78cvRnSfG+IG8=",
      "url": "_framework/System.Net.Http.w8ycgtm9bi.wasm"
    },
    {
      "hash": "sha256-rGIYM/g7mFHB4tUKXxzKAMTdeOGYJ8NmnYQ66r9vFwE=",
      "url": "_framework/System.Net.Primitives.0h7y3g6nqf.wasm"
    },
    {
      "hash": "sha256-ykJ1xusIsrZzLFIdCA1xUAirElXE8djMb4N/UeYz0OQ=",
      "url": "_framework/System.ObjectModel.e7c0pzin5h.wasm"
    },
    {
      "hash": "sha256-l+yEdGVQJIs9g8Y1oaWtNzQepFcEDWOlixqvcMmfwPY=",
      "url": "_framework/System.Private.CoreLib.nkf72o0oz1.wasm"
    },
    {
      "hash": "sha256-xMM4BvBE2rn9IHxXEWJHkj1JQVMCkax90CDQyGiZ1fw=",
      "url": "_framework/System.Private.Uri.opejzacl6a.wasm"
    },
    {
      "hash": "sha256-RPPMxOp8NXB3Mpw4g7uAtBkTpUhh99GWC/1vwBXtn1Q=",
      "url": "_framework/System.Private.Xml.Linq.ojoky2x6ju.wasm"
    },
    {
      "hash": "sha256-lvaRjLwwH+3BnmBBtAq/UX8WlWOI5gaSu1eQWHksIJg=",
      "url": "_framework/System.Private.Xml.i2hk6gn8z7.wasm"
    },
    {
      "hash": "sha256-JZCJ7qDFLjjS+OEWLQ1cIbylRxf00p7n210Cq3ow8Js=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.3yxc5d4q8n.wasm"
    },
    {
      "hash": "sha256-L1UOcWUakffvkJp7uOLHVbtxLd2guMZoQDxChgm7zyo=",
      "url": "_framework/System.Reflection.Emit.pa50cdvfvf.wasm"
    },
    {
      "hash": "sha256-2IM8ZeKlG4DHl+Leb7BteO9MxbAEhQnH8p2BDE2n3nk=",
      "url": "_framework/System.Reflection.Metadata.w2wbpvjlzd.wasm"
    },
    {
      "hash": "sha256-1PpEowNT285pH9QLabbBJhUwVk5N8pShAHK7R24yP/c=",
      "url": "_framework/System.Reflection.Primitives.s2j1s28uhr.wasm"
    },
    {
      "hash": "sha256-X9iEzzd5T0uzjA8n1nxya7g1xB685kP7Bv7B7pKjIQo=",
      "url": "_framework/System.Runtime.9abiirsfuq.wasm"
    },
    {
      "hash": "sha256-5X6FWiZE4NSx4s9iNjfVim2lWQpcbVIsorx1vB6lyno=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f7txb1es0b.wasm"
    },
    {
      "hash": "sha256-LfM6BypmGux3PI4QlIFNgVImNiJP2cT2bRxIdmr+NEc=",
      "url": "_framework/System.Runtime.InteropServices.t4gipi9sfm.wasm"
    },
    {
      "hash": "sha256-v5VUTg84n8lTiYdSZXSYXy9m0WC2k99Ij2F6RCjblTc=",
      "url": "_framework/System.Runtime.Serialization.Primitives.b9zxhpbsq0.wasm"
    },
    {
      "hash": "sha256-BkAo1wUO1j2o4gAgHdIcf5krMaKLY2JTATftC8u/rHw=",
      "url": "_framework/System.Text.Encodings.Web.ujbee8yy9l.wasm"
    },
    {
      "hash": "sha256-4u4rb7N6oqNNYI7xykGEV+ka1VoyqhhK6HREVyqSW3E=",
      "url": "_framework/System.Text.Json.m3qr24e2b0.wasm"
    },
    {
      "hash": "sha256-VkhnFhimNcJI0+rLVltza3kDz+OWZO5MaDBWxxo5DwM=",
      "url": "_framework/System.Text.RegularExpressions.i51asay8an.wasm"
    },
    {
      "hash": "sha256-C/AUG9JZAC5iks6D3bDfW96IeOqOyh+0V7svrdir2HA=",
      "url": "_framework/System.Threading.ff2vmnk05t.wasm"
    },
    {
      "hash": "sha256-0OnLnH9EvbzQVEDezQQPsV1xdkAOloFM0xMuE2gnyDc=",
      "url": "_framework/System.Web.HttpUtility.wsed2e1pbx.wasm"
    },
    {
      "hash": "sha256-yo+J3RWIIHIiwAhqsR9JizNkH/+hd3auB44RBmvvLoI=",
      "url": "_framework/System.Xml.Linq.qsgzs1hc1j.wasm"
    },
    {
      "hash": "sha256-sUpLFuNZQPCWGlQhhlmQjvC+8foGtglJhLTZ0lvunDY=",
      "url": "_framework/System.Xml.XDocument.bh6q24w1sa.wasm"
    },
    {
      "hash": "sha256-hkGLo/MuT/FJ0Xf4XUL0D2VA4dZV532GHNB1JicxLko=",
      "url": "_framework/System.m0fu6d0eya.wasm"
    },
    {
      "hash": "sha256-ULsvyv7nl6doDq/7V6xScA4P8bEScbsCcPFBlPnaS7Y=",
      "url": "_framework/VisNetwork.Blazor.4fraq2v2tj.wasm"
    },
    {
      "hash": "sha256-9flPJU4xTsf79Kdr0/67OiOoYWH8QVOoqVmGBGpq8sc=",
      "url": "_framework/Webassembly.ntyf0uvqcx.wasm"
    },
    {
      "hash": "sha256-zzk0i08BDiPNp87ecuMBt/XTHKMwwodS7wiv3vjA9ts=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-TZYYD3x7iyW/xlS3uKssVXhhRfsa1tRWf3mv9uoU5dU=",
      "url": "_framework/dotnet.native.30frdqhkhd.wasm"
    },
    {
      "hash": "sha256-f8T2ElyBFjTYefsiAzE76vmLPz9b5ywHawSGd3zTD7M=",
      "url": "_framework/dotnet.native.pi27n3xvc0.js"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-VvFDbWnpXFg53kErOn6YyakYqFvLrqERp2hFqrHQfOo=",
      "url": "_framework/netstandard.mg4v51g0up.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
