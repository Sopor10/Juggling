self.assetsManifest = {
  "version": "mV/H7G/t",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-i0q66YoQhfyumSGrPzkrhI/Twfk9C5fNgyYaE57FVpI=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-NLblO2JPa7pQbtJ5LbPe7ypQoztP33cYeAvnJ1W0t1M=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.smouq1e868.bundle.scp.css"
    },
    {
      "hash": "sha256-NtN1cBwAJHhoZFSDeeI0mmZ9ah2dyoPOE45Gy7f22cA=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/Controls/DualRangeSlider.razor.js"
    },
    {
      "hash": "sha256-nZKhD6qbjSNv8xdtFizZF45l+9hNRjXhAWECjvBhjys=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/WizardPage.razor.js"
    },
    {
      "hash": "sha256-zCSV8mpLTOa/Nyf67Du2MNlXxbEIIsFR39dlu7sgt9Q=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.0h5mazi1lh.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-Ei9xUUNVuLD49lEsXfW8TX8Kxmt8+bo+tZyR75qHecE=",
      "url": "_framework/Fluxor.Blazor.Web.q1j6vb2ay7.wasm"
    },
    {
      "hash": "sha256-ASpfANUD0+QbO1vvg5xO5SqBbTNDW8FZd1jd/lQlFgY=",
      "url": "_framework/Fluxor.dlg0eaereb.wasm"
    },
    {
      "hash": "sha256-dLWovKUp9G3o7oOs5NUXjpcbyGKfdGAzVvJTtVW76oc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.03ika61emb.wasm"
    },
    {
      "hash": "sha256-S6ACFZsQ0zlvT3jtpH93emnMFdCdytB62wPLdAb4dPg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.71qaq1kf3w.wasm"
    },
    {
      "hash": "sha256-hOWyoJaO7vVc9OsiRBSmStSlHs/bvdFC5JxMnMaf1oU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.of5s3mmi8t.wasm"
    },
    {
      "hash": "sha256-e8nCQFoVgtyaHeHOtLLeuOQxWKUQ/aFv035PdoLrCFI=",
      "url": "_framework/Microsoft.AspNetCore.Components.pv5fzya8nu.wasm"
    },
    {
      "hash": "sha256-LOBBULi/XW4t2ARw193f39bYefcOCpZQu9Pnx/xG6+M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.4ascqjkgzo.wasm"
    },
    {
      "hash": "sha256-VlasUHL3ewmPDatuOzkCrOTyTwPkIVd24650+2CW75g=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.iitlxos134.wasm"
    },
    {
      "hash": "sha256-Y630CXldwUrJGf3O/yGiTNE/FOC4PhRpBYK+w5He9Kc=",
      "url": "_framework/Microsoft.Extensions.Configuration.xnovko9l24.wasm"
    },
    {
      "hash": "sha256-ht/VSVGIg52S9EeiMIr7tp7vRGEj0EUMNgGe2+LCKy0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.6xhfcjuuuh.wasm"
    },
    {
      "hash": "sha256-cz1Zot0busqSISH6LUmoeZwyy3joC96syZfHS2R1g9I=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.pdq83eroqe.wasm"
    },
    {
      "hash": "sha256-VKkl1lJIOJKz4ZqkWG+Iu0cP6tB09ZwLM5OsOmgCt4I=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ccbly20228.wasm"
    },
    {
      "hash": "sha256-WIs2gQwJpzko0z40K/OtaX7Mfz0fcG47i5BdAqiuhO0=",
      "url": "_framework/Microsoft.Extensions.Localization.k16rwtcb1u.wasm"
    },
    {
      "hash": "sha256-SA3D3CbUaqNyLwqDF/ZYOCwqymX9e/CfQDfA/Fr26ZE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.w2uony6n45.wasm"
    },
    {
      "hash": "sha256-fED0AC2P9vox8e6kgxvz0ISVfhAlQhsZX33zoA9Zk8I=",
      "url": "_framework/Microsoft.Extensions.Logging.grenq3p3q7.wasm"
    },
    {
      "hash": "sha256-D36q/cad1vAbTXK6ZoXyZfvoSeT2Z4XzkfaFrQOJ824=",
      "url": "_framework/Microsoft.Extensions.Options.n2bsjd9ih3.wasm"
    },
    {
      "hash": "sha256-rv3r6coMKuvow6Hc6OAxeNvyB7RbniAzC9Kjjvs0zPs=",
      "url": "_framework/Microsoft.Extensions.Primitives.ic9wbsf5sl.wasm"
    },
    {
      "hash": "sha256-cgmXidzz7CoeFsl5yxjG5f+5moq0I8EiKUGIXMx2018=",
      "url": "_framework/Microsoft.Extensions.Validation.u5qkcvapwo.wasm"
    },
    {
      "hash": "sha256-KBkrmyz1+94H8YEVvIm+A6GPyvHKGGl8MFQONEwpVkM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.cbdj3f5i9f.wasm"
    },
    {
      "hash": "sha256-st1Duvq4XRkZ9+knHBQ/yGiouQTg2YCgreR0t6v1DaQ=",
      "url": "_framework/Microsoft.JSInterop.qavtmxuz5o.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-HCz4uZpxY59w52yzgLH+rwkJz0KhgWoPkoFfrTEov4w=",
      "url": "_framework/Siteswap.Details.kepe4w3mky.wasm"
    },
    {
      "hash": "sha256-FzfQLTqv6kJWVLqm1fZFP8FXMVtIM5AmvWkv7xTve/A=",
      "url": "_framework/Siteswaps.Components.ztqh54ewec.wasm"
    },
    {
      "hash": "sha256-WAdZ4I5e5wJODB7v1JsTQvB0E6crMymwddQ2fhHLDs0=",
      "url": "_framework/Siteswaps.Generator.49t5c25nhm.wasm"
    },
    {
      "hash": "sha256-YCV3ES3Gsf51PRa6Z8dvaobwBhVjDmdbAnAgxVmJqw0=",
      "url": "_framework/Siteswaps.Generator.Core.sxeb54l829.wasm"
    },
    {
      "hash": "sha256-y7NnWh8z8gPuKAQI4hhBL69y2e7NlYbHZDvyDbFBTHI=",
      "url": "_framework/System.1h5i8a3bq8.wasm"
    },
    {
      "hash": "sha256-yw6s30xkQHE0n9IHDzZ3pepXyZs1IHySPCkEdhCAY/E=",
      "url": "_framework/System.Collections.Concurrent.f3dqq8hfca.wasm"
    },
    {
      "hash": "sha256-BoC1xKIoe2u6hw4G6fPTK926TfBorz7cluDcJgEY7pk=",
      "url": "_framework/System.Collections.Immutable.iq8nsihfbz.wasm"
    },
    {
      "hash": "sha256-YzZ8Y+2PrhOsXXmuC2K+9s8YP6gqJmrVAB+ZR6iWM9c=",
      "url": "_framework/System.Collections.NonGeneric.5uafpbq6yt.wasm"
    },
    {
      "hash": "sha256-3IemN0ygZN+3jc69DjlWdNuWEJ59pXYMHGRwgj2sC1M=",
      "url": "_framework/System.Collections.Specialized.o3ia62rlxo.wasm"
    },
    {
      "hash": "sha256-hUBAkF1xRgsc6gvxtM/FEoAUGJZmknKo9+eGUEa/wb4=",
      "url": "_framework/System.Collections.xx0ztt4dm4.wasm"
    },
    {
      "hash": "sha256-MHAAPKphH8675035NIlf6lwfA5exRddE1K9KlUqLxR0=",
      "url": "_framework/System.ComponentModel.8ywkccv6di.wasm"
    },
    {
      "hash": "sha256-2tW6U2yXCBObTwSCcm++JmVY+Z4Tpn/DncZi4//Rj5g=",
      "url": "_framework/System.ComponentModel.Annotations.idghhzacf8.wasm"
    },
    {
      "hash": "sha256-K9hAnxcj2EIf0yqaMTaPmux6Xe1yPWw8EzHRrbwWZUQ=",
      "url": "_framework/System.ComponentModel.Primitives.jy1dplypfh.wasm"
    },
    {
      "hash": "sha256-D7JoXWL24GiMZhGd3wJEyYmjt8JKtE5ogQZGnqYh3Pk=",
      "url": "_framework/System.ComponentModel.TypeConverter.tleoyfz707.wasm"
    },
    {
      "hash": "sha256-UQ1m9CYNiUZCVzJOAEmqPcSOqws9rViLYX0xpzwyl2o=",
      "url": "_framework/System.Console.h0w93kh5av.wasm"
    },
    {
      "hash": "sha256-ZLplpLrhBAeMauhvkkOg7TKuGdn7UJuZtay+ABBaRRo=",
      "url": "_framework/System.Core.4yhjksec8v.wasm"
    },
    {
      "hash": "sha256-hGEG5z/RpOcjnpj2yyK/w8RL4tc1K/KFHa5iPKq+QBg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.gpjrhhbi40.wasm"
    },
    {
      "hash": "sha256-YW/C2G8MWLqUJVbhk9iXoePkuRTNwUYyP0Anv/zwfWA=",
      "url": "_framework/System.Diagnostics.TraceSource.z7k1sy14li.wasm"
    },
    {
      "hash": "sha256-if5QryK6FsVqRnl5ztMG+CJjyP8vkfHINuHnTF1N2V8=",
      "url": "_framework/System.IO.MemoryMappedFiles.9gghxwlw2n.wasm"
    },
    {
      "hash": "sha256-YUHUP3fb8mUiEFOdfQqM/stc3OxmfyDdEIl8P1n6F5o=",
      "url": "_framework/System.IO.Pipelines.9azjszgsci.wasm"
    },
    {
      "hash": "sha256-a8sIspKRsVcSOPusqEHzyr7IyaBGIEjgcq910v01os4=",
      "url": "_framework/System.Interactive.Async.juae56i6ub.wasm"
    },
    {
      "hash": "sha256-XuQlKhbxrcLIODSzGssGxOA984Ue0ugW0JTJq2omdao=",
      "url": "_framework/System.Linq.6rhjjuhczy.wasm"
    },
    {
      "hash": "sha256-+H+PL4ozZ167jwAlf/toNTlEoM7C9aiP8MPZ0kyllGQ=",
      "url": "_framework/System.Linq.Async.0udklamc7c.wasm"
    },
    {
      "hash": "sha256-roJSmTZfyrJs5FpDqtyt9a7kWcCnBJ0HRcf80Z0DvCo=",
      "url": "_framework/System.Linq.AsyncEnumerable.uk0valzids.wasm"
    },
    {
      "hash": "sha256-gGPmfZIowoY2Wr2QIrt34PKngwwLTbUIx6oLsb4AOZw=",
      "url": "_framework/System.Linq.Dynamic.Core.spqx2v4wpx.wasm"
    },
    {
      "hash": "sha256-6fftyUe0YhFIqWKhR6jPkYuFplQ1I6NXBOdVQBBe9EA=",
      "url": "_framework/System.Linq.Expressions.lpxdku059p.wasm"
    },
    {
      "hash": "sha256-VhMrIZStQf0SBROpLeK5kE2QeqSFyfEk9wHPXZoZA5Q=",
      "url": "_framework/System.Linq.Queryable.a7lw4f8p1c.wasm"
    },
    {
      "hash": "sha256-SuvOTcwYBcFt+kXbTMZn8xiayXd2OzU8OSBV7jLgloE=",
      "url": "_framework/System.Memory.qs4kypzs9m.wasm"
    },
    {
      "hash": "sha256-Wr7uYK5IAEEBz//fnLFv8YNhN9O4z269rzOcImH8Yqk=",
      "url": "_framework/System.ObjectModel.2ue58bdwtg.wasm"
    },
    {
      "hash": "sha256-YAfD2U3qk1ejBkzMQ70OF/5c8fibPFlYhGulqL0kQ/o=",
      "url": "_framework/System.Private.CoreLib.w4jz9hqqi7.wasm"
    },
    {
      "hash": "sha256-I/z/edKpTtj3865iH7tTkzJH6Mr9+OHoDODiPfMeHCY=",
      "url": "_framework/System.Private.DataContractSerialization.hfjm0al1je.wasm"
    },
    {
      "hash": "sha256-/OGOjiKwzngUg/Ha35+ZamTPPGTmoP+fVa+GWYye1yg=",
      "url": "_framework/System.Private.Uri.0vuzzuy0dq.wasm"
    },
    {
      "hash": "sha256-sZo91GdtMtybvMdGplnAG9j9TLearB2bg9sJL/Tak+I=",
      "url": "_framework/System.Private.Xml.Linq.ny7sizhudl.wasm"
    },
    {
      "hash": "sha256-5i5urgPuEf572dqG/qD3RmrhIoKlgaWv+hBq1apeFt0=",
      "url": "_framework/System.Private.Xml.yd376rh08a.wasm"
    },
    {
      "hash": "sha256-tSZkfqHhL3cp1jV/7Hl2isJTbQmn+hrYNVYaD2wReh8=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.lcfca9whbz.wasm"
    },
    {
      "hash": "sha256-spEky7ucfnPhx86EslLAHneskWKV+oSfzdkN1lIti5w=",
      "url": "_framework/System.Reflection.Emit.yfh0uqdfku.wasm"
    },
    {
      "hash": "sha256-U9lpfug9B0ik4UoPBUomtZK+t0CCInwdJI3cROs0lW4=",
      "url": "_framework/System.Reflection.Metadata.h7q8gcbmz9.wasm"
    },
    {
      "hash": "sha256-61WD7O+lDGJR/LMFu1GV0BaKpsZeqFt3ZJ6ZdbbTYBM=",
      "url": "_framework/System.Reflection.Primitives.vjaepo5b5z.wasm"
    },
    {
      "hash": "sha256-pGYNj0GobLeGcJ171gYL46dLUm4II/UNtKByEtRPIyI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4euq9hr5ei.wasm"
    },
    {
      "hash": "sha256-x//xU3DJi0E2+wKgW33NmbmW27iQNlteF/foR9IR6RY=",
      "url": "_framework/System.Runtime.InteropServices.ng7gmszazu.wasm"
    },
    {
      "hash": "sha256-BzE3RJQP+Sd5jgPl56W/2JR5hUdKfMSmVZypvKEV4qk=",
      "url": "_framework/System.Runtime.Serialization.Xml.vej3kihmjy.wasm"
    },
    {
      "hash": "sha256-DPVMm3DwbQMhbRAAM1twjR6ZvH0IZCKFCymN4cuL/VE=",
      "url": "_framework/System.Runtime.skyg6bpy5g.wasm"
    },
    {
      "hash": "sha256-9oHjLDAHVcIqywd/PNY5orqmLFtxqM3BXwnhHntnvjQ=",
      "url": "_framework/System.Security.Cryptography.2lkfgnu7ed.wasm"
    },
    {
      "hash": "sha256-n6Fx/gDIIxu+xNYkF7EHepd28xRp7T5RHALzXdn82FU=",
      "url": "_framework/System.Text.Encodings.Web.5r90xnj60u.wasm"
    },
    {
      "hash": "sha256-Wm9P4uOprtwDWJoxbL12LTRSYE4kbuoZhpHjRuCQxlg=",
      "url": "_framework/System.Text.Json.6hrhml0uwh.wasm"
    },
    {
      "hash": "sha256-8cOewo62JabI7r+eH4RQZ3TvapiE5DoopzV3oDmliAY=",
      "url": "_framework/System.Text.RegularExpressions.jvqcdnghra.wasm"
    },
    {
      "hash": "sha256-Krwkp7ALo94Ce4zfsZBwTx2Ejv4SJyDRTwJPpvWsVLY=",
      "url": "_framework/System.Threading.q8v88l37pm.wasm"
    },
    {
      "hash": "sha256-v/J46xJbooJcUOgV2PQgJQyrxxbI+ZjOwr71mUQB3es=",
      "url": "_framework/System.Xml.ReaderWriter.3z5ex3nrmg.wasm"
    },
    {
      "hash": "sha256-rd7mKqoWO+i1WQrAUWNrqH55FP43Ha7M7RlG6BCV+Mo=",
      "url": "_framework/System.Xml.XDocument.nbnxh7shja.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-UzX/WqLTW4KcPN57aRHlK4Kze7Vj56kquEcmyMApp1s=",
      "url": "_framework/Webassembly.xr4enp4wbs.wasm"
    },
    {
      "hash": "sha256-A59Tr9HqEhHMu8kU7kruLI9ayw5MRS6Lvc6z7jCbghk=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-rkoSKXKTcprttj6o/fiSo++kPNTlo2fRfTV5cfIQ/Ko=",
      "url": "_framework/de/Siteswaps.Components.resources.q23vg12vrg.wasm"
    },
    {
      "hash": "sha256-G7msRXnUL77rP4y9mxIu5k0sCXMtpJlaSmnBxHCNJlg=",
      "url": "_framework/de/Siteswaps.Generator.resources.l09pxja7jv.wasm"
    },
    {
      "hash": "sha256-0jaTMBTdejNSz2lYY1MUD2UPD7+1M/n26n5YTt3/vWA=",
      "url": "_framework/de/Webassembly.resources.yckzx1gmrj.wasm"
    },
    {
      "hash": "sha256-eCdWLyBeSn6nA4DAjfMYlFp4C94w0kzphyTfPTzssik=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-YeHM+Mz+Db40LDjmsWwbg0zEL2x3D6HqWFTeGeTsKYE=",
      "url": "_framework/dotnet.native.5nu1oqx3sy.wasm"
    },
    {
      "hash": "sha256-la6Xd16JyahKKUWA0vO10B5Bc6DZcFIHgs98/7yWHvU=",
      "url": "_framework/dotnet.native.dquka3ub0e.js"
    },
    {
      "hash": "sha256-MZMguyke9CroSQl+L/SHIGFkPTD+LtYGXkXjAvwWx40=",
      "url": "_framework/dotnet.runtime.zbexyp8zrs.js"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-6BidRMoiuOn1+sAXrB0wI2h6ynb7APwUbe/LCer3R8Y=",
      "url": "_framework/netstandard.ktniyj1sm0.wasm"
    },
    {
      "hash": "sha256-FiwvmTHh6RK0qtUUS2i5dh+OLlMw0UEge01a4o/iEYE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-gCw01Fy6keKtd8KJAutkwfkLjCTKoFwYY5Mc/FxbJyM=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-7+tPbT7PbyQ/jsoE2CnO4GZ6P2EWrzc1WLN/XbQMURg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YD6ZiRS11HFkE5RK4pa+gbg41BfrL4EajQZj9w5mnJA=",
      "url": "images/brand/fav-icon.svg"
    },
    {
      "hash": "sha256-U2muwLEwJsqjmTr6KQoRrr9sb3PCPIW6T6nTLz640Co=",
      "url": "images/brand/passing_zone_logo_all.svg"
    },
    {
      "hash": "sha256-eOdi7ENvIhNj2dWYeCGdYaVwe0N26k2+LHPWF1FrTVU=",
      "url": "images/brand/passing_zone_short_logo.svg"
    },
    {
      "hash": "sha256-aKoGD0Gkqqtk+8C5hujtNUeQD7E+Yd5tbuOOtZdAl4I=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-MbMVfLVTi7j58y+cq/Gn0wAVEL/aTHAXooqZh2vBvL4=",
      "url": "sw-registrator.js"
    }
  ]
};
