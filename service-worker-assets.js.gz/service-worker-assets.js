self.assetsManifest = {
  "version": "2Do+4BXo",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-Ss42Ydc8GqCoAOFBkDcb19SS6znJHPr8OIR55XUCCJo=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-bgKKW1V5FZRV+DMwV6JVsegnK8+861t4gW3pJLABTes=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-9t6EXWYnl/QKcjuT8/+OKfHA1pouuLwhKIYsHnsB1tA=",
      "url": "_content/Radzen.Blazor/css/components/_qrcode.scss"
    },
    {
      "hash": "sha256-bM6NwAszEecifRF8Ca/7xwdqZiTsnuQjbfSRtRrPZ1Y=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-oUqzDxYNe80U+p/qGo910JR5uFQIteOxLz1nRjlOAi0=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-Ps6dj3dNJxz4vBIYtCma6snpTLrxNUtsJF44R4nqrUk=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-+/7aQ8ZIU+MO7W8u28NMjwPIqinLTXObq6hM13s+tL8=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-lYiMLG73UrqjeD3Xr0zwkygnPDSAQXeAo1554Yjqjkc=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-y1t3FL2iV7MsxXO7fiaG6DyEf4MOIU08FLXhMbGKULA=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-ZWi4yx2zCNqsUHBVWshUj7mCGv3FvFpGBM6i+ykp9wU=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-6/cbP81VzzU4GpwVoEdg5DjibC/5jcwEbvj/ViG1UsE=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-+PA/TMpN+uUgTwqwLmA/nfoyXy9AzOtxFRb9Ejy0j6k=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-5Us2enQt5af7uzmEGC9xUotU2rXJUkRHcto+Q/YSc8Q=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-J8kJYxpBFMrMjHMBSdDlq1lYqyntxOrDZ8AW5FrxH8U=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-RaDI0o+ANUOxSayjP0ndZ22jk6BIgblCgPTytsVuWG8=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-uH1ANClTfbqNpbSeMoHfEyi5ssUziV9FK+YEjFboovo=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-+E798BlUipOceP/VE5zmQu4bf71ZuuOhQ4eFt9PsdzM=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-mscmBJFsTrAe0H/SoknylPnukiQX2yfQ/zSnbR4B75k=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-fuMUjjnaozyNt7Kd5KqOw1cI6JT0zgU7c8BcfGZj1sw=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-y6x9nQqkv3mW+Dvmm6Pvh+h0ixHfY0RLzrX6ZlktoG4=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-7xmAzgvRn2xFhzWaXMFlLgMJ9icEfh/7s2kLm6O5xbU=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-fzXK/2BQ8C/lABKJC6dsV+cXmFHprEg2ICoPIqt6r2E=",
      "url": "_content/Radzen.Blazor/css/math.css"
    },
    {
      "hash": "sha256-C4qz2ROPYj/2LipWJuZA+QGcrD42dL2h+zorv/aL9to=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-+jNLGuAcGkhjI19cN7CxkKMG5Wjha50RYQvLPVfHuNk=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-mHh6OGo9cpMZlZptx+gUmbVAY28oSpRtDR7lsb98WKk=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-iNp0DFZMfWAVbfAPjzVumy2ethleJO7kcEWniqva1Ps=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-tRcVAq9DGc0nyvTuxUpiBTY8PaxnC6deHLSE8Ri1PMg=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-L3h/NlSLDZIy6hFJqaMYK1LDUWwsYbZ9hpZerHEOw/U=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-3ItdIkpQRpOJ1Jl8BDjx+vF7GmeXt+FwQF/a19WZLJA=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-HV2X2hbFh6v/FCtaATlbZiQ3DbGZDPfd/n1l5Vc9Aj4=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-HYNTnwNf3xj899KPdiKwmD1e5t3XRg9VaQgB1ZOvKeI=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-9AS1YaxIbWC02cpnQXcNdZb2sX0yBJG/MHrHi6K4n9Q=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GFU2mt0A9T8j9YMwMQqIUmdziKNDuPppDCn2o37LV2E=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-ngKHhAWWBEnzT+Ei3lV+XNutMoolMdRNPr/dC9MzOpw=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-+eSpwuS0Mx0DVjyuFo3DoQXiI+Mp+4I1MtdWSbDcZK4=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-YQqC+x+db2pnQw/gibR4ai58y8WWbVsaiM7Dg/5ZjmQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-YEIKzZHjTFrB0PdPq+MUTCQVa9BXJOk4GoWEv21FNno=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-eM8DTi6b6DvS8NIedSLSGsOM4Y0OGeQUae6fmc0F5HQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.map"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-cGOjPiVWWygaE8CFdoLZjcTpjW5SWN2gHBsKDExWBhs=",
      "url": "_framework/Fluxor.Blazor.Web.wcy6s9h87i.wasm"
    },
    {
      "hash": "sha256-9RYxaPKks/KG4cxWvALGkiJYw0HIkUce0so1m308KCk=",
      "url": "_framework/Fluxor.fj93ytimo8.wasm"
    },
    {
      "hash": "sha256-2BMRt/nioS7vdbDhsLWFPbqusRi0Q9olDRXNkOOEbwo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.4pi680o7gk.wasm"
    },
    {
      "hash": "sha256-7rDJcV64SWFh1fz6nm0aUnaACP4bGpKJQYs/eynTUnE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.a181yodxc7.wasm"
    },
    {
      "hash": "sha256-XAL6GpQ7h0vebTxuXiSZHNE6liVbbhPj4MYrFxe1iGs=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.0xcx27kt2p.wasm"
    },
    {
      "hash": "sha256-87hnzBQsEcdxNZ8wb7XSJjGejCWH8WCD70HVWsbNzY8=",
      "url": "_framework/Microsoft.AspNetCore.Components.zovmrl0gwc.wasm"
    },
    {
      "hash": "sha256-M9yB50ZzBGiD5tr4mHLlc0tdaJO/XjzOQqJmXKE+KZ8=",
      "url": "_framework/Microsoft.CSharp.5mn55mizeo.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-CQxKGqqkQXddagSvoctbhfaOzwk+RyD3Io4+zrzibLg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ld6nw7j71m.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-Jt1s4yZxBCfaW0hBtYM0mQ/tPgqZl1kbrJ+4gm5SHpE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ungunfmsyt.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-iXVQMm+EHuOl0M20TcVFEIMHOVbqpCM/voxYP3x6eac=",
      "url": "_framework/Microsoft.Extensions.Options.ngqudnk2q9.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-ZIpDyB4IdBPC9TO0r43oSZiTsA22JMhALw5EfSD4y2s=",
      "url": "_framework/Microsoft.JSInterop.w3txse5ejr.wasm"
    },
    {
      "hash": "sha256-l2qEfPM/BjYyiblhUW+zUgDUT7vciCSwbC6Vj2Klbeo=",
      "url": "_framework/MoreLinq.zdi2h46g68.wasm"
    },
    {
      "hash": "sha256-S2baCiw5Lo/0Z5QkWYkqKQQMEd9KUx4k7MlMflDjR28=",
      "url": "_framework/Radzen.Blazor.da40cibnls.wasm"
    },
    {
      "hash": "sha256-r1y2OahQB7lCKJpu0kk/R26RHpDqhjwLu6d894TE1+Y=",
      "url": "_framework/Siteswap.Details.vwtxn8rk4d.wasm"
    },
    {
      "hash": "sha256-okmOdMUnCasjLVRgg12WZSafNWSvGFhov1QSHfNQhKE=",
      "url": "_framework/Siteswaps.Components.q209pu7a8i.wasm"
    },
    {
      "hash": "sha256-bMOqVoyJcyKLQwvOPldyBFpB//f98GfwvqYRM5889Qo=",
      "url": "_framework/Siteswaps.Generator.83u5tqb2vl.wasm"
    },
    {
      "hash": "sha256-xMF0eauQ5DkSzUozHLFFMQnL6DSJO09nJLtgag+Dzbw=",
      "url": "_framework/System.8rv0tdtrxz.wasm"
    },
    {
      "hash": "sha256-F1Dd0QGg/mHq2Qw75dt1mhbyko6LKezAOSRC8SPWwgA=",
      "url": "_framework/System.Collections.Concurrent.xaui6omvn8.wasm"
    },
    {
      "hash": "sha256-Hg9yKAhS3hhNEt5xf80TVxa4jA/bhMolwkngtFVkNs8=",
      "url": "_framework/System.Collections.Immutable.62xj92b1k4.wasm"
    },
    {
      "hash": "sha256-5v48q//sNBVap2VzgR7P/qvmwjm15K1yeowwu7d52XI=",
      "url": "_framework/System.Collections.NonGeneric.arlv3zbax0.wasm"
    },
    {
      "hash": "sha256-JeEWt4UY1+rcilWa0vrWLUePUxMEeSBFSfV3XBg9Wn0=",
      "url": "_framework/System.Collections.Specialized.7d43y1y71o.wasm"
    },
    {
      "hash": "sha256-wkB2c4G/w3kWBWzz9lIMqgMQiCyoP/K3iQA/bl+ebVY=",
      "url": "_framework/System.Collections.i4a2lrauld.wasm"
    },
    {
      "hash": "sha256-iK22E1ZfRGOIlk85BUO0gman9m+tbENJOqkc3sE40rM=",
      "url": "_framework/System.ComponentModel.Annotations.0qp9o4sgnc.wasm"
    },
    {
      "hash": "sha256-eqM2Df+a6Ik4PoxwxLaMir/nXwJ9uUSmBKQrYk8+3nc=",
      "url": "_framework/System.ComponentModel.Primitives.yixbx14uus.wasm"
    },
    {
      "hash": "sha256-S3KNGWtwp/+bnXNnyVANoYDT8yoS1QWNxagb+bMUqr0=",
      "url": "_framework/System.ComponentModel.TypeConverter.50nhfgd2bs.wasm"
    },
    {
      "hash": "sha256-P2bTPhn46nReTKHreFG6K47nCeDru/fCwA+UWdaZUK4=",
      "url": "_framework/System.ComponentModel.rp2ud0tstw.wasm"
    },
    {
      "hash": "sha256-Tbsey7tk2l5VBN5Pk+EtP45xYhSyjCpGJh+il6c1lxA=",
      "url": "_framework/System.Console.5aqxocjfgj.wasm"
    },
    {
      "hash": "sha256-nwLypftdFIuz9pkWPQeOb9Pzipi4fkf/d1b6+hQYmQY=",
      "url": "_framework/System.Core.hks3y6th5y.wasm"
    },
    {
      "hash": "sha256-RFhRNzXRRYXM4N/x+E2DIzeHJUCrlCzT4Tc1U0aqV9E=",
      "url": "_framework/System.Data.Common.gruoazwlfn.wasm"
    },
    {
      "hash": "sha256-wFAsrNvmX0wIovecw3INJkK/SmkXtqL/WM06Ce+wjHg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.0ouyxo2hmc.wasm"
    },
    {
      "hash": "sha256-fBJGeBTqV5cdjSnsxHieeWCpMPB3NB8VJrAqzcpZGN0=",
      "url": "_framework/System.Diagnostics.TraceSource.gbuk8hpj62.wasm"
    },
    {
      "hash": "sha256-oabOcPmQglwYyIY1Dk1S11NTqGk+7YFexhdQsZQ8Zmk=",
      "url": "_framework/System.Drawing.Primitives.960b5v95al.wasm"
    },
    {
      "hash": "sha256-IS00TxscKzwCbA9Iwfl5oyX6HDxnFLqrzHDub/VjVDk=",
      "url": "_framework/System.Drawing.xc9zr6of0m.wasm"
    },
    {
      "hash": "sha256-rq5Mdel0ueYYmgkx2AJEYiHVV368s26GU71wNps5l5c=",
      "url": "_framework/System.IO.MemoryMappedFiles.inmcljd6il.wasm"
    },
    {
      "hash": "sha256-FBW6K4TORa24v2L639DPjf309NTGkrj0iIqiJaPqcYA=",
      "url": "_framework/System.IO.Pipelines.wn1erg3up3.wasm"
    },
    {
      "hash": "sha256-rJyVOKuibJTb0SU2g665M8xZpAVGem0hbS5MGUEujZA=",
      "url": "_framework/System.Linq.4o7mr2hts6.wasm"
    },
    {
      "hash": "sha256-ZBX4y7qqNxAG2D1pxGD0kUN3ABBDQEQP0PY+XFZ7Y1Q=",
      "url": "_framework/System.Linq.Async.ovfc2irvky.wasm"
    },
    {
      "hash": "sha256-T5dboKdZJ4Dz5kNl8HouOg9xPV1WLEeGCkrx24JWlx8=",
      "url": "_framework/System.Linq.Dynamic.Core.9i63prupac.wasm"
    },
    {
      "hash": "sha256-70E10mKGSc2ZjuY+a8dLoAATlPwFBLt1LovTvTANAoQ=",
      "url": "_framework/System.Linq.Expressions.1ksmobum18.wasm"
    },
    {
      "hash": "sha256-LE4aehOt63gR5BGnGpT5NI2uxWQn0aoBLVLrEoPJYkQ=",
      "url": "_framework/System.Linq.Queryable.034ey0i7ms.wasm"
    },
    {
      "hash": "sha256-8+ApALGRVAgh1shJG4LZ37QCqO00XtPad/v0F5qjSo0=",
      "url": "_framework/System.Memory.vd0gb4k3e1.wasm"
    },
    {
      "hash": "sha256-d/EVRT3gXoScecmfc3fFJQrwNHiJFYcOqIXR59Tr4U8=",
      "url": "_framework/System.Net.Http.98abav23v4.wasm"
    },
    {
      "hash": "sha256-VsWTEOyEbltVNWebWtzswCEfVLEN7seHoNS6agRLaJw=",
      "url": "_framework/System.Net.Primitives.e24bsgwgy3.wasm"
    },
    {
      "hash": "sha256-z/s7nA7w2NlFw+LM4Ifp+9eXz5B/T0p1QBOeWhL8sus=",
      "url": "_framework/System.ObjectModel.7637w0tsfc.wasm"
    },
    {
      "hash": "sha256-WcXhOJb11l7ZQBuEyzS5Xd8JUybrxa7JWtd4D4ruuo4=",
      "url": "_framework/System.Private.CoreLib.z5hn8f2vl1.wasm"
    },
    {
      "hash": "sha256-d4asEeri3JmukS7LY6x8lIAO5v5BdY6AcYRfY7KfnOU=",
      "url": "_framework/System.Private.Uri.16ro6hfxfj.wasm"
    },
    {
      "hash": "sha256-/GyVHMyYHC3dLt/ct1l+2TCUO6kHMxntRTAilGecYpA=",
      "url": "_framework/System.Private.Xml.Linq.kki09rcyvj.wasm"
    },
    {
      "hash": "sha256-dP5ds1LqZD8G78WB3Nv/mNeUk1KZ6EcYYSboBOu+5Fk=",
      "url": "_framework/System.Private.Xml.kc3eidhxuq.wasm"
    },
    {
      "hash": "sha256-1RCsGmwpH/0fcPJ53puU2l49aVQkYVpaNTipylpw24o=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.lsd0rgp8rq.wasm"
    },
    {
      "hash": "sha256-i/AGZR6aySfVT+coBhVi44bB2xyNIDgo8LSatlMAR9A=",
      "url": "_framework/System.Reflection.Emit.xx71l70eol.wasm"
    },
    {
      "hash": "sha256-MXZFYXTpIaBRZQSZGoBI5zFgQQGv3dl2M+CaBdn1poY=",
      "url": "_framework/System.Reflection.Metadata.hsz4wmrkkj.wasm"
    },
    {
      "hash": "sha256-AGiV5D0hD52zwyT0Qiv/2IzUuQCsjpV5q2cdQGUJK9Y=",
      "url": "_framework/System.Reflection.Primitives.kvhyhemwil.wasm"
    },
    {
      "hash": "sha256-ZmWIwLfDJBSY2oTfNoWXvCQ3pkLPPiGmnYJPBxDYz9M=",
      "url": "_framework/System.Runtime.InteropServices.6px0w8z6xi.wasm"
    },
    {
      "hash": "sha256-dr2zPg+11BQOd27TZPxcs18PqUREGUfAtTD9nRdz7sw=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.it9v611w20.wasm"
    },
    {
      "hash": "sha256-EQFV/X5fi+UF4pyjHvt9aKck8oHREQLeEeex/z5vamM=",
      "url": "_framework/System.Runtime.Serialization.Primitives.53mp5ktcqx.wasm"
    },
    {
      "hash": "sha256-HeM6qqmkIwt9XYwE4d+ba0ilP0e2J5FmwR+/rgYnuqk=",
      "url": "_framework/System.Runtime.p1u0nds3y8.wasm"
    },
    {
      "hash": "sha256-3anIZ/05UwtTHcjEwW+sGwko3P5lOMH9s1unDouwTBE=",
      "url": "_framework/System.Text.Encodings.Web.1jb665zgmj.wasm"
    },
    {
      "hash": "sha256-JFIsOWr0EQQ9MN9YNfTsSGzhvFREHqkEjA4Nv3Rw46k=",
      "url": "_framework/System.Text.Json.0dx5m94djz.wasm"
    },
    {
      "hash": "sha256-OgvgQruTSfWqUZewdPm9IFj3Kw3BYWsJTWB2wSriunc=",
      "url": "_framework/System.Text.RegularExpressions.e62jv1si39.wasm"
    },
    {
      "hash": "sha256-7HRpxfGj5sI1zrphvqiLFIXmqbTPdY2VDAdJm1HCNIw=",
      "url": "_framework/System.Threading.k290n83y9v.wasm"
    },
    {
      "hash": "sha256-gxdvvb/qoqZRhI7ZbjHGf6YR9X7icodr0bDYDmaA4pM=",
      "url": "_framework/System.Web.HttpUtility.77s7pdkp5q.wasm"
    },
    {
      "hash": "sha256-5claBNmyy8L12DFLS17Fh4SBiTjwhYts3ds7g8dX8Gc=",
      "url": "_framework/System.Xml.Linq.fnt4rzi185.wasm"
    },
    {
      "hash": "sha256-GFDeJPMpvuxG84bJZz3l/h9Zp3tHgIQlwd9lBwkQq9w=",
      "url": "_framework/System.Xml.XDocument.kpklgpeww4.wasm"
    },
    {
      "hash": "sha256-ULsvyv7nl6doDq/7V6xScA4P8bEScbsCcPFBlPnaS7Y=",
      "url": "_framework/VisNetwork.Blazor.4fraq2v2tj.wasm"
    },
    {
      "hash": "sha256-1S+fvvtX6poECtQWAmYOvLU9QpHMzobZ1jtyiSV3yi8=",
      "url": "_framework/Webassembly.11jah43ltp.wasm"
    },
    {
      "hash": "sha256-0m5N+JejuQ6ELXVtcbtmI6i+mGAJW/nVXIW1h1cDn+4=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-N+/jRbIsqVbSKyrJpXTfko/MbGFn4mYhGgK+pW+zQ7o=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-ldc3tVh9jo9M3X+6cd0F0Hfgw584wvTPlNfarATLeeQ=",
      "url": "_framework/dotnet.native.pzxu4ndvpw.js"
    },
    {
      "hash": "sha256-aecJhlCCzC/7BlOLPbi6+2BkokejaEZ8VlafZe3W6bc=",
      "url": "_framework/dotnet.native.vewqaawxgw.wasm"
    },
    {
      "hash": "sha256-yfXUv1l/B489E8p12JxUvxly0JvHL9CCsoZUDlfGH9c=",
      "url": "_framework/dotnet.runtime.drv0pr9n5o.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-NJ4abDVrzY4SiPfgeF/1Q9iQWlOiFA5u4geH5Fsnlhg=",
      "url": "_framework/netstandard.8fddx2tlyf.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
