self.assetsManifest = {
  "version": "SC7FVJ3+",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-wFQy3YZ5B8tDE7SVlSyd9DbC8XstJj9OyCDgmF82L18=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-z+X+dG5UyqqngwfUpSBk7xnunjafy3H7xTyJvw3Wp6k=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.puij8nbrfn.bundle.scp.css"
    },
    {
      "hash": "sha256-4WxQOlUyppqr8kLmbIRxdsocHLK9+f3eRHUQLKOtIMg=",
      "url": "_content/Siteswaps.Design.Fixtures/Siteswaps.Design.Fixtures.zvqgbbndl7.bundle.scp.css"
    },
    {
      "hash": "sha256-83Y3VqGBsLcjg5Utw3RDNG+auv6zqH4/PPwavI4QwIA=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingPage.razor.js"
    },
    {
      "hash": "sha256-o25z5uysRrF+qMuOVpDgeBLWXM3QNnTM7HO4fyvughg=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingThrowChipRow.razor.js"
    },
    {
      "hash": "sha256-rWswo2OSS3ji2dvr19DmobleNULxHesPHT25kC7AG48=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/Controls/DualRangeSlider.razor.js"
    },
    {
      "hash": "sha256-lh2MEHR0WF9aZGtQjFkebCbG2xjz2nxN7sGOrJapDtg=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/WizardPage.razor.js"
    },
    {
      "hash": "sha256-oIr4oEdzBG5eCZDd/S+zoVGIgJ7sHsnpi+z3aVPFpkc=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.k7dz5ec6ww.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-FpAhVpaw9UJbej/kZuE9tEhHu6MMEafaUZ/Hv8zf8nk=",
      "url": "_framework/Blazored.LocalStorage.e6jo5xh325.wasm"
    },
    {
      "hash": "sha256-e5XY5HktztH1G5D+ivPnTci++hOmoHdvObQeIJGYtNk=",
      "url": "_framework/ExhaustiveMatching.pvh0005fqb.wasm"
    },
    {
      "hash": "sha256-h+4NkBcGpMpryz24i57eMNFypbX1JxWaAF1ski048XQ=",
      "url": "_framework/Fluxor.Blazor.Web.rfh5ngd69g.wasm"
    },
    {
      "hash": "sha256-kmFR937gjSMYaugBUj01ICEI99F6HFm/q+iaZQMcH+E=",
      "url": "_framework/Fluxor.qq9ltcdeo2.wasm"
    },
    {
      "hash": "sha256-sTbr5pym1Z/C3mJ9yoP+XEATsUjw7lbIeHFON+h1sms=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.vw7x7bvjv1.wasm"
    },
    {
      "hash": "sha256-6UECy2Seqt0TrYfGKznaUSaEkHg/DiPeS6j94f/0Emg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.1qghzse0o4.wasm"
    },
    {
      "hash": "sha256-1wUnqknLQU2PSH4jVidE/J5FoPtd7ZPHSTaGXz2kIGQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.p44lysasre.wasm"
    },
    {
      "hash": "sha256-98be6TYt/IIO/kNCmGSXgkwNOQoSK2P94fmHHgiHSag=",
      "url": "_framework/Microsoft.AspNetCore.Components.f618fk1bcz.wasm"
    },
    {
      "hash": "sha256-l8xuMPBIytDlsVipKcny4/V0zbAjJckJxqbtWJcncis=",
      "url": "_framework/Microsoft.Extensions.Configuration.1ezpgdlkhk.wasm"
    },
    {
      "hash": "sha256-tm6S8Zxf8NzUrUVvtojqlYELJ/ect0nKZcx8Z7/iGkI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.awg3pcndbr.wasm"
    },
    {
      "hash": "sha256-yLeqa+N7rj/oA+/DuzjYNyfXd1ErXM5krBAglzElmtc=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.svkmtmeo3a.wasm"
    },
    {
      "hash": "sha256-aBvQ/hjvWjNCG089D7owVJIUPazDqP+mw4FMH7xN0Js=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.sfzkvj0etu.wasm"
    },
    {
      "hash": "sha256-yoCDYdbmgwNF7zyC4j+kYjiOsHN8NrtrlcMzgMp0r+A=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ezphr6lb26.wasm"
    },
    {
      "hash": "sha256-ssG8bY1HJgMre03jMxpw2cTZeX5yWoUzo6wzoVbFh6A=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.y4c9scxfut.wasm"
    },
    {
      "hash": "sha256-nF2Mh8a8iAFpwk+myaFmCEMYpbwTU9lxjBizwIrzaAw=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.0navi5hah5.wasm"
    },
    {
      "hash": "sha256-Eg9BbHp7owM8vj1uN9pIGgfaauETqGCijD5s7YHUfGo=",
      "url": "_framework/Microsoft.Extensions.Localization.28r9tszzb3.wasm"
    },
    {
      "hash": "sha256-uMeDMd0qS3mI/CdS7eCG6mKIYBTFA/uzTIQx3JtVGxs=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.szsqjwv7n8.wasm"
    },
    {
      "hash": "sha256-tHjpTT34vmou0TR7Hw5QXdH6ccEVRsTn/bfpDCIxAZs=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.suqzitaifq.wasm"
    },
    {
      "hash": "sha256-mhyfDfp1yETuDVueSidJxvvZcMFIEgObSnA7PCk7v0E=",
      "url": "_framework/Microsoft.Extensions.Logging.ydr71rn8ee.wasm"
    },
    {
      "hash": "sha256-UolvUgMqQR2M3WdFL+isNJskKUteBot2fb+zpbQS61Q=",
      "url": "_framework/Microsoft.Extensions.Options.62mscr8fzm.wasm"
    },
    {
      "hash": "sha256-7B+3tbywUzZZdZ8ljdqOP+i5mqr4dPis1C1f2Pf/D54=",
      "url": "_framework/Microsoft.Extensions.Primitives.c0eko127xd.wasm"
    },
    {
      "hash": "sha256-dTpn8r+xR2+7XDCQYr4b6TPjcHe5MaZLlIlYy/5hdMs=",
      "url": "_framework/Microsoft.Extensions.Validation.j23g6nh3wp.wasm"
    },
    {
      "hash": "sha256-VEB/4YtP9ySU4p2RtiTB5X0jKnexUUDF9ZO492ISjxI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.grtk0vdldj.wasm"
    },
    {
      "hash": "sha256-SXxZknLsjuJ2srBnwQWrVPOYNnagXR12cbBxU6/Lh7Q=",
      "url": "_framework/Microsoft.JSInterop.ha52dy43a4.wasm"
    },
    {
      "hash": "sha256-UamEnLWuzSCKHs8LW/OEXEunIg1ro0Gld08Z+h0V+fs=",
      "url": "_framework/MoreLinq.zrscm5zg2h.wasm"
    },
    {
      "hash": "sha256-4WmZt66HVX866CbnI6nrzfaSo7YabGCE6t/GeM62QYA=",
      "url": "_framework/Siteswap.Details.lzmqbamn76.wasm"
    },
    {
      "hash": "sha256-DrPY+YaCEuPJR7RiGCgbW3okxBcat9mVoFv2VLhDp8E=",
      "url": "_framework/Siteswaps.Components.mbhd8nr1z5.wasm"
    },
    {
      "hash": "sha256-u4UccPx5XQYFODAzZmUcM/+BzSRnSgXAzvWMZpoblU8=",
      "url": "_framework/Siteswaps.Design.Fixtures.ji2g9jof9e.wasm"
    },
    {
      "hash": "sha256-lG9lyFFPovBs+afVkAvOScUFHM+XaPgLFeyQ58VSKms=",
      "url": "_framework/Siteswaps.Generator.Core.onov9uc1um.wasm"
    },
    {
      "hash": "sha256-zMyzI0+8NuN+EG6v+lqYtJwoKSsDhRgEjk8wtQP/LEk=",
      "url": "_framework/Siteswaps.Generator.odivatool5.wasm"
    },
    {
      "hash": "sha256-fQVQd4VhHU17BE8XRWp9bTEmtzMTnYMSXNGDaaoT89U=",
      "url": "_framework/System.Collections.Concurrent.tsrjud422r.wasm"
    },
    {
      "hash": "sha256-Lvk3jA+7f4kO6tilt5piXsmgw8MtDC0sOwRO7UBfQZw=",
      "url": "_framework/System.Collections.Immutable.axcfqwnrzc.wasm"
    },
    {
      "hash": "sha256-vWkH812fP3sgf+mZpzFQOQ+F09FaR9DHaeJnH60qnfA=",
      "url": "_framework/System.Collections.NonGeneric.xjv4h8uxpi.wasm"
    },
    {
      "hash": "sha256-SKluIYEObIr3MGrb/7LqWLy931++T5kBGXCLsBMQhNo=",
      "url": "_framework/System.Collections.Specialized.sz7dxjcloe.wasm"
    },
    {
      "hash": "sha256-yuPIi0zMyWYkwpAauytGhKVsnB2rIXWr8MRazihS8H0=",
      "url": "_framework/System.Collections.mx1gmktg4u.wasm"
    },
    {
      "hash": "sha256-wuw0z1s1zHT+d30qCRx6uN1bT6gP8eGEMPHz4MLO20M=",
      "url": "_framework/System.ComponentModel.Annotations.y7u5vru56v.wasm"
    },
    {
      "hash": "sha256-BzMy7WnvFRTGMqR4K4u0aOJJ+fZDoDMR5C9EhPf8WI4=",
      "url": "_framework/System.ComponentModel.Primitives.xi5k0hdfpq.wasm"
    },
    {
      "hash": "sha256-une3gmYzIHe2u8Y+ls7B9IC8b2kfr+cqpQpAp9mZVTY=",
      "url": "_framework/System.ComponentModel.TypeConverter.yx88pwvef1.wasm"
    },
    {
      "hash": "sha256-i/TAe+IMHtWGhPUumwkXKc3xoLnQX+I+5Fw3V8LLtyI=",
      "url": "_framework/System.ComponentModel.t6sboglk0b.wasm"
    },
    {
      "hash": "sha256-Kcbupqra++7X2HTCCJxNHZR/rA3GboZ4K27UF8sdZFI=",
      "url": "_framework/System.Console.rv6gvlco9y.wasm"
    },
    {
      "hash": "sha256-Taalr868Tv45lU2sR7IJe5x4TQiS01P03vxTND/LRW4=",
      "url": "_framework/System.Core.pxxubl05v8.wasm"
    },
    {
      "hash": "sha256-lgqCb1hQsGLAeEOiMVMYLHWcKu+BzVzJAQUJ0r2iKmg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ymjszsjaex.wasm"
    },
    {
      "hash": "sha256-6XL5VInUwRobzjdR9yYjK4oJrCDrYTzafZw6KyTa5lI=",
      "url": "_framework/System.Diagnostics.TraceSource.ldw0j7aj6v.wasm"
    },
    {
      "hash": "sha256-U5qAkprjZIReWh7aDBlMaL8+EEFJYC6FQcPi6lhxEe4=",
      "url": "_framework/System.IO.MemoryMappedFiles.3smcki4lcx.wasm"
    },
    {
      "hash": "sha256-nbfbBTuTJvn6PNLWJcKFVtnfRNmkfIMTn6M4UhXCxxI=",
      "url": "_framework/System.IO.Pipelines.nvrht9ubsx.wasm"
    },
    {
      "hash": "sha256-0Ava9QEAZzvicw6huLI/Lwt3mkFEbYYYmYgqguN6Ov0=",
      "url": "_framework/System.Interactive.Async.47zcrvq9fy.wasm"
    },
    {
      "hash": "sha256-8rh0I8ytJ9YuI3d/UO+1qGTWyvfj8FWSzw+ujwASSUg=",
      "url": "_framework/System.Linq.Async.20jndnhczl.wasm"
    },
    {
      "hash": "sha256-d0sB5iw9WAkk5Cyl/8m0x53pd/ooTVj9fPGGzarM6sY=",
      "url": "_framework/System.Linq.AsyncEnumerable.fu3gcupm57.wasm"
    },
    {
      "hash": "sha256-C1CP17yev2rIvnfo/+4/NwsOrr2Ejg3d3i5xmdltfPU=",
      "url": "_framework/System.Linq.Dynamic.Core.hhsvivqloy.wasm"
    },
    {
      "hash": "sha256-LArJ+NrcGQAVilACZpU+MBXuu/l5dvFttyZp+7gqOS4=",
      "url": "_framework/System.Linq.Expressions.cc7gh052a6.wasm"
    },
    {
      "hash": "sha256-rfa2EYVOp8NYB5bGtCGRLeFlJWaPyZ+d7LecvKMyr+Y=",
      "url": "_framework/System.Linq.Queryable.dszy9l769c.wasm"
    },
    {
      "hash": "sha256-DigIHYaqRk5/TpUUgOtalX1WpNKIJpb7covrZDTzemE=",
      "url": "_framework/System.Linq.ynrgok5o37.wasm"
    },
    {
      "hash": "sha256-C0rdOlDLf57dEeRwKMvGtZTBJc3QdmkQ65eKYuU3ZVQ=",
      "url": "_framework/System.Memory.9f5as4lcku.wasm"
    },
    {
      "hash": "sha256-fNvyIywLihKxnIYOTgysFyoUU0O+zLXQMwJPSVugcO4=",
      "url": "_framework/System.ObjectModel.g5g7bb6yie.wasm"
    },
    {
      "hash": "sha256-k5/CaQm9dSqzyn2Xjpzv9j6RY07GijF3jaJSbKYQCxw=",
      "url": "_framework/System.Private.CoreLib.xfvxv9kzj6.wasm"
    },
    {
      "hash": "sha256-o+k3mblhnkUkUI8UvB4qZRVCjbu8plpL1qPF4Jrthic=",
      "url": "_framework/System.Private.DataContractSerialization.3c76nel714.wasm"
    },
    {
      "hash": "sha256-LdS8h8dv0SVBf4qjFn1A2vCW5lPGv2OarHqoA89HjHs=",
      "url": "_framework/System.Private.Uri.dwi24dzw3o.wasm"
    },
    {
      "hash": "sha256-xbKdktSbmo1prErlLyYBX5LZ5KVT62D/XkKI6ZEW2VU=",
      "url": "_framework/System.Private.Xml.Linq.5w4o8nwb4q.wasm"
    },
    {
      "hash": "sha256-zEquEBkAOxpoTQ/adwac+plahjCu2FKVLea1jQvOvDU=",
      "url": "_framework/System.Private.Xml.gnw290t7ph.wasm"
    },
    {
      "hash": "sha256-rSM+CsGpSMrlrNaw3/FbWLZb7spcMxoD2npDLo0wDz0=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.zkeejmp8ss.wasm"
    },
    {
      "hash": "sha256-c7dolFmsYKYAiIh3ONPXcK0mP9Kt9DHDUstUYpWx5d0=",
      "url": "_framework/System.Reflection.Emit.by69g7uv82.wasm"
    },
    {
      "hash": "sha256-oZSlmdb56H0p5A8gZHltLeNI6IrsA4lel+0PRYNrH2A=",
      "url": "_framework/System.Reflection.Metadata.9ui1vgoxch.wasm"
    },
    {
      "hash": "sha256-lafN96Qm9gssGJBzhBB/dre5zwdJE1MnuelXRXuiIBM=",
      "url": "_framework/System.Reflection.Primitives.5c2fug912w.wasm"
    },
    {
      "hash": "sha256-aqUjcsTrMb/soQlYR96axIjGo7GQ0Qv5zjRDbPwhtfg=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.uizjk7d97m.wasm"
    },
    {
      "hash": "sha256-RPC6IE6fmw7gM+Lk75oQHqos1V2kJXHGmhFvWEq0pIs=",
      "url": "_framework/System.Runtime.InteropServices.o5bh13zshk.wasm"
    },
    {
      "hash": "sha256-7ghKTsP6xwoGogSqlAvEKI0W4wyKTHq7tPSTt9YnRJo=",
      "url": "_framework/System.Runtime.Serialization.Xml.egy2eocwht.wasm"
    },
    {
      "hash": "sha256-/k8X8W9S1GupYZR+6kMgS8IyHdERN7lnE9q72n0e0Jk=",
      "url": "_framework/System.Runtime.mru9c8cpoq.wasm"
    },
    {
      "hash": "sha256-RU+AcPojtu3D+Eo3iKWbCbL7DFxuBOKQOgy2a6CbE9M=",
      "url": "_framework/System.Security.Cryptography.7datjp27kt.wasm"
    },
    {
      "hash": "sha256-Cd4D/R/P9B9Fcky8n0HwUp2Uk6E1V4D2UHhSYwP2ApM=",
      "url": "_framework/System.Text.Encodings.Web.dviq0bbl7p.wasm"
    },
    {
      "hash": "sha256-U9/6PwGwXbgVU/E+EKcwWorRGBpj3tpaxNk/OLc7mqY=",
      "url": "_framework/System.Text.Json.nr78ealqpr.wasm"
    },
    {
      "hash": "sha256-JnQkAhDCdinAJMvPoJq5e2F5/TZ9QjBpxxeQvXqLVUw=",
      "url": "_framework/System.Text.RegularExpressions.ml5a9en5vq.wasm"
    },
    {
      "hash": "sha256-5ko18XI+J/fVvQjcc7ATIC/VIK8KyQ9pp6La+L78KWs=",
      "url": "_framework/System.Threading.iaqg03a90q.wasm"
    },
    {
      "hash": "sha256-ANaiVspOfrgldK28ZpXzz9/EmjYLPF9rjZSHar4A76Y=",
      "url": "_framework/System.Xml.ReaderWriter.o65zt5qvki.wasm"
    },
    {
      "hash": "sha256-5H5aWNly3CXvfgT9xQgmep4E9haqEFQmuanoQcTqRoc=",
      "url": "_framework/System.Xml.XDocument.soa8946spf.wasm"
    },
    {
      "hash": "sha256-zOrKilij0kVnBL+fZDSyJYxYKRkVVLNRE+Xrx3oYyKs=",
      "url": "_framework/System.sgns93b1s8.wasm"
    },
    {
      "hash": "sha256-uTsVV+qbYMaSHuOJA+8uehV657M9oR2RmgmRhWAwjyk=",
      "url": "_framework/VisNetwork.Blazor.nwvjgzqmt4.wasm"
    },
    {
      "hash": "sha256-cwHqh6PqGH6SC8O0WUBBg+kdnDKTljGrXrKYE8ySWJo=",
      "url": "_framework/Webassembly.tgvtub993o.wasm"
    },
    {
      "hash": "sha256-xI+0AYBllEcYNYZeds+rgnJ8l9AF245ZsJTBUmm+7RU=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-XtzVQt8vk5A9LDqJQcUAK4ukFgix9LUQ0R4ojl3LkjU=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-cVbGAbr+gw0w+njlwGGn7Iyxtume2geYhDiumRLAe3M=",
      "url": "_framework/de/Siteswaps.Components.resources.puutlc7vs2.wasm"
    },
    {
      "hash": "sha256-yj3nTr7qN/s2e29cdsfxNuvAExB0hLnVveQD0e8BlTc=",
      "url": "_framework/de/Siteswaps.Generator.resources.im2qes7a07.wasm"
    },
    {
      "hash": "sha256-3fAqe0PODEIbDON4YCkrs0gasTcBQR1nZZsJsYfpeHM=",
      "url": "_framework/de/Webassembly.resources.toqrdx2bs9.wasm"
    },
    {
      "hash": "sha256-I54CPjluXBOp5JZFe6a00Xbb7kzK7QbH/xF7VXCHJT4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-pa64xOCP8wYJGYGEEPrR/d0zxvHDuhK4Q4GXnPNLXv8=",
      "url": "_framework/dotnet.native.97mp2wn9ci.js"
    },
    {
      "hash": "sha256-3bfskcb6xzSi/+3iyykC86HtIMTs2F79HJU0x+jEEoU=",
      "url": "_framework/dotnet.native.zs5341621e.wasm"
    },
    {
      "hash": "sha256-OjXfxsYRP/cygSpkbZTiu2yEQ4kgJ7vAxM82jpdKhQ8=",
      "url": "_framework/dotnet.runtime.u7u1yxqnoc.js"
    },
    {
      "hash": "sha256-5BfhzgOGQRjWj996AOsK8ZD97vgGxXD5Ucoy9h+kBH8=",
      "url": "_framework/icudt.g3en5r9teb.dat"
    },
    {
      "hash": "sha256-M8YDxGre22QSGD9Alt7YbD45OzHZC0pNyR+T22NEJCc=",
      "url": "_framework/netstandard.3oxrrebdos.wasm"
    },
    {
      "hash": "sha256-FiwvmTHh6RK0qtUUS2i5dh+OLlMw0UEge01a4o/iEYE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-gCw01Fy6keKtd8KJAutkwfkLjCTKoFwYY5Mc/FxbJyM=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-7+tPbT7PbyQ/jsoE2CnO4GZ6P2EWrzc1WLN/XbQMURg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YD6ZiRS11HFkE5RK4pa+gbg41BfrL4EajQZj9w5mnJA=",
      "url": "images/brand/fav-icon.svg"
    },
    {
      "hash": "sha256-U2muwLEwJsqjmTr6KQoRrr9sb3PCPIW6T6nTLz640Co=",
      "url": "images/brand/passing_zone_logo_all.svg"
    },
    {
      "hash": "sha256-eOdi7ENvIhNj2dWYeCGdYaVwe0N26k2+LHPWF1FrTVU=",
      "url": "images/brand/passing_zone_short_logo.svg"
    },
    {
      "hash": "sha256-tz6SDxMqEsAxYtUYPlLCS9Cnz980buGBmlS2y+9S1n4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-xZxX3HCGv1TLpxU7++crUesr3lmj99urJcP0hjSTGHY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-AqMy6ms/HeOdXV/Q6pY4gNPNQoU0LYrAb0YdM+OkIPA=",
      "url": "pwa-install.js"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-icJjkY+OZgTWDhLfFupwPt4NS/3HEV4Xht0V9Ygu5xU=",
      "url": "sw-registrator.js"
    }
  ]
};
