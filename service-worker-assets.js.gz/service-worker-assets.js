self.assetsManifest = {
  "version": "4PiHYoA0",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-4iH5CAMeCafnnWGF4fHKDlydRntLhLUzxM4I4JXXZPY=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-ztyW/TjAzgM5/whqE8k0eDY23jJKYLxWj8H+F9vRgg4=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2b0dqwc069.bundle.scp.css"
    },
    {
      "hash": "sha256-qM+h2CXKG3txteshpEi9iY7FSRjjhDh803R1Ysp0nXc=",
      "url": "_content/Siteswaps.Components/causalDiagramEditor.js"
    },
    {
      "hash": "sha256-hcITjztvy9yZi2DZPLHp6xy9A1SSZxk8c50WH8Ir7UY=",
      "url": "_content/Siteswaps.Components/design-tokens.css"
    },
    {
      "hash": "sha256-vZy98TD6JOjhvEJIWhrUmvp7Aw2t+mPX2FKa2uozxwM=",
      "url": "_content/Siteswaps.Components/designTokens.js"
    },
    {
      "hash": "sha256-jRZno/BK5QTs90k+T/bqCKbdSzefFEFTv6G+X5bP/6U=",
      "url": "_content/Siteswaps.Components/wizardProgress.js"
    },
    {
      "hash": "sha256-VMKWdzVPgKvRI18Bd/cI3KLP1Ou0rKUd61OKcWYsfx8=",
      "url": "_content/Siteswaps.Design.Fixtures/Siteswaps.Design.Fixtures.81szxd7lv9.bundle.scp.css"
    },
    {
      "hash": "sha256-0eZ8bsyh58PCQdqYpKI3Cr3KspxfY9KpNoQkq2iqMbg=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingPage.razor.js"
    },
    {
      "hash": "sha256-o25z5uysRrF+qMuOVpDgeBLWXM3QNnTM7HO4fyvughg=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingThrowChipRow.razor.js"
    },
    {
      "hash": "sha256-rWswo2OSS3ji2dvr19DmobleNULxHesPHT25kC7AG48=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/Controls/DualRangeSlider.razor.js"
    },
    {
      "hash": "sha256-htSyOxBsRpEdhBJldrERbU3Au369Bgr70M80MPbGZkg=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/WizardPage.razor.js"
    },
    {
      "hash": "sha256-7dAiJ0yDnRudvOkJKTlS8fEiOhiSOvf+HNN3Ofeu5/w=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.3ghnrjpfkb.bundle.scp.css"
    },
    {
      "hash": "sha256-rx7Zmsiva/rb0u6hZq60yjLV5sBbE1RWYL9vVXELlBM=",
      "url": "_content/Siteswaps.Jif.Components/Jif/JugglerLayoutEditor.razor.js"
    },
    {
      "hash": "sha256-X0r7t11NZdbSLyL7rIg3PJK85u5MKhtNb6I63HXBAfY=",
      "url": "_content/Siteswaps.Jif.Components/Jif/PassistAnimation.razor.js"
    },
    {
      "hash": "sha256-TocDypvRW+mpUE72IL3OJjp8C35KpCrHai2FMIllqXI=",
      "url": "_content/Siteswaps.Jif.Components/Siteswaps.Jif.Components.a617jdzwnq.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-FpAhVpaw9UJbej/kZuE9tEhHu6MMEafaUZ/Hv8zf8nk=",
      "url": "_framework/Blazored.LocalStorage.e6jo5xh325.wasm"
    },
    {
      "hash": "sha256-o1b3yxfgcP4tA9EN+q/CG+gL66X0EhpqilljRzNifZ8=",
      "url": "_framework/Dunet.73baggfv47.wasm"
    },
    {
      "hash": "sha256-e5XY5HktztH1G5D+ivPnTci++hOmoHdvObQeIJGYtNk=",
      "url": "_framework/ExhaustiveMatching.pvh0005fqb.wasm"
    },
    {
      "hash": "sha256-h+4NkBcGpMpryz24i57eMNFypbX1JxWaAF1ski048XQ=",
      "url": "_framework/Fluxor.Blazor.Web.rfh5ngd69g.wasm"
    },
    {
      "hash": "sha256-kmFR937gjSMYaugBUj01ICEI99F6HFm/q+iaZQMcH+E=",
      "url": "_framework/Fluxor.qq9ltcdeo2.wasm"
    },
    {
      "hash": "sha256-VcgcpVrEEK0iSYdOXHxrGxUobJrUo9GMpE27DpfPRvE=",
      "url": "_framework/Microsoft.AspNetCore.Components.9vbll5v9b4.wasm"
    },
    {
      "hash": "sha256-HjBthMK5iv73HoVtAmavL+FkZ76FCuZvfppg/LGN+O0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ex304uoiru.wasm"
    },
    {
      "hash": "sha256-ZtxJrRDJnHSHAQZsaCs8ikTMlTR0bRPch3H8/Fi1tjU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.6xfwzi0a0w.wasm"
    },
    {
      "hash": "sha256-5AymIgamcfO5YIEDMZmQDxIyjxUv2fursz7+TEaZWUM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.c83zogejmq.wasm"
    },
    {
      "hash": "sha256-gPYEp70ZmrxYlpLQw7hcxdmIbQ6vmluxLP8cfyoVWzo=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.gol3euaj3d.wasm"
    },
    {
      "hash": "sha256-WWSvU1JDlu+bkUC9QASXcgI6FBxn6nqhoi+goYlADAM=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.vaqacjgd1g.wasm"
    },
    {
      "hash": "sha256-it2ZhBMdA01nWq87yJoqpIh2zzD4VlW5qVKw+RKqPzw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q81lkglnox.wasm"
    },
    {
      "hash": "sha256-qprAZs11QknnNWs31jrjGmWxdUsXL6dZqWOH/WHzx8s=",
      "url": "_framework/Microsoft.Extensions.Configuration.e6rfa9mvfw.wasm"
    },
    {
      "hash": "sha256-gK/w5wyozNToJIhrtWuJxPhpg8Wa8zU6DftVf3nqtuc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.4fem6e2qsd.wasm"
    },
    {
      "hash": "sha256-jxo+s2tQ1ttnsvHv0GfKvqHrm+o+J/1F+8wsAPpKK20=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.nyfzzvsl5t.wasm"
    },
    {
      "hash": "sha256-2jQ7jiew9q+5Ke8i4fl+RClN1kk9u0ejlFTCHyIWg4Q=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.qz20gv1zfo.wasm"
    },
    {
      "hash": "sha256-jrG0mdpst0h6GpNSYnKL6CGIpoqljOAai75Nx5vueow=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.es1aeztafo.wasm"
    },
    {
      "hash": "sha256-UI/VpVCSQq1k6851I2nIRybFHWT0BJkz8pnAhtB+6fs=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.wgrd77yf8o.wasm"
    },
    {
      "hash": "sha256-UwtfUqtUsqs69oishFBQRYhYsK8xmEBPG3yrBs33LAs=",
      "url": "_framework/Microsoft.Extensions.Localization.38nzfjxcrh.wasm"
    },
    {
      "hash": "sha256-+VTzLD1lJCIJKH4EngYTEzdOJ4IuvqOvWuWxO22zuSc=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.x6oacwzaee.wasm"
    },
    {
      "hash": "sha256-NWvCnZePj4rXoxVRu/WaBZJgbknKn/Jn6NQHVjzojC8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ndqd6y4475.wasm"
    },
    {
      "hash": "sha256-TKvpCqOYjJqprbYn0eluY84Nj1RMWjYf/0zCA25CcB0=",
      "url": "_framework/Microsoft.Extensions.Logging.ksbw1ccply.wasm"
    },
    {
      "hash": "sha256-E5F7spkpp43og2uetXvYmKGrfQRsYW1laAzBbBVliOA=",
      "url": "_framework/Microsoft.Extensions.Options.5ya6i84xrk.wasm"
    },
    {
      "hash": "sha256-T1vljupCAO//4Au7oNib235dVE8HSLpLlZVTjVV5Gtg=",
      "url": "_framework/Microsoft.Extensions.Primitives.1cw8f4prw0.wasm"
    },
    {
      "hash": "sha256-SRTMKPr3Z5FePw1q6Wp9LtpCKZ5t4kA7iSPq1TUBwJg=",
      "url": "_framework/Microsoft.Extensions.Validation.ldu2yz4khd.wasm"
    },
    {
      "hash": "sha256-uHbb5b7vnE0GwS6Qws3ipDRp2E0UWNZ9G2JJrz8Au4U=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.kthmj8ue8z.wasm"
    },
    {
      "hash": "sha256-L+XFg0Ege3T53gM82kSYWMjBOAcR0kFl7pZPql5Lzfo=",
      "url": "_framework/Microsoft.JSInterop.x07x55u912.wasm"
    },
    {
      "hash": "sha256-D2aFO++J+d2eE9RGg/gBdqcJunjgMz7Yu3Hw2YCzBrE=",
      "url": "_framework/MoreLinq.5njmhjv7yd.wasm"
    },
    {
      "hash": "sha256-iXTsqnK1r8JnvVYZxq78jZl8/F1x8jxaQKJoa8d7CFc=",
      "url": "_framework/Siteswap.Details.dfq3gv2ng4.wasm"
    },
    {
      "hash": "sha256-6PosFk5kFKhqkNyJAlGaUy/yhDL+k45bNV9dwv4kbQw=",
      "url": "_framework/Siteswaps.Components.crlrgxqmvw.wasm"
    },
    {
      "hash": "sha256-mzQIy7EJo9vdHHWMLRpR/vy2lL1oYc2AG4WCjuOV5SM=",
      "url": "_framework/Siteswaps.Design.Fixtures.9jrsdtxiww.wasm"
    },
    {
      "hash": "sha256-W5XdIN/vJGX4SwYWg9t2ehMLc84hCRAn+nbCcKD93K0=",
      "url": "_framework/Siteswaps.Generator.5gui0st1kp.wasm"
    },
    {
      "hash": "sha256-QTm7G94F9o6I1hln/ATmg1iAqB0ZY4zPQ4KM3wRboEk=",
      "url": "_framework/Siteswaps.Generator.Core.3ngef367g7.wasm"
    },
    {
      "hash": "sha256-eAyYVcjkJizEBRuPq9yTcMkL2xsO5jgT5gwsufgusEs=",
      "url": "_framework/Siteswaps.Jif.Components.cngx9q5mk7.wasm"
    },
    {
      "hash": "sha256-TixZRk4PnxB2DUMwTTNDLYUr/jsRL/ncpEU0Bp1Q1Yo=",
      "url": "_framework/System.Collections.Concurrent.a51u7tp5ck.wasm"
    },
    {
      "hash": "sha256-pzkZduyOF+6ShPAWGpzJwvv5Dxk6J0e0f9A1kUED7D8=",
      "url": "_framework/System.Collections.Immutable.db0frjrtye.wasm"
    },
    {
      "hash": "sha256-cJV4NF4rBMS96Q4YIyrQ8qPVFKLxngr62N32jMXJ0Yo=",
      "url": "_framework/System.Collections.NonGeneric.wki67452tw.wasm"
    },
    {
      "hash": "sha256-3P+ooKUBt1R0yLCAkerAgpednh9meIWJD0gpeiuhR1k=",
      "url": "_framework/System.Collections.Specialized.k2okpcir6t.wasm"
    },
    {
      "hash": "sha256-SFj8JW9LJF9ylljrvNCsl3gNmwiV/dlp61fsZsdXBww=",
      "url": "_framework/System.Collections.ga56wypq3j.wasm"
    },
    {
      "hash": "sha256-mb/Vs/bFgIt4ObTuUv56hzjuaIJ2rSvQETwBD/+ZCew=",
      "url": "_framework/System.ComponentModel.Annotations.ldrgtdghx5.wasm"
    },
    {
      "hash": "sha256-hLhX0/KR6wUGLBIOoTF1xNsO23W5fKZV3CRhyKn4qOw=",
      "url": "_framework/System.ComponentModel.Primitives.8zxiky6il0.wasm"
    },
    {
      "hash": "sha256-bS2dDLo9MXpO7eqT9NQ4JADk7IJ9E0V5HEz+NhxgN0M=",
      "url": "_framework/System.ComponentModel.TypeConverter.9lb3oyz3om.wasm"
    },
    {
      "hash": "sha256-uVJJUT1DKu5RCowE7r2KWzwN9Q9Ep0+XYi0dg7lEvvs=",
      "url": "_framework/System.ComponentModel.dre8ytm0cg.wasm"
    },
    {
      "hash": "sha256-N8pmb8Rm9ZoytCeYXCPO4zTzLR7TPCrtGrg9x3A8YA0=",
      "url": "_framework/System.Console.nwuzzg08sh.wasm"
    },
    {
      "hash": "sha256-e53EUPgKw2vUiPP4k9m6w1MDzGSla5436cpr+BcdORQ=",
      "url": "_framework/System.Core.t6tnvkigcb.wasm"
    },
    {
      "hash": "sha256-GHTcYadAEz9pWSX1uxZ/75+8p0Rfo0jZZzLrUNxOVZg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.8gtcwh9zc1.wasm"
    },
    {
      "hash": "sha256-ZGzW6arpxE0iDuC2WYOHXrzVUEvCE3TMZNWcGVbe1GY=",
      "url": "_framework/System.Diagnostics.TraceSource.o32vwoluty.wasm"
    },
    {
      "hash": "sha256-b6myBzu6U3BNv0G6hIQPFEMvX6AE5+eQ2cxyouTTkbI=",
      "url": "_framework/System.IO.Compression.vwdgrh635t.wasm"
    },
    {
      "hash": "sha256-YSjGJR7KNhe9mwEde6CgtsXy+sI/+3MIiLv5m11FDOM=",
      "url": "_framework/System.IO.MemoryMappedFiles.7yhbkd8tdl.wasm"
    },
    {
      "hash": "sha256-hnDOQNTIH/aa1TzCygGWtOIjPNT7her4x77kuTUV3To=",
      "url": "_framework/System.IO.Pipelines.yeihgeljvz.wasm"
    },
    {
      "hash": "sha256-0Ava9QEAZzvicw6huLI/Lwt3mkFEbYYYmYgqguN6Ov0=",
      "url": "_framework/System.Interactive.Async.47zcrvq9fy.wasm"
    },
    {
      "hash": "sha256-sGparnMfqpfLHvTYdW8ZuZBWuaOXtezgtUSZG14Qwgg=",
      "url": "_framework/System.Linq.0k0m5pwjbk.wasm"
    },
    {
      "hash": "sha256-8rh0I8ytJ9YuI3d/UO+1qGTWyvfj8FWSzw+ujwASSUg=",
      "url": "_framework/System.Linq.Async.20jndnhczl.wasm"
    },
    {
      "hash": "sha256-CRLdphVt45b5tfH3r81vbBKawda5UKAXxx/mILzAxsE=",
      "url": "_framework/System.Linq.AsyncEnumerable.jpavixr2px.wasm"
    },
    {
      "hash": "sha256-C1CP17yev2rIvnfo/+4/NwsOrr2Ejg3d3i5xmdltfPU=",
      "url": "_framework/System.Linq.Dynamic.Core.hhsvivqloy.wasm"
    },
    {
      "hash": "sha256-Xjp7yG+aQhazM/vbGqeTaIVfslisQHpIcQDyuPvbVKE=",
      "url": "_framework/System.Linq.Expressions.exn6r3iofa.wasm"
    },
    {
      "hash": "sha256-5PfmmhKtivs443wM3LGt06KqPf3JVzAG85IePEsR2cM=",
      "url": "_framework/System.Linq.Queryable.sygcjpelfc.wasm"
    },
    {
      "hash": "sha256-h5pU3mTWpkmpbiZAz0b5eAKCb9ifi91k0YfrSRpQy54=",
      "url": "_framework/System.Memory.dfde2mpl0c.wasm"
    },
    {
      "hash": "sha256-FfXfdKn1yuGqdHX9FihMXNlNKG1RRAm0tmONG/uroKo=",
      "url": "_framework/System.ObjectModel.bsna8345og.wasm"
    },
    {
      "hash": "sha256-w8A4mABLHYQ6BxP1fqPBpgU9hg99ipNxaLr7O6bb0kU=",
      "url": "_framework/System.Private.CoreLib.778l4w22wd.wasm"
    },
    {
      "hash": "sha256-mfTggEgA7z0hM/iwZzTiKvgw2gGLFJRZxkmXY6vzZy4=",
      "url": "_framework/System.Private.DataContractSerialization.tfeybvnlbh.wasm"
    },
    {
      "hash": "sha256-PeeSJGeI5cpnOyRDanqzYj96dZQ/NMPVukvxh087TbA=",
      "url": "_framework/System.Private.Uri.h3s486y6px.wasm"
    },
    {
      "hash": "sha256-HNOwYF6es620CkXvvRKcQZ9vw5u4X/eZAn5yHct0BwA=",
      "url": "_framework/System.Private.Xml.Linq.kcepktnih7.wasm"
    },
    {
      "hash": "sha256-VWtfHX4IlEiFsjQQetqVGJYroLWGe8wm24s1O4XmAAI=",
      "url": "_framework/System.Private.Xml.zy8hxr05oi.wasm"
    },
    {
      "hash": "sha256-Eluvu6znuoPcNTgFgRvvWfcoBgruXf0L3kPwEb3JAcQ=",
      "url": "_framework/System.Reflection.Emit.6ejrimubht.wasm"
    },
    {
      "hash": "sha256-InR/3W9Vq5ww6et+c9fItesWAkCnmuk5rle4xKwtd9o=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.yg0n28vngf.wasm"
    },
    {
      "hash": "sha256-Ljxnmo3oqw7+HKdZP7B1SJHqbd3N4pwW+uxIZokasCQ=",
      "url": "_framework/System.Reflection.Metadata.28jqwoazhm.wasm"
    },
    {
      "hash": "sha256-WPHCRvHZZa0dZ20iiUINLcLT41K+zNqqX5IG6yC9KLw=",
      "url": "_framework/System.Reflection.Primitives.sr39afldzp.wasm"
    },
    {
      "hash": "sha256-y8Nk1Qaz3kKH/VnddTuEDJK4BnP+ffnyTSzRA+Vt3XI=",
      "url": "_framework/System.Runtime.5wvrqud0q8.wasm"
    },
    {
      "hash": "sha256-KCr6EFEHkNObycfsKVPt4enUoGUREo0CYSKIn8SX3mk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.0mcgud8ejr.wasm"
    },
    {
      "hash": "sha256-j/P89v2MxGvt+Y4i4ajPrcb9yjdm5kbgTypp6vcLK2U=",
      "url": "_framework/System.Runtime.InteropServices.h45u78t9gg.wasm"
    },
    {
      "hash": "sha256-J9MGoq99sjeMJlp7M4JakT4e5S2jvKVXzP4rhiWSqWA=",
      "url": "_framework/System.Runtime.Numerics.tbftqocvoh.wasm"
    },
    {
      "hash": "sha256-UoyroVVSRKL1FRnfAh9Farkuzsi8NCXN4TpFcsf3uIE=",
      "url": "_framework/System.Runtime.Serialization.Primitives.2f94r0nco8.wasm"
    },
    {
      "hash": "sha256-gNTXU8f+3PqOd15gcoacq+88LbBXHStCRJtneGS0cgY=",
      "url": "_framework/System.Runtime.Serialization.Xml.kf1lpe8cs9.wasm"
    },
    {
      "hash": "sha256-ixQ7Y96EUtew/0CMYcfe3JMJxDMSCW1WtCS9EkFPT6Q=",
      "url": "_framework/System.Security.Cryptography.9v5btb3qdh.wasm"
    },
    {
      "hash": "sha256-rqjFLrnk9t9yR/6PlZ/0P/bjFQvI5AI4n7JLCuBOsgM=",
      "url": "_framework/System.Text.Encodings.Web.ijf0asmnsf.wasm"
    },
    {
      "hash": "sha256-T6hfdsDQlWDv/Vx9kst3bA5+DxO2DEqMIuPdfHe9MAA=",
      "url": "_framework/System.Text.Json.d1kxc6hci2.wasm"
    },
    {
      "hash": "sha256-QPDrd5NzCk0m2OXamVUQ19qjKZQIZp2q4dETbbxaJc8=",
      "url": "_framework/System.Text.RegularExpressions.47wd8xiv56.wasm"
    },
    {
      "hash": "sha256-/LMh+EoDZXm5LdevXgpB8Qwg0hg5rgLahBunC1S9/qA=",
      "url": "_framework/System.Threading.k0zv9062m5.wasm"
    },
    {
      "hash": "sha256-LqDGFyiaB+6nZwdX7KzCKJgLvJ0yCE3ToLKQnK7BJmk=",
      "url": "_framework/System.Xml.ReaderWriter.utao3818lg.wasm"
    },
    {
      "hash": "sha256-EbWWYVOWB1t/LmVZD2Jh8dqVomnqr9nSekbiEJUyqZ8=",
      "url": "_framework/System.Xml.XDocument.ljl00ykpvj.wasm"
    },
    {
      "hash": "sha256-deV0DUTbY0DlBTfQncbI/Sg+Eb7dON2nXbyolKeyvTM=",
      "url": "_framework/System.n1lgwvdeih.wasm"
    },
    {
      "hash": "sha256-uTsVV+qbYMaSHuOJA+8uehV657M9oR2RmgmRhWAwjyk=",
      "url": "_framework/VisNetwork.Blazor.nwvjgzqmt4.wasm"
    },
    {
      "hash": "sha256-qFgxz2eK1lG8exDkDERYWDHAUy3ptoMlg4JKpMGmf54=",
      "url": "_framework/Webassembly.sztugt577l.wasm"
    },
    {
      "hash": "sha256-h5BykV52WXDQQYSSeQYmnw2hLafu9fcAvqRQUCbYr2Q=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wK4d75N7t8qDNB2PXHAvew2pZnWUklx2XJPmmlACEsE=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-JNiD6c4OnZQNFMPkFh5MVZujKSlQyeOpkyE42T8o92o=",
      "url": "_framework/de/Siteswaps.Components.resources.w9c84x8zt0.wasm"
    },
    {
      "hash": "sha256-hCLzF0WGd6KFwX8EW4ht1oTd0CXKwY8TGU6U3Zq7gwA=",
      "url": "_framework/de/Siteswaps.Generator.resources.kuftwamwyx.wasm"
    },
    {
      "hash": "sha256-ZwERDP+pvfz8hVF/1ZcUxtMocNtY9EG9fHq0abtAE04=",
      "url": "_framework/de/Siteswaps.Jif.Components.resources.h24crx0lge.wasm"
    },
    {
      "hash": "sha256-X1TFo4HktqBtnsOokfegECfO2wRN3hGIDh29naxjeBM=",
      "url": "_framework/de/Webassembly.resources.rpcw03qv9x.wasm"
    },
    {
      "hash": "sha256-TM4JrfUtZlsrkv2OfDFFiRCxS8SpgWe95NgYZp5YMUY=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-Ur8XxyZ4L3eGVBZWlm0mGpmQcW72FCZ3dpG/GQttdKs=",
      "url": "_framework/dotnet.native.ec7us1wehk.wasm"
    },
    {
      "hash": "sha256-LC9CHaXa3ZR3i52oIPqBxnavGNPE6CrNtebtvnvIqaQ=",
      "url": "_framework/dotnet.native.s4szq374gb.js"
    },
    {
      "hash": "sha256-FsddKLA9kAdfVKI0lZFago0rrc/gNe0yrVtP7+D/qN0=",
      "url": "_framework/dotnet.runtime.uyfhwbfd13.js"
    },
    {
      "hash": "sha256-5BfhzgOGQRjWj996AOsK8ZD97vgGxXD5Ucoy9h+kBH8=",
      "url": "_framework/icudt.g3en5r9teb.dat"
    },
    {
      "hash": "sha256-25KOKTzJzLBcisDJ9zONy+oV6g6XQLG5oYaKZGWQ1ko=",
      "url": "_framework/netstandard.fbgtrktclb.wasm"
    },
    {
      "hash": "sha256-DiaxlB1RyaCCvqevGR/K0r88bw50WwTaI2W3uDHcdwk=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-gCw01Fy6keKtd8KJAutkwfkLjCTKoFwYY5Mc/FxbJyM=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-7+tPbT7PbyQ/jsoE2CnO4GZ6P2EWrzc1WLN/XbQMURg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YD6ZiRS11HFkE5RK4pa+gbg41BfrL4EajQZj9w5mnJA=",
      "url": "images/brand/fav-icon.svg"
    },
    {
      "hash": "sha256-U2muwLEwJsqjmTr6KQoRrr9sb3PCPIW6T6nTLz640Co=",
      "url": "images/brand/passing_zone_logo_all.svg"
    },
    {
      "hash": "sha256-eOdi7ENvIhNj2dWYeCGdYaVwe0N26k2+LHPWF1FrTVU=",
      "url": "images/brand/passing_zone_short_logo.svg"
    },
    {
      "hash": "sha256-tubP82ueEf1/NiuNnVdUxZ8WCJIj5CAoCVGoanS6nt0=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-F6iOAHENKExyTbkogCq1KU6iAcjPU62R2rDLUJlvutk=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-3jWlqqSCGZoiCgf11GFXEY4of9015Dtru0iJ14WEj1M=",
      "url": "navMenu.js"
    },
    {
      "hash": "sha256-AqMy6ms/HeOdXV/Q6pY4gNPNQoU0LYrAb0YdM+OkIPA=",
      "url": "pwa-install.js"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-7IjkH4FcDOEif7UuJjRQyup2ul8mk3RvKtRu44BeHM0=",
      "url": "sw-registrator.js"
    }
  ]
};
