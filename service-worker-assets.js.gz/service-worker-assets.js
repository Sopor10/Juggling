self.assetsManifest = {
  "version": "3vV6ro6W",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-wFQy3YZ5B8tDE7SVlSyd9DbC8XstJj9OyCDgmF82L18=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-z+X+dG5UyqqngwfUpSBk7xnunjafy3H7xTyJvw3Wp6k=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.puij8nbrfn.bundle.scp.css"
    },
    {
      "hash": "sha256-4WxQOlUyppqr8kLmbIRxdsocHLK9+f3eRHUQLKOtIMg=",
      "url": "_content/Siteswaps.Design.Fixtures/Siteswaps.Design.Fixtures.zvqgbbndl7.bundle.scp.css"
    },
    {
      "hash": "sha256-0eZ8bsyh58PCQdqYpKI3Cr3KspxfY9KpNoQkq2iqMbg=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingPage.razor.js"
    },
    {
      "hash": "sha256-o25z5uysRrF+qMuOVpDgeBLWXM3QNnTM7HO4fyvughg=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingThrowChipRow.razor.js"
    },
    {
      "hash": "sha256-rWswo2OSS3ji2dvr19DmobleNULxHesPHT25kC7AG48=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/Controls/DualRangeSlider.razor.js"
    },
    {
      "hash": "sha256-htSyOxBsRpEdhBJldrERbU3Au369Bgr70M80MPbGZkg=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/WizardPage.razor.js"
    },
    {
      "hash": "sha256-oIr4oEdzBG5eCZDd/S+zoVGIgJ7sHsnpi+z3aVPFpkc=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.k7dz5ec6ww.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-FpAhVpaw9UJbej/kZuE9tEhHu6MMEafaUZ/Hv8zf8nk=",
      "url": "_framework/Blazored.LocalStorage.e6jo5xh325.wasm"
    },
    {
      "hash": "sha256-e5XY5HktztH1G5D+ivPnTci++hOmoHdvObQeIJGYtNk=",
      "url": "_framework/ExhaustiveMatching.pvh0005fqb.wasm"
    },
    {
      "hash": "sha256-h+4NkBcGpMpryz24i57eMNFypbX1JxWaAF1ski048XQ=",
      "url": "_framework/Fluxor.Blazor.Web.rfh5ngd69g.wasm"
    },
    {
      "hash": "sha256-kmFR937gjSMYaugBUj01ICEI99F6HFm/q+iaZQMcH+E=",
      "url": "_framework/Fluxor.qq9ltcdeo2.wasm"
    },
    {
      "hash": "sha256-HjBthMK5iv73HoVtAmavL+FkZ76FCuZvfppg/LGN+O0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ex304uoiru.wasm"
    },
    {
      "hash": "sha256-Dw+Qd/l/8Sb7ghkdTrnq8qRfHq0ZNhXUDITXFFsA8N8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.tlec8dgrif.wasm"
    },
    {
      "hash": "sha256-5AymIgamcfO5YIEDMZmQDxIyjxUv2fursz7+TEaZWUM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.c83zogejmq.wasm"
    },
    {
      "hash": "sha256-dqeg66msIT1bHsT1o5yzyzcDe+JON7HkVz8mJU2fRh8=",
      "url": "_framework/Microsoft.AspNetCore.Components.umglgwpxw9.wasm"
    },
    {
      "hash": "sha256-gPYEp70ZmrxYlpLQw7hcxdmIbQ6vmluxLP8cfyoVWzo=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.gol3euaj3d.wasm"
    },
    {
      "hash": "sha256-WWSvU1JDlu+bkUC9QASXcgI6FBxn6nqhoi+goYlADAM=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.vaqacjgd1g.wasm"
    },
    {
      "hash": "sha256-it2ZhBMdA01nWq87yJoqpIh2zzD4VlW5qVKw+RKqPzw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q81lkglnox.wasm"
    },
    {
      "hash": "sha256-qprAZs11QknnNWs31jrjGmWxdUsXL6dZqWOH/WHzx8s=",
      "url": "_framework/Microsoft.Extensions.Configuration.e6rfa9mvfw.wasm"
    },
    {
      "hash": "sha256-gK/w5wyozNToJIhrtWuJxPhpg8Wa8zU6DftVf3nqtuc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.4fem6e2qsd.wasm"
    },
    {
      "hash": "sha256-jxo+s2tQ1ttnsvHv0GfKvqHrm+o+J/1F+8wsAPpKK20=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.nyfzzvsl5t.wasm"
    },
    {
      "hash": "sha256-2jQ7jiew9q+5Ke8i4fl+RClN1kk9u0ejlFTCHyIWg4Q=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.qz20gv1zfo.wasm"
    },
    {
      "hash": "sha256-jrG0mdpst0h6GpNSYnKL6CGIpoqljOAai75Nx5vueow=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.es1aeztafo.wasm"
    },
    {
      "hash": "sha256-UI/VpVCSQq1k6851I2nIRybFHWT0BJkz8pnAhtB+6fs=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.wgrd77yf8o.wasm"
    },
    {
      "hash": "sha256-UwtfUqtUsqs69oishFBQRYhYsK8xmEBPG3yrBs33LAs=",
      "url": "_framework/Microsoft.Extensions.Localization.38nzfjxcrh.wasm"
    },
    {
      "hash": "sha256-+VTzLD1lJCIJKH4EngYTEzdOJ4IuvqOvWuWxO22zuSc=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.x6oacwzaee.wasm"
    },
    {
      "hash": "sha256-NWvCnZePj4rXoxVRu/WaBZJgbknKn/Jn6NQHVjzojC8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ndqd6y4475.wasm"
    },
    {
      "hash": "sha256-TKvpCqOYjJqprbYn0eluY84Nj1RMWjYf/0zCA25CcB0=",
      "url": "_framework/Microsoft.Extensions.Logging.ksbw1ccply.wasm"
    },
    {
      "hash": "sha256-E5F7spkpp43og2uetXvYmKGrfQRsYW1laAzBbBVliOA=",
      "url": "_framework/Microsoft.Extensions.Options.5ya6i84xrk.wasm"
    },
    {
      "hash": "sha256-T1vljupCAO//4Au7oNib235dVE8HSLpLlZVTjVV5Gtg=",
      "url": "_framework/Microsoft.Extensions.Primitives.1cw8f4prw0.wasm"
    },
    {
      "hash": "sha256-SRTMKPr3Z5FePw1q6Wp9LtpCKZ5t4kA7iSPq1TUBwJg=",
      "url": "_framework/Microsoft.Extensions.Validation.ldu2yz4khd.wasm"
    },
    {
      "hash": "sha256-uHbb5b7vnE0GwS6Qws3ipDRp2E0UWNZ9G2JJrz8Au4U=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.kthmj8ue8z.wasm"
    },
    {
      "hash": "sha256-L+XFg0Ege3T53gM82kSYWMjBOAcR0kFl7pZPql5Lzfo=",
      "url": "_framework/Microsoft.JSInterop.x07x55u912.wasm"
    },
    {
      "hash": "sha256-D2aFO++J+d2eE9RGg/gBdqcJunjgMz7Yu3Hw2YCzBrE=",
      "url": "_framework/MoreLinq.5njmhjv7yd.wasm"
    },
    {
      "hash": "sha256-OXPufkguTeogW4qrRJLTE5ba4Z+RZRpgZ5r4wRLF7gg=",
      "url": "_framework/Siteswap.Details.psjgz2ido7.wasm"
    },
    {
      "hash": "sha256-gTNHR1N7YfMwcoJpLenATU6m96xF0RvEhG0QElBnUpw=",
      "url": "_framework/Siteswaps.Components.pac5m8jxyd.wasm"
    },
    {
      "hash": "sha256-B7zfTfhGgXpvtVvDxXw65ZuYokCLONdUGuV89eVCZKQ=",
      "url": "_framework/Siteswaps.Design.Fixtures.zxsqjxdnfn.wasm"
    },
    {
      "hash": "sha256-6N9P5VyxmEBUkjmzU9SWwIPEhypxzzRZ30yQhfoMZ9g=",
      "url": "_framework/Siteswaps.Generator.Core.0ymb7w7l3u.wasm"
    },
    {
      "hash": "sha256-s6k51qz2GOrTnpMDB9DmWez3ovOSP6w7MnNPhMj0Q2E=",
      "url": "_framework/Siteswaps.Generator.dw0jjqbu8t.wasm"
    },
    {
      "hash": "sha256-TixZRk4PnxB2DUMwTTNDLYUr/jsRL/ncpEU0Bp1Q1Yo=",
      "url": "_framework/System.Collections.Concurrent.a51u7tp5ck.wasm"
    },
    {
      "hash": "sha256-4GUMfnuEo6F4m35vASWxFL4NpJhGrE6enaKyBHGYI2A=",
      "url": "_framework/System.Collections.Immutable.4nmlkjkcef.wasm"
    },
    {
      "hash": "sha256-cJV4NF4rBMS96Q4YIyrQ8qPVFKLxngr62N32jMXJ0Yo=",
      "url": "_framework/System.Collections.NonGeneric.wki67452tw.wasm"
    },
    {
      "hash": "sha256-3P+ooKUBt1R0yLCAkerAgpednh9meIWJD0gpeiuhR1k=",
      "url": "_framework/System.Collections.Specialized.k2okpcir6t.wasm"
    },
    {
      "hash": "sha256-ALDb3fhxwWLBze01ZHGTzpFBkoCVxMmX1KBCHDmegJE=",
      "url": "_framework/System.Collections.g0jvuknzv7.wasm"
    },
    {
      "hash": "sha256-mb/Vs/bFgIt4ObTuUv56hzjuaIJ2rSvQETwBD/+ZCew=",
      "url": "_framework/System.ComponentModel.Annotations.ldrgtdghx5.wasm"
    },
    {
      "hash": "sha256-hLhX0/KR6wUGLBIOoTF1xNsO23W5fKZV3CRhyKn4qOw=",
      "url": "_framework/System.ComponentModel.Primitives.8zxiky6il0.wasm"
    },
    {
      "hash": "sha256-bS2dDLo9MXpO7eqT9NQ4JADk7IJ9E0V5HEz+NhxgN0M=",
      "url": "_framework/System.ComponentModel.TypeConverter.9lb3oyz3om.wasm"
    },
    {
      "hash": "sha256-uVJJUT1DKu5RCowE7r2KWzwN9Q9Ep0+XYi0dg7lEvvs=",
      "url": "_framework/System.ComponentModel.dre8ytm0cg.wasm"
    },
    {
      "hash": "sha256-N8pmb8Rm9ZoytCeYXCPO4zTzLR7TPCrtGrg9x3A8YA0=",
      "url": "_framework/System.Console.nwuzzg08sh.wasm"
    },
    {
      "hash": "sha256-e53EUPgKw2vUiPP4k9m6w1MDzGSla5436cpr+BcdORQ=",
      "url": "_framework/System.Core.t6tnvkigcb.wasm"
    },
    {
      "hash": "sha256-GHTcYadAEz9pWSX1uxZ/75+8p0Rfo0jZZzLrUNxOVZg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.8gtcwh9zc1.wasm"
    },
    {
      "hash": "sha256-ZGzW6arpxE0iDuC2WYOHXrzVUEvCE3TMZNWcGVbe1GY=",
      "url": "_framework/System.Diagnostics.TraceSource.o32vwoluty.wasm"
    },
    {
      "hash": "sha256-b6myBzu6U3BNv0G6hIQPFEMvX6AE5+eQ2cxyouTTkbI=",
      "url": "_framework/System.IO.Compression.vwdgrh635t.wasm"
    },
    {
      "hash": "sha256-YSjGJR7KNhe9mwEde6CgtsXy+sI/+3MIiLv5m11FDOM=",
      "url": "_framework/System.IO.MemoryMappedFiles.7yhbkd8tdl.wasm"
    },
    {
      "hash": "sha256-hnDOQNTIH/aa1TzCygGWtOIjPNT7her4x77kuTUV3To=",
      "url": "_framework/System.IO.Pipelines.yeihgeljvz.wasm"
    },
    {
      "hash": "sha256-0Ava9QEAZzvicw6huLI/Lwt3mkFEbYYYmYgqguN6Ov0=",
      "url": "_framework/System.Interactive.Async.47zcrvq9fy.wasm"
    },
    {
      "hash": "sha256-sGparnMfqpfLHvTYdW8ZuZBWuaOXtezgtUSZG14Qwgg=",
      "url": "_framework/System.Linq.0k0m5pwjbk.wasm"
    },
    {
      "hash": "sha256-8rh0I8ytJ9YuI3d/UO+1qGTWyvfj8FWSzw+ujwASSUg=",
      "url": "_framework/System.Linq.Async.20jndnhczl.wasm"
    },
    {
      "hash": "sha256-CRLdphVt45b5tfH3r81vbBKawda5UKAXxx/mILzAxsE=",
      "url": "_framework/System.Linq.AsyncEnumerable.jpavixr2px.wasm"
    },
    {
      "hash": "sha256-C1CP17yev2rIvnfo/+4/NwsOrr2Ejg3d3i5xmdltfPU=",
      "url": "_framework/System.Linq.Dynamic.Core.hhsvivqloy.wasm"
    },
    {
      "hash": "sha256-Xjp7yG+aQhazM/vbGqeTaIVfslisQHpIcQDyuPvbVKE=",
      "url": "_framework/System.Linq.Expressions.exn6r3iofa.wasm"
    },
    {
      "hash": "sha256-5PfmmhKtivs443wM3LGt06KqPf3JVzAG85IePEsR2cM=",
      "url": "_framework/System.Linq.Queryable.sygcjpelfc.wasm"
    },
    {
      "hash": "sha256-79sXRg2IgHqYYw38Cwe38l7NBiucIqWcZGgVySaHV20=",
      "url": "_framework/System.Memory.l351s2b3s6.wasm"
    },
    {
      "hash": "sha256-FfXfdKn1yuGqdHX9FihMXNlNKG1RRAm0tmONG/uroKo=",
      "url": "_framework/System.ObjectModel.bsna8345og.wasm"
    },
    {
      "hash": "sha256-xom4kiNA8ZfTXiirXWh2e1cmr4ivtPSeLNDBE3EVRfg=",
      "url": "_framework/System.Private.CoreLib.ebujan1lyy.wasm"
    },
    {
      "hash": "sha256-mfTggEgA7z0hM/iwZzTiKvgw2gGLFJRZxkmXY6vzZy4=",
      "url": "_framework/System.Private.DataContractSerialization.tfeybvnlbh.wasm"
    },
    {
      "hash": "sha256-PeeSJGeI5cpnOyRDanqzYj96dZQ/NMPVukvxh087TbA=",
      "url": "_framework/System.Private.Uri.h3s486y6px.wasm"
    },
    {
      "hash": "sha256-HNOwYF6es620CkXvvRKcQZ9vw5u4X/eZAn5yHct0BwA=",
      "url": "_framework/System.Private.Xml.Linq.kcepktnih7.wasm"
    },
    {
      "hash": "sha256-VWtfHX4IlEiFsjQQetqVGJYroLWGe8wm24s1O4XmAAI=",
      "url": "_framework/System.Private.Xml.zy8hxr05oi.wasm"
    },
    {
      "hash": "sha256-Eluvu6znuoPcNTgFgRvvWfcoBgruXf0L3kPwEb3JAcQ=",
      "url": "_framework/System.Reflection.Emit.6ejrimubht.wasm"
    },
    {
      "hash": "sha256-InR/3W9Vq5ww6et+c9fItesWAkCnmuk5rle4xKwtd9o=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.yg0n28vngf.wasm"
    },
    {
      "hash": "sha256-Ljxnmo3oqw7+HKdZP7B1SJHqbd3N4pwW+uxIZokasCQ=",
      "url": "_framework/System.Reflection.Metadata.28jqwoazhm.wasm"
    },
    {
      "hash": "sha256-WPHCRvHZZa0dZ20iiUINLcLT41K+zNqqX5IG6yC9KLw=",
      "url": "_framework/System.Reflection.Primitives.sr39afldzp.wasm"
    },
    {
      "hash": "sha256-KCr6EFEHkNObycfsKVPt4enUoGUREo0CYSKIn8SX3mk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.0mcgud8ejr.wasm"
    },
    {
      "hash": "sha256-j/P89v2MxGvt+Y4i4ajPrcb9yjdm5kbgTypp6vcLK2U=",
      "url": "_framework/System.Runtime.InteropServices.h45u78t9gg.wasm"
    },
    {
      "hash": "sha256-gNTXU8f+3PqOd15gcoacq+88LbBXHStCRJtneGS0cgY=",
      "url": "_framework/System.Runtime.Serialization.Xml.kf1lpe8cs9.wasm"
    },
    {
      "hash": "sha256-7vpmPnLUU1LklVE1+s4YJ/aAGZ2botOg2szo21CVLLg=",
      "url": "_framework/System.Runtime.ycgd5zectc.wasm"
    },
    {
      "hash": "sha256-ixQ7Y96EUtew/0CMYcfe3JMJxDMSCW1WtCS9EkFPT6Q=",
      "url": "_framework/System.Security.Cryptography.9v5btb3qdh.wasm"
    },
    {
      "hash": "sha256-rqjFLrnk9t9yR/6PlZ/0P/bjFQvI5AI4n7JLCuBOsgM=",
      "url": "_framework/System.Text.Encodings.Web.ijf0asmnsf.wasm"
    },
    {
      "hash": "sha256-zCH4S88cEA+qgGMsJJddb+mbvFaRm0q2CJpnMOPxpOg=",
      "url": "_framework/System.Text.Json.sa3abtrm6n.wasm"
    },
    {
      "hash": "sha256-QPDrd5NzCk0m2OXamVUQ19qjKZQIZp2q4dETbbxaJc8=",
      "url": "_framework/System.Text.RegularExpressions.47wd8xiv56.wasm"
    },
    {
      "hash": "sha256-/LMh+EoDZXm5LdevXgpB8Qwg0hg5rgLahBunC1S9/qA=",
      "url": "_framework/System.Threading.k0zv9062m5.wasm"
    },
    {
      "hash": "sha256-LqDGFyiaB+6nZwdX7KzCKJgLvJ0yCE3ToLKQnK7BJmk=",
      "url": "_framework/System.Xml.ReaderWriter.utao3818lg.wasm"
    },
    {
      "hash": "sha256-EbWWYVOWB1t/LmVZD2Jh8dqVomnqr9nSekbiEJUyqZ8=",
      "url": "_framework/System.Xml.XDocument.ljl00ykpvj.wasm"
    },
    {
      "hash": "sha256-deV0DUTbY0DlBTfQncbI/Sg+Eb7dON2nXbyolKeyvTM=",
      "url": "_framework/System.n1lgwvdeih.wasm"
    },
    {
      "hash": "sha256-uTsVV+qbYMaSHuOJA+8uehV657M9oR2RmgmRhWAwjyk=",
      "url": "_framework/VisNetwork.Blazor.nwvjgzqmt4.wasm"
    },
    {
      "hash": "sha256-3BGvd7zOWNSbBmUGcnnX8iMSvD09t25Z+0H1Sv939q0=",
      "url": "_framework/Webassembly.4okee0gr2b.wasm"
    },
    {
      "hash": "sha256-h5BykV52WXDQQYSSeQYmnw2hLafu9fcAvqRQUCbYr2Q=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wK4d75N7t8qDNB2PXHAvew2pZnWUklx2XJPmmlACEsE=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-HZudqQRLsVk+KSsbrNBNVtYYxvT7ugzIbyHgGI3QhEw=",
      "url": "_framework/de/Siteswaps.Components.resources.5qj5o8rjcv.wasm"
    },
    {
      "hash": "sha256-FyTkVr7XAseLfLuhgeCECylA9nWr/ie7Zw0ZlpizBtU=",
      "url": "_framework/de/Siteswaps.Generator.resources.t3i5lrj1ed.wasm"
    },
    {
      "hash": "sha256-9gPSZaUC2oUC1CTQD4KSVIkbQHocDu8qXpOCqhyJLgs=",
      "url": "_framework/de/Webassembly.resources.i1wfk4tvts.wasm"
    },
    {
      "hash": "sha256-5E0sw5ahP4UuUzmjNojiHWIISvXxtls/CsSE88gvtBQ=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-NcU+nEk8wJ/8XhuXpMtT+fyCRIVn0Mz4/At8mLHdba8=",
      "url": "_framework/dotnet.native.rskqrhrjk3.wasm"
    },
    {
      "hash": "sha256-LC9CHaXa3ZR3i52oIPqBxnavGNPE6CrNtebtvnvIqaQ=",
      "url": "_framework/dotnet.native.s4szq374gb.js"
    },
    {
      "hash": "sha256-FsddKLA9kAdfVKI0lZFago0rrc/gNe0yrVtP7+D/qN0=",
      "url": "_framework/dotnet.runtime.uyfhwbfd13.js"
    },
    {
      "hash": "sha256-5BfhzgOGQRjWj996AOsK8ZD97vgGxXD5Ucoy9h+kBH8=",
      "url": "_framework/icudt.g3en5r9teb.dat"
    },
    {
      "hash": "sha256-IY9rTwFxXGoT80hakelsIciwdzg2Ucu4R9fZ7CvVy88=",
      "url": "_framework/netstandard.xws3awl3lm.wasm"
    },
    {
      "hash": "sha256-FiwvmTHh6RK0qtUUS2i5dh+OLlMw0UEge01a4o/iEYE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-gCw01Fy6keKtd8KJAutkwfkLjCTKoFwYY5Mc/FxbJyM=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-7+tPbT7PbyQ/jsoE2CnO4GZ6P2EWrzc1WLN/XbQMURg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YD6ZiRS11HFkE5RK4pa+gbg41BfrL4EajQZj9w5mnJA=",
      "url": "images/brand/fav-icon.svg"
    },
    {
      "hash": "sha256-U2muwLEwJsqjmTr6KQoRrr9sb3PCPIW6T6nTLz640Co=",
      "url": "images/brand/passing_zone_logo_all.svg"
    },
    {
      "hash": "sha256-eOdi7ENvIhNj2dWYeCGdYaVwe0N26k2+LHPWF1FrTVU=",
      "url": "images/brand/passing_zone_short_logo.svg"
    },
    {
      "hash": "sha256-tz6SDxMqEsAxYtUYPlLCS9Cnz980buGBmlS2y+9S1n4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-xZxX3HCGv1TLpxU7++crUesr3lmj99urJcP0hjSTGHY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-AqMy6ms/HeOdXV/Q6pY4gNPNQoU0LYrAb0YdM+OkIPA=",
      "url": "pwa-install.js"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-icJjkY+OZgTWDhLfFupwPt4NS/3HEV4Xht0V9Ygu5xU=",
      "url": "sw-registrator.js"
    }
  ]
};
