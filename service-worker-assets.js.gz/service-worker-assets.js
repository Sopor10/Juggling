self.assetsManifest = {
  "version": "tHP67BWK",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-ectN1UDmnjzhpqsPB5c5rY3p7aSeHJOUu22UcexKVq0=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-//i/JzMyYCIsAOKzHut9LAXW+XgwZbWOlx6jbf7O5B8=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-J6P6bKws8xYOnp2HEmjUhVc6GkT11SczcZQzkLqrpLE=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-s5wwUWgwrLJOUf6N5LNIauwI7T0Tidd25b2HaFZSHzc=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-yq22PzZMxoOuwzGg2WAGz5EAMyBtnZe1g96CdeSqyFQ=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-ZrxMkhk8bSkguJXYhx0VSqZ5UobGLa/Up2Xp7rotuwk=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-XqOisC4ioURQ5zkXqyB3aQcdHhwN2zvOGJyik6zvqVs=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-3fs8pAJqiHOhIim0rpZsIthdLTIqvY4TSjgnvS/nfkg=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-RlYQfEsF9lBg0Kt+iAAx03wc0Hpy9lXmXJ/GBF40tcs=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-SQmr+L20Xgl+zWGnIiNjX+1Aggie8NPFi3FgmBs/H+Y=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-OgG/URGDL765oEyXripH0B/7dN3dQFcXpnlAjg5dfi8=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-9eYA9KvGTJ9yINv6OFQ6dvdsrdgFG0QwDA0cDW+fNbo=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-JTVqfH7YQEbPaXo0L79fy8AMtvx0NmYtOl35RwkVO/U=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-halqu8G6vxW9t+MMiVfxCc9jG9k3aeeVTZslAB8K/5E=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-HevElI0rUMBEv0bx/J8UDo2XCby8XqY385ReiprEjkU=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-8PhRYdYmBxS5dUFiiP0dN7as2VguLg5WJ9Q70v+N39g=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-xUHUuQRXzqwPiVcKr5oCxlRfl/bPoVHY2nOBEaqgLX8=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-Tjux88it7rUI7GEhUMD+fYh3ncI/cwbPVevalWS6iB0=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-Jxg6VmzqlJP6TvCIkJc7KG3E93K4t/OsVC5hGF07CZU=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-EXzwgvuwDM4XHVXAnE+V7TTYrzK/BKtcSCYFd4dRx1w=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-jpEa8Dv8fmxLQo6Vy8zD5lhoI2EvxJySW7LaSII5VWQ=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-h0XuH2mGYhdmtmqP5y5HgCY/HprvplgfniDxIcRTSuw=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-f0uhXaNzSHCguW7IErTRjeiGQXPWEWl5p/eehMZkDdc=",
      "url": "_framework/Fluxor.9yjucuf12h.wasm"
    },
    {
      "hash": "sha256-DBC32gXCmb31ELcLWyN0VaYPespDZiNUhIL276D1X7Q=",
      "url": "_framework/Fluxor.Blazor.Web.4opwue5a6j.wasm"
    },
    {
      "hash": "sha256-Fj9bglpuaeUZA4JLtqwphjXd2cdY11izQZGZ4zDxfEc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.aff0lrfe84.wasm"
    },
    {
      "hash": "sha256-3b2Kgr95JaQWkGLv2PPVbqVMj2SNNo9uaZswYrhUl6M=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.dk8evrhjsn.wasm"
    },
    {
      "hash": "sha256-wox69uSk8HcO0LLb5aJKZ/ugOxLSBLa6iFnZWPeK6D8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.u5rh59oisa.wasm"
    },
    {
      "hash": "sha256-BvuQcbeZ/zLu2nxdmqadBKRklWwzQYv8WKjYBMP76to=",
      "url": "_framework/Microsoft.AspNetCore.Components.une3o0gupw.wasm"
    },
    {
      "hash": "sha256-paZ2SOmR3rS6DbsyF0fGXb65tp4qqd+Ty8qUlgGxA9A=",
      "url": "_framework/Microsoft.CSharp.nxawmx6wpl.wasm"
    },
    {
      "hash": "sha256-t6RTssXXLKtSJOUT6iI/BYV3YrPbautTCsqhz549lCU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.rvgls4fdhk.wasm"
    },
    {
      "hash": "sha256-eo/oa3JT4Cc/LE0otD/LWr4fQN9Vz7QtpfNt8oeccXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q0m0kr40cg.wasm"
    },
    {
      "hash": "sha256-I4+EaVahm205fWtCCjHNu0JQkCoqkwXkA83p797yGAM=",
      "url": "_framework/Microsoft.Extensions.Configuration.byt2r8jpbf.wasm"
    },
    {
      "hash": "sha256-acCED8dRnvLNnWqy3QvjvLCIeDKOBEuD3A120wuHhr4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7kgrfhq7r7.wasm"
    },
    {
      "hash": "sha256-X6pGkX8XoJScpOuTtfK3Ad7juQQn5bfFNtLVSxNbyws=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ttnw5gzmzr.wasm"
    },
    {
      "hash": "sha256-acRsHgI/54vH8NtxKbTe9tOhCM+dTd+VlCZHem4o9wE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.zxlqejpj4x.wasm"
    },
    {
      "hash": "sha256-lveY4zTZw8AEbESkgoYqtN4fiLFXAEfBdoYLdzmpLfE=",
      "url": "_framework/Microsoft.Extensions.Logging.q74thzykfo.wasm"
    },
    {
      "hash": "sha256-coFXOjH3e7XqSbBUhi1MbWKcbZBCchaL5tMKFypmyqc=",
      "url": "_framework/Microsoft.Extensions.Options.ins6s7he4s.wasm"
    },
    {
      "hash": "sha256-yumksFeLjkCb3oD27DyYQPGSrliFAjLg4s8CaDv3WyA=",
      "url": "_framework/Microsoft.Extensions.Primitives.m84zq78fb1.wasm"
    },
    {
      "hash": "sha256-zKNWe/zGp/E5ibBoimP2IH/do0w9653nb3NKFc7lFnk=",
      "url": "_framework/Microsoft.Extensions.Validation.o5kzzozb1w.wasm"
    },
    {
      "hash": "sha256-zIGd0h8/AoN3niSEUSSn1zX71vJ4hqGJZ3UwI1g+UD0=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.kivdlry06d.wasm"
    },
    {
      "hash": "sha256-6CyKCqamJ2SmhdW1FlBjSomT+myLhaQUOx1QXn3fRFw=",
      "url": "_framework/Microsoft.JSInterop.wukylkryv5.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-bHB/cBn/H5KkUAsLI7LLMttH71+jesW4vLWQz6S2NTQ=",
      "url": "_framework/Radzen.Blazor.gdv3ahimsx.wasm"
    },
    {
      "hash": "sha256-WgJ0pxiT2T/oG/QckutxOrnW6HRtsalPEPqi9P0qg1k=",
      "url": "_framework/Siteswap.Details.qjeoivrboy.wasm"
    },
    {
      "hash": "sha256-Ytn/Xr8MIdChoqoZOiMsKhejBd5OYV3nqJ5V4giODTw=",
      "url": "_framework/Siteswaps.Components.mywbr8lxg3.wasm"
    },
    {
      "hash": "sha256-omhHD55FaaNBhVR/j1Y7loqBn8XVKoTsQiArz7rQ6aY=",
      "url": "_framework/Siteswaps.Generator.Core.6nixwfhvex.wasm"
    },
    {
      "hash": "sha256-iZSeKu1rmVZuGyx9ERrBMH6C9BYk2aYzqjgtU2qaTQ0=",
      "url": "_framework/Siteswaps.Generator.h6yukucc1m.wasm"
    },
    {
      "hash": "sha256-tMixsUF4GSgbd7+FHB6PICB4tUpDj29znyKxTr6gLUA=",
      "url": "_framework/System.0x1wb7tfot.wasm"
    },
    {
      "hash": "sha256-QUiPZRpRNrIvE0evVMGCO1AV5f8to/tis1QRp2ImsTM=",
      "url": "_framework/System.Collections.Concurrent.hcsbksilam.wasm"
    },
    {
      "hash": "sha256-gfYaSrfsz9cFFxt/wm3PZBjAwAn6oFY0Ptm00VjMXKM=",
      "url": "_framework/System.Collections.Immutable.dlogipk2ma.wasm"
    },
    {
      "hash": "sha256-M0el5Xw1xPJZolXEHcAWKv8PAZ8atreLJ2lNKBkRT9I=",
      "url": "_framework/System.Collections.NonGeneric.z0x8e4db99.wasm"
    },
    {
      "hash": "sha256-NdXneX3eb/fQDExHNnr61GSA1cxIBghQmQHgwQOVDro=",
      "url": "_framework/System.Collections.Specialized.3utf6sf9v2.wasm"
    },
    {
      "hash": "sha256-K6lKvw/oqeL/2ZqzGrlKyfD/2lqp35PNdyxVI1mVYtA=",
      "url": "_framework/System.Collections.p3pngmp7c6.wasm"
    },
    {
      "hash": "sha256-gqxjvpLCs/kExu91mDTAXSvbfu0rQjDiieBC0M5QmFs=",
      "url": "_framework/System.ComponentModel.Annotations.mvlfg4nmst.wasm"
    },
    {
      "hash": "sha256-vroTW1IdRpOVAX0xSozibSRXEVauYEhx46+/Uk0TuVg=",
      "url": "_framework/System.ComponentModel.Primitives.mruytmik25.wasm"
    },
    {
      "hash": "sha256-i18H/8MIzhHvZXnZ4hURQcU6+hJ9QuxcVwxaBTF/8oE=",
      "url": "_framework/System.ComponentModel.TypeConverter.d65dlgdotp.wasm"
    },
    {
      "hash": "sha256-vNPdMM7IJ6bWQd4orV+k9dAOGXrvPJVrPHBx+XQNgY4=",
      "url": "_framework/System.ComponentModel.wh4mkitemo.wasm"
    },
    {
      "hash": "sha256-m/9kwK6mg0bQ+17s6fsnwVYGTCZddUOeu87VkfwzdNE=",
      "url": "_framework/System.Console.5ooap7j0yy.wasm"
    },
    {
      "hash": "sha256-NffiQSq52Jy7hHgCuP0tSE0YYYpMWw8kM9NJhQjNxQE=",
      "url": "_framework/System.Core.jq9mib523o.wasm"
    },
    {
      "hash": "sha256-t9xnyaZj6cGggijTfQWrdh8ATLXTLQH4vAJ5M6y9P4E=",
      "url": "_framework/System.Data.Common.xmx0xalgvo.wasm"
    },
    {
      "hash": "sha256-OhmG+tV5H8o0KHVFQHa0Taa7/j2ltyk9Y8vc9tvcMMM=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.iie3dchnbt.wasm"
    },
    {
      "hash": "sha256-MXBbyNq8fha7MY4Y6D/fJ63wG++o6kQfIFkR6KdJHbE=",
      "url": "_framework/System.Diagnostics.TraceSource.n2rryr2kjj.wasm"
    },
    {
      "hash": "sha256-pe9foojObxPr0GBjVWrGA0gyU8a5M2XJZMClMcei31U=",
      "url": "_framework/System.Drawing.Primitives.vn04g57q24.wasm"
    },
    {
      "hash": "sha256-OXGvvAB2pYUvt9B1gFkenRdgfQ6W9ylaUOjtpvUUvjs=",
      "url": "_framework/System.Drawing.lljoc384ha.wasm"
    },
    {
      "hash": "sha256-b/kA6GT1ULCkjOqM+isX4ikoRkwSs40t5U1ywmQvHWE=",
      "url": "_framework/System.IO.MemoryMappedFiles.x03lc6awuw.wasm"
    },
    {
      "hash": "sha256-FWFhFxEZRtzlRy0d1OlgWHCxpJOCVc6uUn3yqvvXpYc=",
      "url": "_framework/System.IO.Pipelines.r4k8j9p1r8.wasm"
    },
    {
      "hash": "sha256-a8sIspKRsVcSOPusqEHzyr7IyaBGIEjgcq910v01os4=",
      "url": "_framework/System.Interactive.Async.juae56i6ub.wasm"
    },
    {
      "hash": "sha256-wVSQbHYgF0uKxO26KPR7eXmxW2w2gg6UMClz2SJO1q8=",
      "url": "_framework/System.Linq.72fs4r2m62.wasm"
    },
    {
      "hash": "sha256-+H+PL4ozZ167jwAlf/toNTlEoM7C9aiP8MPZ0kyllGQ=",
      "url": "_framework/System.Linq.Async.0udklamc7c.wasm"
    },
    {
      "hash": "sha256-b7OW/KYST/nxhO4JshrnbcBGuVkTHFkYmXLhZrXdavQ=",
      "url": "_framework/System.Linq.AsyncEnumerable.hstfs77ysb.wasm"
    },
    {
      "hash": "sha256-QB/t+uYL9UedVTW4zO/5HG8oL5paKwdKTZW68+tSTrA=",
      "url": "_framework/System.Linq.Dynamic.Core.4vazbp99me.wasm"
    },
    {
      "hash": "sha256-H428hdQ9ryaLvi0kaIPxuD0mT1085YZjYWwqkpQtqm4=",
      "url": "_framework/System.Linq.Expressions.hcygxklyc6.wasm"
    },
    {
      "hash": "sha256-JD0eki1domQIGB3SxZKTLcq88lyFoG4lE1+OVwpLUNs=",
      "url": "_framework/System.Linq.Queryable.ont0390k0h.wasm"
    },
    {
      "hash": "sha256-kzehYn+5Iko6HtoWm61d53Zb+PatFvA7p97H9b6qelw=",
      "url": "_framework/System.Memory.r2vx4u6ghp.wasm"
    },
    {
      "hash": "sha256-5Vmx6PI3lXXBjio0ybowVyIqYwwu6LMjKL4bKCerdu4=",
      "url": "_framework/System.Net.Http.fzehs5j9t5.wasm"
    },
    {
      "hash": "sha256-plHxgH09JKpwQgM6VKoolDp+/W1iDi95M2dJMferqKE=",
      "url": "_framework/System.Net.Primitives.yl1uus6nzv.wasm"
    },
    {
      "hash": "sha256-bi77WszWOIkqEog+mXSJYI9nn/byPf2gTBsfsAGDTAo=",
      "url": "_framework/System.ObjectModel.y3ucfzrebt.wasm"
    },
    {
      "hash": "sha256-d+umvwwAEEbyJQA+sHIQQkF1R+rPhVYCceBiV5yhJFw=",
      "url": "_framework/System.Private.CoreLib.xii38b41im.wasm"
    },
    {
      "hash": "sha256-Ii1K8RkY9DZ/oUgIP/+y6LdSXNcsNrbDu+1RAVsBPaM=",
      "url": "_framework/System.Private.Uri.yoyilq1jkj.wasm"
    },
    {
      "hash": "sha256-SyyTmBO2vA6OM6AMwHK/QqYR0TkUORUX2leHURA9JIw=",
      "url": "_framework/System.Private.Xml.Linq.diaqc09s4z.wasm"
    },
    {
      "hash": "sha256-cFR8cpMCHM+imQ/BIe900jVTtPtkLd1YStANre52oYQ=",
      "url": "_framework/System.Private.Xml.krfrrmx0xs.wasm"
    },
    {
      "hash": "sha256-G4c8q/l/+TWqqjO6ySsJVZ+r1/KuxhnonFPB6DdL4Uw=",
      "url": "_framework/System.Reflection.Emit.5svchj7o1r.wasm"
    },
    {
      "hash": "sha256-V4cO2L79HqD66qYmWg7u6HU1ranXCT3q4gsp8uY7Jyk=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.dzv3ojfe0l.wasm"
    },
    {
      "hash": "sha256-YSJtBwcza7fBgq+6C9QbumYhtu8+xGc8NmLg+bmBz0w=",
      "url": "_framework/System.Reflection.Metadata.nm7o1gwvqm.wasm"
    },
    {
      "hash": "sha256-ZKNzk4yT8RabjrGQkBswkfw6d0D7CWkIQcrUAmuwAzk=",
      "url": "_framework/System.Reflection.Primitives.soa2aswi66.wasm"
    },
    {
      "hash": "sha256-p6/wV05PEoKocillIiVPYCnVVIrkHEzHoyxRM/6Uc8A=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.hq2mpklnqr.wasm"
    },
    {
      "hash": "sha256-HRqqFNMv+p7tQOwVoe0r8/mXbQqU/KY1UGG3W5nR3SQ=",
      "url": "_framework/System.Runtime.InteropServices.b6ou4fj7w6.wasm"
    },
    {
      "hash": "sha256-J44xHlCQ6/m3Umi0eTdnSdrSODIMR9bb9eSt3T/LPXY=",
      "url": "_framework/System.Runtime.Serialization.Primitives.5l2je0puqv.wasm"
    },
    {
      "hash": "sha256-GJuLXz6DE2l9ZGSvi5hcbg5zvp7eEgOGVlGsKxpwyN4=",
      "url": "_framework/System.Runtime.ows3qv3izl.wasm"
    },
    {
      "hash": "sha256-5STuuzqiWrDJm62Lw4UYwqJ73iHHx4OxypqBOqHCKqg=",
      "url": "_framework/System.Security.Cryptography.vv6xqw2hzq.wasm"
    },
    {
      "hash": "sha256-EhJPtvHc+IHAuXhM3Xl7Bw88t0hw1IaiPNAyxGnanVw=",
      "url": "_framework/System.Text.Encodings.Web.ird9g4uvkd.wasm"
    },
    {
      "hash": "sha256-Y7X6PXAoBBPhN0oOOlQHWZxpOoenV38qcSszTK9fi8M=",
      "url": "_framework/System.Text.Json.xbv8aotmpa.wasm"
    },
    {
      "hash": "sha256-cLQPdutsYs6rzlJFFyalBjRZ3CAU0Xl6xyd/SMslruk=",
      "url": "_framework/System.Text.RegularExpressions.04g8gapd0l.wasm"
    },
    {
      "hash": "sha256-NxePaVQeiCM0wKNiXt6rqBER4WecmgUcooKvGhmYNpg=",
      "url": "_framework/System.Threading.r7mrizboij.wasm"
    },
    {
      "hash": "sha256-dwZf8arcPXU7eB31lFTsJHQNpw65xoJ5cQlp/ez8o68=",
      "url": "_framework/System.Web.HttpUtility.zt8rxg6dkn.wasm"
    },
    {
      "hash": "sha256-5fWQqFGllSkAU/RIKtlSWTiQ6yo6HqKLGnlWX4e/sPk=",
      "url": "_framework/System.Xml.Linq.1t1f7abjkk.wasm"
    },
    {
      "hash": "sha256-y7iF0ghSL2xJRroSXl7MOBVB08IyJEVDdrkrqUOvLZY=",
      "url": "_framework/System.Xml.XDocument.vratx33c3m.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-ddaGHZzzU580/8K+cUJk6kijVwjFa7Ui7CMIg3VUfJU=",
      "url": "_framework/Webassembly.t60eiff4xd.wasm"
    },
    {
      "hash": "sha256-1xlHuu1iNOJiMMz2BCq95uekwHf6pdpTcgVNKVBboPs=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-r802kYuf9Izw3K+bn6z2uhl+py8ZwIWkkCx+Bb1O8FI=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-UAh66lBUD2gp1454TvHz1o3o9XA0qsyUsMvGRa3aqBw=",
      "url": "_framework/dotnet.native.0ozb72tchu.js"
    },
    {
      "hash": "sha256-QDJs057cshJHUImR9OUODMG4noM1R9hcjex/6yXpBYI=",
      "url": "_framework/dotnet.native.sdh140y2w6.wasm"
    },
    {
      "hash": "sha256-/ndm/PF1BeBT5mXzYAES79wNK5sIZIQKAGcUqPL9ZP8=",
      "url": "_framework/dotnet.runtime.2zl32tp6ah.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-H+LTBYk1SyGtv6oQDbeMNDHq4meGfvH6uqGCzFfY73M=",
      "url": "_framework/netstandard.hoj1o3o266.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
