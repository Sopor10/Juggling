self.assetsManifest = {
  "version": "cFQj6TuR",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-neK0LvLswUY0Nto6Cpc5ml5oSC0Ewy/oVZPX6EEu2GI=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-zSvpOi9wbh/87e2orD6L1yg57uRkTm1X1uZkWj4axT0=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-3TxU6Q5yHJAP4dEkQxetq1LdzBU3Z1dUu5wdEy8Iatg=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-e2t0XEvHjvnHz0+YyBm1WzS/2xM0xQqkmsqWzqNL7bI=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-vgChE+Tg3uiyY5YwR4ct3Mmb44soz0648J3PQAyTUTU=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-cn4tYaUvJXmtUOixxyvsDd1GgD3dxht2G6WaQ9ugIM4=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-4ZhsA5It6DSxM0+FQXNEnYQxstRyADciid1036IIYKw=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-l9kMxJEo8TzgFnIS2VNVb3CQq74PNdVLWt4K4pwKyZs=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-u+ZZ/beUAOubCGdvebfogD+/jSrEXzKzjTyJHl1yCns=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-HJsAypWKyLz1pRfBkH+6hWEiEqOFGpnf2yRcmvfHLK4=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-jQnJQgL7D887Cr/N+ZKn+KSSllDVogMPO2Zo6qUi91A=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-YeMQZuEajn7fk7zwwvz+CuBnXwd37R5EJrE2WGPZdfE=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-0q+uxXtDeinEdGv7d0nx0BTfgDsKyPT81DPNYyo0T3M=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-XXq4AWzZdI1TcMOaoy39k8fKLrOiUNgQ9Hh2OQdfs+k=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-qR6n4PLaYLro0GUmrCDi2RL31tFA//lzfRkl7UOkwhM=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-OQwGRlu7Ilnz4pT8G4AULrm7TrRxKnIZXCvMWon6w2I=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-zr/DC++GRcAVwRD8WIa1Txz5ofKos+WZOxErN9qjS0k=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-+u+2q5DSbEwvoeFlPHaMWn+fa4d/Y4wfPxyftW0zmMM=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-3oVE9QoDWXxlpvsI97eUMrnDh7/+BeUg6hKM9A21TPg=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-6JpprDLklK3UfMPPCZc3brkTcpiwaDPQGn6MKTRaCEs=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-aDl81ZduIuqUVrCAPZmPBzU7uQNTvWSvqUW+XRaJy2w=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-PWhS0bBFhKeg2GutRpftqPeVtr59oeXfOslhwdHDkQ0=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-f0uhXaNzSHCguW7IErTRjeiGQXPWEWl5p/eehMZkDdc=",
      "url": "_framework/Fluxor.9yjucuf12h.wasm"
    },
    {
      "hash": "sha256-DBC32gXCmb31ELcLWyN0VaYPespDZiNUhIL276D1X7Q=",
      "url": "_framework/Fluxor.Blazor.Web.4opwue5a6j.wasm"
    },
    {
      "hash": "sha256-x4OZ34vzk+smNBTVDO0X1fONp0vYPzg/TpNplBGcXrw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bfujbirxhp.wasm"
    },
    {
      "hash": "sha256-9orFwYi4JmyvNBA2Q0qX+JmKtAPN+FFPJOWH2x/WRnY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.qgnpmzz752.wasm"
    },
    {
      "hash": "sha256-+RlPR9fdwcYSc9IB483Yuw1i4fu8hGNwyCAKnfGSc+I=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.9wrjeuoyd8.wasm"
    },
    {
      "hash": "sha256-4/V1QONqjoQzFvMU+iFH6Z0dHNG5uhO3QSkBuBPqyUo=",
      "url": "_framework/Microsoft.AspNetCore.Components.f1r0luws7d.wasm"
    },
    {
      "hash": "sha256-arFlXiD7/dPJPioaVpb+ywGwlEnQ3ebVCp5TzGTWscw=",
      "url": "_framework/Microsoft.CSharp.i905qt9lhd.wasm"
    },
    {
      "hash": "sha256-LOBBULi/XW4t2ARw193f39bYefcOCpZQu9Pnx/xG6+M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.4ascqjkgzo.wasm"
    },
    {
      "hash": "sha256-VlasUHL3ewmPDatuOzkCrOTyTwPkIVd24650+2CW75g=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.iitlxos134.wasm"
    },
    {
      "hash": "sha256-Y630CXldwUrJGf3O/yGiTNE/FOC4PhRpBYK+w5He9Kc=",
      "url": "_framework/Microsoft.Extensions.Configuration.xnovko9l24.wasm"
    },
    {
      "hash": "sha256-+PtRqtTocXIy+ki9OlmSXfg4LRRrY0xyO88gt/IKby0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.gymjx0g911.wasm"
    },
    {
      "hash": "sha256-cz1Zot0busqSISH6LUmoeZwyy3joC96syZfHS2R1g9I=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.pdq83eroqe.wasm"
    },
    {
      "hash": "sha256-ED3btvQNynKkxhlZtG5I2E+X1528YLLk4sDWh80texw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.4vhiktfaqi.wasm"
    },
    {
      "hash": "sha256-fED0AC2P9vox8e6kgxvz0ISVfhAlQhsZX33zoA9Zk8I=",
      "url": "_framework/Microsoft.Extensions.Logging.grenq3p3q7.wasm"
    },
    {
      "hash": "sha256-AQhhfhLMv+vwCiCQeW4MP+PDX6zfp618jfAvEhlGEzc=",
      "url": "_framework/Microsoft.Extensions.Options.rpe6kdgyiy.wasm"
    },
    {
      "hash": "sha256-ZBy3LVR1MRfpTzx1Oh4qiMpv0ZdTFGJwv8GsPfK9U0E=",
      "url": "_framework/Microsoft.Extensions.Primitives.072etlnfwu.wasm"
    },
    {
      "hash": "sha256-cgmXidzz7CoeFsl5yxjG5f+5moq0I8EiKUGIXMx2018=",
      "url": "_framework/Microsoft.Extensions.Validation.u5qkcvapwo.wasm"
    },
    {
      "hash": "sha256-KBkrmyz1+94H8YEVvIm+A6GPyvHKGGl8MFQONEwpVkM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.cbdj3f5i9f.wasm"
    },
    {
      "hash": "sha256-LK02KlZoKiZz3eNoIxPU/lat/ipB8VrAYf+sUER9Jc8=",
      "url": "_framework/Microsoft.JSInterop.wn91mc8f40.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-9Ebdsdw+aLrgFYRS3Ndu3hyngLfeM35NT2o0YA17FEI=",
      "url": "_framework/Radzen.Blazor.898tmpttin.wasm"
    },
    {
      "hash": "sha256-+NTGSLXPauDznq9uk6nf8Dh0Dg7yRmf8Qrb/GbkuAMU=",
      "url": "_framework/Siteswap.Details.wqwhrscfk4.wasm"
    },
    {
      "hash": "sha256-c7MRGSNlPrwt07/th97VsewzNSeVXHqNHpDFaM8JygE=",
      "url": "_framework/Siteswaps.Components.zsq3pg9epj.wasm"
    },
    {
      "hash": "sha256-/r9iWQfO2fqE+RM3I4AP7fbldtdUmfY7dkCDeGDLZbI=",
      "url": "_framework/Siteswaps.Generator.6v6tokhywe.wasm"
    },
    {
      "hash": "sha256-pL+HehH9P3Flmxg8Th6mWF2ulr+FsiubwAoH73BnqL8=",
      "url": "_framework/Siteswaps.Generator.Core.gl6lf70nmc.wasm"
    },
    {
      "hash": "sha256-ANkVtS5QdAk0LbSR+JgjqBf0bsL1KYWW/U/a41seF/o=",
      "url": "_framework/System.Collections.82n51547fl.wasm"
    },
    {
      "hash": "sha256-zR1EZqb2b1ZrhtmeGdIAWUu7mtbpAsLXFufEauLssms=",
      "url": "_framework/System.Collections.Concurrent.pl8dpegs19.wasm"
    },
    {
      "hash": "sha256-k1PPTJH57/ZWmRsFptcYtljF6g41e3XlcKnGzYVgK2Y=",
      "url": "_framework/System.Collections.Immutable.njlqk8f3ia.wasm"
    },
    {
      "hash": "sha256-P5gtiHeu4cuSaG8YqGoa+pADbBlEclko3pTn2dPYfFM=",
      "url": "_framework/System.Collections.NonGeneric.d11ao732kn.wasm"
    },
    {
      "hash": "sha256-LL7KvMdnUtJTgCDezCeryS476W354UC2WYpSaQ+99Q0=",
      "url": "_framework/System.Collections.Specialized.8t57h19bfh.wasm"
    },
    {
      "hash": "sha256-w8kjX6l9HfCvAhekRkmt6Z5Ke2CxPOenDWyAhZX/iiM=",
      "url": "_framework/System.ComponentModel.9h13ohdho8.wasm"
    },
    {
      "hash": "sha256-C8QWl6GcRoEZ6KERbYIzmxyG/BIEh4o+Fl1uk5tce8o=",
      "url": "_framework/System.ComponentModel.Annotations.frzgj6usxk.wasm"
    },
    {
      "hash": "sha256-GAjEEIIwEqwhgtKRtPRd09w529qeD+Uvonm7p9wYzXU=",
      "url": "_framework/System.ComponentModel.Primitives.oww2xlwvp4.wasm"
    },
    {
      "hash": "sha256-mVG72Dn/D2OZTI20Uv3FQEcvg+ZbX54byQJkrWj6G30=",
      "url": "_framework/System.ComponentModel.TypeConverter.3p6upy7pbr.wasm"
    },
    {
      "hash": "sha256-Lc9uFEr84yAt4b0YYv/dNaAfGOfhR/wfAn+ATiijeIY=",
      "url": "_framework/System.Console.1r6wxxsler.wasm"
    },
    {
      "hash": "sha256-v69fvMyRw2MLYdCm6c8qEDEkwXngA3Mc83Q+EdySs3s=",
      "url": "_framework/System.Core.vkph4sefmh.wasm"
    },
    {
      "hash": "sha256-e9zprSYr73ZjEg3RA/warz+T2HKCMKf4R4FC2EJzOSA=",
      "url": "_framework/System.Data.Common.b4ukzlhiml.wasm"
    },
    {
      "hash": "sha256-Exr7usKEpZTKszlznexb503jWxdm+6JRTx4YuWLWkIU=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.d0y3j5rtmf.wasm"
    },
    {
      "hash": "sha256-2Q7B6W4m2O4h8dciPeHR5e5guawiK2T30gbrbvLHQiE=",
      "url": "_framework/System.Diagnostics.TraceSource.trb9bwc5w4.wasm"
    },
    {
      "hash": "sha256-f/OUjzpoXORRiy71/4AVWxsGxILDtvZWdv6ArOEs6qE=",
      "url": "_framework/System.Drawing.3viw894b88.wasm"
    },
    {
      "hash": "sha256-Tllbj1f53qkjrwPuo05qu2UUb+nBv7sOvoJTNyHgJQU=",
      "url": "_framework/System.Drawing.Primitives.2ja0kwddtj.wasm"
    },
    {
      "hash": "sha256-kEPU5H/i+7iJmo975f5GKaaDlfZEh56IuRA+jOZTxQQ=",
      "url": "_framework/System.IO.MemoryMappedFiles.oilugtpbul.wasm"
    },
    {
      "hash": "sha256-7N+scuN8nmiU+QbLyZpP/FeRS5FYzMOKMTSW7NAJetA=",
      "url": "_framework/System.IO.Pipelines.s624opig07.wasm"
    },
    {
      "hash": "sha256-a8sIspKRsVcSOPusqEHzyr7IyaBGIEjgcq910v01os4=",
      "url": "_framework/System.Interactive.Async.juae56i6ub.wasm"
    },
    {
      "hash": "sha256-+H+PL4ozZ167jwAlf/toNTlEoM7C9aiP8MPZ0kyllGQ=",
      "url": "_framework/System.Linq.Async.0udklamc7c.wasm"
    },
    {
      "hash": "sha256-wMKXfOyiX1n4kXOA/v6gdP16MV3AVhk1AYBd14WuDVk=",
      "url": "_framework/System.Linq.AsyncEnumerable.4vapuzjryo.wasm"
    },
    {
      "hash": "sha256-QB/t+uYL9UedVTW4zO/5HG8oL5paKwdKTZW68+tSTrA=",
      "url": "_framework/System.Linq.Dynamic.Core.4vazbp99me.wasm"
    },
    {
      "hash": "sha256-XHed0K0X+GZnD/i+HKr3kEeJIrUsyWEu+vAq7SqItHA=",
      "url": "_framework/System.Linq.Expressions.s0c2mq5gci.wasm"
    },
    {
      "hash": "sha256-zc5KGlP1rAJ6kJJrlLLHHU8z5pyIHq6hIvBhiIcChcs=",
      "url": "_framework/System.Linq.Queryable.1b4s6p00v9.wasm"
    },
    {
      "hash": "sha256-QAU1ee052SRus2JcoASHru/WsnU8stWaYe3ZcRPXNlk=",
      "url": "_framework/System.Linq.ctysavw5h3.wasm"
    },
    {
      "hash": "sha256-nrKYE5t5K9UQrg7oRbyAufOy1isxDOp6UwsmLYnZbZA=",
      "url": "_framework/System.Memory.qtn0ennx4i.wasm"
    },
    {
      "hash": "sha256-JXa4JvBBXp5bOiF4BV34ifgxbJHAP/vaMAL5xh5wt3Y=",
      "url": "_framework/System.Net.Http.58c1auc93o.wasm"
    },
    {
      "hash": "sha256-wAP39lrPxd24Aksv911Fc9QeQhlMtivWi6RANnW+0+Q=",
      "url": "_framework/System.Net.Primitives.g0joan8ok8.wasm"
    },
    {
      "hash": "sha256-A22CuO+w3YChYU41RLgPOy8cLwrZiA4ohhtghcp9v7g=",
      "url": "_framework/System.ObjectModel.9hlx0ya5a9.wasm"
    },
    {
      "hash": "sha256-zwkb1mpUbhBPmDkRIUujUJEcUU/spFjkM03MBDq25DA=",
      "url": "_framework/System.Private.CoreLib.r1t3ovqz5m.wasm"
    },
    {
      "hash": "sha256-KWzpZPUlXfFtVVDVnZJLrx0eWikHXgBa+Wy6g1ynwnw=",
      "url": "_framework/System.Private.Uri.pkwpbgdsoe.wasm"
    },
    {
      "hash": "sha256-7caKFfMUyPDLbXNBdKyC5W1IVcWVd9cIWKSg5WXBZf4=",
      "url": "_framework/System.Private.Xml.Linq.7ffoxlq037.wasm"
    },
    {
      "hash": "sha256-pXrQ1Rr6HrlOhkHS72IKgSbHmtEPULrt8rREdiUqi4c=",
      "url": "_framework/System.Private.Xml.tqivimas1v.wasm"
    },
    {
      "hash": "sha256-zVbZkkJtsHWToL2kAtYti7gd5tRpRCW+DicEwBlMcRI=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.jsj4oxfxpz.wasm"
    },
    {
      "hash": "sha256-AJ0FKJ9ZDsQrHBfyUVp6H2SFeCvAQ7b+CO5o/1gEdtM=",
      "url": "_framework/System.Reflection.Emit.st9tuyayjq.wasm"
    },
    {
      "hash": "sha256-EIGVcgztm7VFFRIESiwtW4brgz4MHsIni8jnSqXeZzU=",
      "url": "_framework/System.Reflection.Metadata.oekbduy325.wasm"
    },
    {
      "hash": "sha256-lvQRu8HVW0Oi/FFIOhFbm8Rh91NbibGtoCWYsjtHfho=",
      "url": "_framework/System.Reflection.Primitives.65rsbezu43.wasm"
    },
    {
      "hash": "sha256-Cp2bQOeRFVxMIA/IQbNc6pVyPdKopwM4EnwXZAse2KM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.uzoakn3mog.wasm"
    },
    {
      "hash": "sha256-hRKk/mTbKOvEiiMNlxO5KeZXI1qIZfVKPN5bbnFRTUI=",
      "url": "_framework/System.Runtime.InteropServices.v3fgp5l84q.wasm"
    },
    {
      "hash": "sha256-0Ft8otSyBLY3Xf1wCa28JH48CeCqnc1LVF55TTXbifc=",
      "url": "_framework/System.Runtime.Serialization.Primitives.g04uo13c1r.wasm"
    },
    {
      "hash": "sha256-gLq9AoWSR59ItWVjr8f1HU+pxj0zmtk/EIDT7v0mArA=",
      "url": "_framework/System.Runtime.c5c4ovrk68.wasm"
    },
    {
      "hash": "sha256-FrsOY8zOQD81TGKDEh0mP3ZICBl00LE3furOw7bToxY=",
      "url": "_framework/System.Security.Cryptography.6wps1yap4a.wasm"
    },
    {
      "hash": "sha256-grMY4M0k8p9y9MREo8l+5RNL6efy7B8EG4ymwcIG62U=",
      "url": "_framework/System.Text.Encodings.Web.q6hehx1i4q.wasm"
    },
    {
      "hash": "sha256-OzNMTH1bIycOBMvaKZSnk5Fe9ap/l+pWD8JNJyeST5Y=",
      "url": "_framework/System.Text.Json.bg3r5xya7t.wasm"
    },
    {
      "hash": "sha256-wAHPTk0jNWHj7SPZGfzpvhVkejTXdnwyKkIZwl40Pcs=",
      "url": "_framework/System.Text.RegularExpressions.oejkr5fdah.wasm"
    },
    {
      "hash": "sha256-tD0l8jkHGArxjxeVQBljWjCbOFmMS0giqeAQ9574Nek=",
      "url": "_framework/System.Threading.0bgjpol6rw.wasm"
    },
    {
      "hash": "sha256-/c3k4DddsfTkctWfiqSEupb8ygRAN4IPO7uZ1kjzYH4=",
      "url": "_framework/System.Web.HttpUtility.v92a8shsad.wasm"
    },
    {
      "hash": "sha256-T+9RdfUBfnlvro21wk8VmmYe3ZDfKiYEBbJPCfLiuds=",
      "url": "_framework/System.Xml.Linq.7qmldn65vo.wasm"
    },
    {
      "hash": "sha256-98Juu410m7xA9HgROwSepPIO18xwGABVNiVc4529598=",
      "url": "_framework/System.Xml.XDocument.v6g8vwwz54.wasm"
    },
    {
      "hash": "sha256-TbXBiQa38E2TrjWSwZYk9l9sTztp8pQ4MLJyVPBpaEk=",
      "url": "_framework/System.nnqvudo0vd.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-AxSwgbcGhJ/CPcyjrwQNrtwWUjYSruY0wWfncks0bMI=",
      "url": "_framework/Webassembly.d8dg5kxl3c.wasm"
    },
    {
      "hash": "sha256-A59Tr9HqEhHMu8kU7kruLI9ayw5MRS6Lvc6z7jCbghk=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-CUD6I0S7ev/fRXEG5a92z697vWTACjY4NNUQp9SHv3U=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-D0lB5QwPstRFCtxEm6fcgSVwqMmZpgC35x8sfarJM8M=",
      "url": "_framework/dotnet.native.7au35iu85t.wasm"
    },
    {
      "hash": "sha256-gXwUFytQWX5e5jpvb2EjW2Tj5EV/HOJY/II20+77fz0=",
      "url": "_framework/dotnet.native.hs4lpa5w7s.js"
    },
    {
      "hash": "sha256-7i3usfTrnzC/9qWO4si5Bw4w7D9fUSnSBdhQ47blX2M=",
      "url": "_framework/dotnet.runtime.a6jcqbs390.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-PNRSb+2oX7p+klGjBFqHih3dxBSgjzEsT2YI4+LQCoA=",
      "url": "_framework/netstandard.ke7vpdx679.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
