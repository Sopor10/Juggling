self.assetsManifest = {
  "version": "2xBKXycO",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-Zj7sF25g49ZYgpgxmvvLs4xs7wWCla5f2cWoqW+r6/4=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-kYE8x9Fxto4kAa5rZOX7UoWbO/ezKh+gt2g0jSZWNtI=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-9t6EXWYnl/QKcjuT8/+OKfHA1pouuLwhKIYsHnsB1tA=",
      "url": "_content/Radzen.Blazor/css/components/_qrcode.scss"
    },
    {
      "hash": "sha256-YVOvEQpafIYbQ1C1wHpTmvQmix/J7IIM/s6bR15xzeY=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-gkui+AFMoSJ/CZpSzxAiT7olmWjNpYUjIBWOJI6wuMc=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-twSJ5g1IeBzpsxmHR3FNu7ItID6H3XbU1HZ/qJSWRFg=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-9ZPFj82lGG387S9bKduzkwVEZO4fdwo027aodi4LNVo=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-YmGG8kk6j+Dwd+oz9V/6BjCSaUsYklsZsy/ikfZnS68=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-vty/la3MXjb8+NihPQEMF9ijro+NPHFHsJOXoK4Mh28=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-4tmVJXuCBk2/QRsIy7dLf1bN3X2OolRLRGYmKeVi0zk=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-teD7Xp9KoEEbG4QaoWzAqntOrbHPWNULM3dsFVROfkE=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-F6ZGl/o1vaNUJUGMCDbYnYCswD583tEqbu+LSy+/0ho=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-4ZMduw+tDam6nGA8fEuuPFi23JFfcM2y2EDh3/5rKAw=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-VId/LOwa/fiUtA67BmPAvXp5phlsSyykd0Lw/Fc2DAM=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-h2e1Huh88KqwXtlPMXfdyz7KuPmGwRQ4mlMmmDB0ttM=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-fzXK/2BQ8C/lABKJC6dsV+cXmFHprEg2ICoPIqt6r2E=",
      "url": "_content/Radzen.Blazor/css/math.css"
    },
    {
      "hash": "sha256-wJ3Lb9vVJtckdL66r8uyArmsd8F8WDFB2tVJR17TJ/M=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-FC48ZdritMsdzEs4DD6VfaM2i2mQenOOvjOe4CKSJCU=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-tkEpeRJs4pAczrvwgj5NEuwRXunsC9lJYbx/prqb+IM=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-BR7Qlv0MDGLSKU4dbtBeCRDWQRHGoA4xs+85cVsXI2k=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-3zReFg9ZAhiu8VOEA3fk2vRjYcKthwM+mh8/Xs8S/tw=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-ioPJnBiXjLVLzXAmSiBh6j7e9/Z+OtdZ4+++6sqTfmY=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-6/nVMSZPj5TQ58+geQrVD21/1z5mCK1ktWtneQZzvaY=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-U9HViKHLkZ5sWC6DzhKOGlAyxEQWJKRSkwzvTPi63/A=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-f0uhXaNzSHCguW7IErTRjeiGQXPWEWl5p/eehMZkDdc=",
      "url": "_framework/Fluxor.9yjucuf12h.wasm"
    },
    {
      "hash": "sha256-DBC32gXCmb31ELcLWyN0VaYPespDZiNUhIL276D1X7Q=",
      "url": "_framework/Fluxor.Blazor.Web.4opwue5a6j.wasm"
    },
    {
      "hash": "sha256-WDj6zFF5W2cCVm+/vXciPtBVz/6ZZuf3Ap9OLi0KsWk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.cro4aqj7ws.wasm"
    },
    {
      "hash": "sha256-4ZDV2WkWDBG/hZCum1dvXlHHqVy/JV7uH5Zp5f20cME=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.jn1biw81qc.wasm"
    },
    {
      "hash": "sha256-Acg1yXvhj6PyNQb6hPPYZflcoMTrUlEZXk2Q5DgUnKA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.3rjs5kr9uv.wasm"
    },
    {
      "hash": "sha256-PfqT8l+/wKUnG2Am/7bXCEnUmt4FsOZBXoGqUjdzQgM=",
      "url": "_framework/Microsoft.AspNetCore.Components.hruurepi4y.wasm"
    },
    {
      "hash": "sha256-sp0r0xzKwYxxoTGF4f9WqHHd9qLSg2HidqkFUd0FHUw=",
      "url": "_framework/Microsoft.CSharp.e5f0xsyif5.wasm"
    },
    {
      "hash": "sha256-TRP7en/tYrB0OHj3n5BVZ5BQH3VTIuLi7/i+WeKRXyM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.h3x7gkd3wi.wasm"
    },
    {
      "hash": "sha256-OjISDzBleMVRyG6rOCMR1WjrrnGHVnlAEGfRtLYXksQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.awfv43uy1f.wasm"
    },
    {
      "hash": "sha256-SetdHnoubSXEfLfgohBpm7QWFpANyybYdHUQHXJmcGQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.zdophn6obr.wasm"
    },
    {
      "hash": "sha256-G+wGLFASIZbORM75OJ/Xbn+bPW9gAbDVRaDZQg2ciu4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.54x5plfzkn.wasm"
    },
    {
      "hash": "sha256-FLbHGpks/qUdpolOZxXwNFFHSZ2+KaN0l03L22jlZOw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.sa5hpai13s.wasm"
    },
    {
      "hash": "sha256-sJqpG/RCGV21wJcp+Ca7vgs8N+Bnsy8prLw0oPmmV8Y=",
      "url": "_framework/Microsoft.Extensions.Logging.0wppuax7wd.wasm"
    },
    {
      "hash": "sha256-aUEckgx6qwUWZXMwRqR1LmkLP14GRhhFT2AhBBJAJvk=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.1ufx3g93fb.wasm"
    },
    {
      "hash": "sha256-c8KJZH62bCfIAv/i/inVxrAzJ8++Mko5GpcBVldhSgM=",
      "url": "_framework/Microsoft.Extensions.Options.9lxuk5vqht.wasm"
    },
    {
      "hash": "sha256-wPHyXmdrduba3eHx418PJMQVjpA/rpfj5v5LIH2suHI=",
      "url": "_framework/Microsoft.Extensions.Primitives.sxwmyjz82q.wasm"
    },
    {
      "hash": "sha256-KsUXuyRYgilIX8K8GzwmeElIHWi1+ysgcvRDxQ00C78=",
      "url": "_framework/Microsoft.Extensions.Validation.iqrfzy0v45.wasm"
    },
    {
      "hash": "sha256-IbbB/XtjYWT/H76RKR7XCkmdE5Vo4ubHSshoYiq9Od0=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.jnpc95ilb1.wasm"
    },
    {
      "hash": "sha256-iqsljTZVfyjvFK/LZ5XkdVTu1FFJC3FUwQQJilTY8uA=",
      "url": "_framework/Microsoft.JSInterop.m02lvidi9h.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-qIHmYHu8Tx8xpLRm1wWccLL8BTvtOR33aCodIDqE7yY=",
      "url": "_framework/Radzen.Blazor.szeblzox47.wasm"
    },
    {
      "hash": "sha256-xCMcFfQFv9eetoel2LwPPrk1OMZiK0Kq8H7MaYL2M/Y=",
      "url": "_framework/Siteswap.Details.o5nwj3ka65.wasm"
    },
    {
      "hash": "sha256-Eqc7AlJz06baGZQ5IRy3sUrmZC16nbqDznZ8xiOrS8k=",
      "url": "_framework/Siteswaps.Components.a5jsx6zdqw.wasm"
    },
    {
      "hash": "sha256-5X9K/epzOK3yBliyyvHjKQJZ2Sij0nyWvpE2dCUPPpk=",
      "url": "_framework/Siteswaps.Generator.Core.71vc499i2j.wasm"
    },
    {
      "hash": "sha256-3mf0aRd9MhYYlXKNzF0gr9ET+g3/tYRDoo15OXq9RMg=",
      "url": "_framework/Siteswaps.Generator.ug0qfhpgst.wasm"
    },
    {
      "hash": "sha256-rkLX2wVa7roxAYzGFI09jKLrEw/WO6kYQTcnREOu9Tg=",
      "url": "_framework/System.Collections.6qgsf0lxg8.wasm"
    },
    {
      "hash": "sha256-BKtfxNgBwjSN9/AdaNfPU9/d/xgddl9YH/aMtA5tKA4=",
      "url": "_framework/System.Collections.Concurrent.854wwuik61.wasm"
    },
    {
      "hash": "sha256-zhuLdJeDBoIWqzj41Q1KRT4i07//ktPXWyUdIqwUPSw=",
      "url": "_framework/System.Collections.Immutable.maxpn81op6.wasm"
    },
    {
      "hash": "sha256-58OGhqlOWNCH/w6Xe3fciPS4lc82wM37AVyQzDpP4Pc=",
      "url": "_framework/System.Collections.NonGeneric.xatvqjpe2z.wasm"
    },
    {
      "hash": "sha256-Gxhxs6lhY5fqvFxwakHGwRvmq+P+A9ZB7A4TXYFhVUA=",
      "url": "_framework/System.Collections.Specialized.9nebltsthx.wasm"
    },
    {
      "hash": "sha256-iLB/v5ymsBx034mmns4x2J284v/yxNXikHUL6Ts7BhI=",
      "url": "_framework/System.ComponentModel.0aycg6tn4n.wasm"
    },
    {
      "hash": "sha256-BU7o+aZcLPZByGu1N5VGGTZFk+C1T2WhDfg+W0kmghU=",
      "url": "_framework/System.ComponentModel.Annotations.du8tkm5ar1.wasm"
    },
    {
      "hash": "sha256-FMM1TeJmbYoJ6BeT9ULZuZ3MAXu9cvFI07X63VP6UpM=",
      "url": "_framework/System.ComponentModel.Primitives.8zq6dmn5kp.wasm"
    },
    {
      "hash": "sha256-fEL406fe7nrN8SnQrYuEhzzmsC0n8JNxK9G2U305/Bs=",
      "url": "_framework/System.ComponentModel.TypeConverter.o7no6nrkg1.wasm"
    },
    {
      "hash": "sha256-mLRZDT7CKiwJ0R7rrAg0aL/e9PmKCUJKhPIG9CSwiVs=",
      "url": "_framework/System.Console.kdzqjrw14z.wasm"
    },
    {
      "hash": "sha256-JWX8kg5a1bdki34c2JubUAkq3UP3Fbin+V/OX1/Izpk=",
      "url": "_framework/System.Core.tqe26a8842.wasm"
    },
    {
      "hash": "sha256-zmgR4z9/u/BeEicOSsj8g30c6ocpOVEIyvs2G3pt8a0=",
      "url": "_framework/System.Data.Common.qlwvau3o84.wasm"
    },
    {
      "hash": "sha256-c3VlUVbhJGhrZz04H7zAIWWJdovcHPNW/5lvp2gsMz8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.rumrlhzi38.wasm"
    },
    {
      "hash": "sha256-93LMoIY65OVq7bIkAswITOSFjirdOEHG0ClQk0nOmvM=",
      "url": "_framework/System.Diagnostics.TraceSource.7olh3quuv4.wasm"
    },
    {
      "hash": "sha256-KwXEWTXZS4p1uKg+Veev9HNs6NOaOxk4hZfTfmBBCRc=",
      "url": "_framework/System.Drawing.3uzv2f6kn7.wasm"
    },
    {
      "hash": "sha256-dxOQxmyzlMoJaAUOv1+0Q2mwy4x13LTrtlnNrFC9pEM=",
      "url": "_framework/System.Drawing.Primitives.jxcgalbgz2.wasm"
    },
    {
      "hash": "sha256-UqmcjNef38Wys0AwrsvDC4LKo+D047zXX9ZRKtNUhJs=",
      "url": "_framework/System.IO.MemoryMappedFiles.ijb5luq2el.wasm"
    },
    {
      "hash": "sha256-EWhxA7J9ryvoU3icCZgM2vfR/mEM2EZLLcxqJhr72CQ=",
      "url": "_framework/System.IO.Pipelines.vghmabkwgd.wasm"
    },
    {
      "hash": "sha256-kCn05pitMJb4HeHW8//LYoOnmmVre2ARo/2fCjaKzd4=",
      "url": "_framework/System.Interactive.Async.w4ccatvl43.wasm"
    },
    {
      "hash": "sha256-e7f/b+XuYlL7gnMn3ZSLldZLWLhnjmjnS9e/lc9nFhI=",
      "url": "_framework/System.Linq.Async.9ng5pnnqa8.wasm"
    },
    {
      "hash": "sha256-txDOcwP0De/N5uVvjW9Abz7rjVppsICSNS0DCPim3FM=",
      "url": "_framework/System.Linq.AsyncEnumerable.dn470ne5eg.wasm"
    },
    {
      "hash": "sha256-5mMcR6Lmx8cWJWZek6QwlfKvlcYMgwRBLA5/5KeAVes=",
      "url": "_framework/System.Linq.Dynamic.Core.yt3i0kvfqy.wasm"
    },
    {
      "hash": "sha256-+BgDrbBnxiLKq9j7926KqkU3nxoFYNA2IZsMi65v+p4=",
      "url": "_framework/System.Linq.Expressions.guwzm084eo.wasm"
    },
    {
      "hash": "sha256-PQuKuNFedTs55uNiR0m+sHjqWMwHa5YXVLaf8csNw3A=",
      "url": "_framework/System.Linq.Queryable.9xx6uj53w1.wasm"
    },
    {
      "hash": "sha256-pb2LMxlG5wv5/8RY15l3TXFX55AR+maqUD9c1Hw4OTQ=",
      "url": "_framework/System.Linq.bcy6vsqtm4.wasm"
    },
    {
      "hash": "sha256-wrApBKxzie0PN8H1/dV1DKYRCV3fFd21Xct8zPo1Sjs=",
      "url": "_framework/System.Memory.28i6zbw8rc.wasm"
    },
    {
      "hash": "sha256-6e+gb2hrsca+406plnM9VFqfv8CMi+ChLj/zEQMOj9A=",
      "url": "_framework/System.Net.Http.3t4fun3ilr.wasm"
    },
    {
      "hash": "sha256-gcSyjZCWlkUbsdHp/weRBWjtTl8KHsHa0LkHE9Xvnjw=",
      "url": "_framework/System.Net.Primitives.5j5ae3dc60.wasm"
    },
    {
      "hash": "sha256-a/3un0xTvJhVckhz4+4e7vMwdZjgAoFsy7WDfGyvdLA=",
      "url": "_framework/System.ObjectModel.rovovu1ykb.wasm"
    },
    {
      "hash": "sha256-h6MZmF3RVVyzGSPro48Y9lw8PRMgntwxAd746YTyVWw=",
      "url": "_framework/System.Private.CoreLib.hyeb0n4lm7.wasm"
    },
    {
      "hash": "sha256-nS7QmCL3cN6CqPXhAAbKOFIf63VhaHjHp5BJpAmz340=",
      "url": "_framework/System.Private.Uri.jcm1ym7br3.wasm"
    },
    {
      "hash": "sha256-/KqmTGBTQwazwCh/8IKiXJ0AWFurCimojdGefX60I0E=",
      "url": "_framework/System.Private.Xml.Linq.4s96qxy5kk.wasm"
    },
    {
      "hash": "sha256-ljySyXvn8mOTROa5KZBdFBKgOSa6w9dTqqni+MpGtH0=",
      "url": "_framework/System.Private.Xml.ursn6j2bmm.wasm"
    },
    {
      "hash": "sha256-jwoiXXtYHK8y28UMn8S7NFo20W+2UBSCZJcUWQxPb2w=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.r5kaeyfkvn.wasm"
    },
    {
      "hash": "sha256-8iuveFlpy2mdy450W2hPLvMFZLYS6FCd7E4ZvFKx34Q=",
      "url": "_framework/System.Reflection.Emit.a5p7pw2oqi.wasm"
    },
    {
      "hash": "sha256-HCg1YQK8SmUqx4/HfzZ/1Ik/swu6Rn4zU+PNeAgtSy0=",
      "url": "_framework/System.Reflection.Metadata.g7pisr3nmo.wasm"
    },
    {
      "hash": "sha256-ngxdVSxRZeKtUTywyO9kglKfmVBvN0/wzM65a6T7nkM=",
      "url": "_framework/System.Reflection.Primitives.63fkyau3se.wasm"
    },
    {
      "hash": "sha256-pg1DdfEus8MgtvuevXJW7tX0CHVfSV+Zu9N/Xlo6NMY=",
      "url": "_framework/System.Runtime.InteropServices.606hh9eikf.wasm"
    },
    {
      "hash": "sha256-IeA7pB0f/o3eZVGm+sIm8RKPcsD69THNJym/etwOWYI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.bp9v1jxw1s.wasm"
    },
    {
      "hash": "sha256-5iydBXzzVmhV9ZUJ+UeZ2bRfb2/O92ox0o4acHFbyEo=",
      "url": "_framework/System.Runtime.Serialization.Primitives.yheyr1ho8i.wasm"
    },
    {
      "hash": "sha256-xDp+apSEURLg+Y/il9SyMEySb6U47sDRx4rx1BlYifc=",
      "url": "_framework/System.Runtime.s0elv3aeuf.wasm"
    },
    {
      "hash": "sha256-/xYxHC1kn+7sx+OOX07MJauwWNE3EH0XZVJ/L50Iam0=",
      "url": "_framework/System.Security.Cryptography.96mf7xwhxv.wasm"
    },
    {
      "hash": "sha256-t5giQdf8+U1bgTS+SDlqmhA1qDEmJ5rAlr9gJ+Zn4qM=",
      "url": "_framework/System.Text.Encodings.Web.70fzedw1k9.wasm"
    },
    {
      "hash": "sha256-Y5qHUGYtO2/i4VlpuzhNET0WJ0Y2yTu/bCI8EO8mSv8=",
      "url": "_framework/System.Text.Json.phyox0qtgh.wasm"
    },
    {
      "hash": "sha256-xTk/XOHatmy3fQ5aPUUAmUpNIFZHxCSxT9325g4MRdM=",
      "url": "_framework/System.Text.RegularExpressions.nxsbb5c2gu.wasm"
    },
    {
      "hash": "sha256-BV6qY1Y4J7ypTLoMcHkCGaFgQTCoyNxc5uD8HEKfrOc=",
      "url": "_framework/System.Threading.vzb9xjlrao.wasm"
    },
    {
      "hash": "sha256-3J8Be8GH36TDlvGVIm7tkQM3Q1gSUMtADFiqnFlli/s=",
      "url": "_framework/System.Web.HttpUtility.44pw5lkdxc.wasm"
    },
    {
      "hash": "sha256-B45e+WTL2VicVkqRzonMAYf3a4yI96CpyM4IYzSqzNw=",
      "url": "_framework/System.Xml.Linq.55sa1dphju.wasm"
    },
    {
      "hash": "sha256-iV8Jjf9KrHpK9g4VJpZeK2UjyJoJ3PivCmHE3pJcY74=",
      "url": "_framework/System.Xml.XDocument.hif44loflj.wasm"
    },
    {
      "hash": "sha256-20jVhUzIwd4iBa37tc3g3OaofHfBeJaMcRCVn9IZFoU=",
      "url": "_framework/System.fv399lvvsg.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-4OKtmpT5RHdkDZaWp25yMt737IO8g7XAeITyz3YM1fY=",
      "url": "_framework/Webassembly.oaa3so1ugl.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-Q/miW8ix1zj3hmOV/f1vPYjK4DZg4eJ/tBhs8p/IuBQ=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-MMdRDxijJrAS+FHoJfoEZXaoLLD8QhFOL8+GtdGnFbc=",
      "url": "_framework/dotnet.native.cdd2fmhqzo.wasm"
    },
    {
      "hash": "sha256-xJIEohGAXOMcChjahWWg9RFYdXbHb+BzCBV7AJBw6po=",
      "url": "_framework/dotnet.native.gxlbbd5rgv.js"
    },
    {
      "hash": "sha256-cajUr4vA/MpLPWj3omULUOwEQw3i8CE2n8AmDheqWBM=",
      "url": "_framework/dotnet.runtime.peu2mfb29t.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-Gc9hCS0tWN0DCDNlpz01FdSsiuBcEoyeWgYbiQLF9c0=",
      "url": "_framework/netstandard.5hnp4mfwpj.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
