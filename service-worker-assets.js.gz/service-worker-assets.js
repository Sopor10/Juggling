self.assetsManifest = {
  "version": "Uy2JmSjk",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-JeypQ6k1BD6nhw0rxcXZSp9bOeGyVqr+sst92RsCOjA=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-VWIIkqe2RFbIUVDqnTZa6ta0DfrP0fmbUgXa/JN4OJw=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-XppnVNMSWZltWUCjOzpaUuWEuGozPxHUgfXL2r6JccU=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-M9oCY0HEHaFPTMj7CLTxNBT7/8jUvcI3/3q27/kphek=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-t1uKYgBcl4bJd25sz4/f990IWqPxutyGC4Hc5H2eQqs=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-JD3RygdxeOquPFPRQ3DelNTdtQ+kJf0jQlEyJZbTCfU=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-lYiMLG73UrqjeD3Xr0zwkygnPDSAQXeAo1554Yjqjkc=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-/0Sj01fq9ZarIh1gzP4k9BNe/ATG3FeA+d5LAnmJHqw=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-Mlw3ybaMyE1dBptyAS1fcdPsMdt9fJDNio58gkLc5uE=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-JX9tH0gP6nOH9g1fcaSt1h+/yC5SEBf2v0atI4Xh3ts=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-wsCFo85Tm++Hir55ycJcA850vMHr3ejT4YmaO32HaNc=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-VvNHHKQAF5/cgbyUH9uOjcQQocL5fK3c2mEREqROQso=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-J8kJYxpBFMrMjHMBSdDlq1lYqyntxOrDZ8AW5FrxH8U=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-WjA34uYE8l7EE+5tc05Xxo3Jmlk3KgWzscDJaPPa/xk=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-L8V7i1RCuTmYGOZ5GdxzKEHNBgLPssts+VIR0TmgS9U=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-/ZegJwq+zVdwm94+neiq/PBCJdquvd8D1BeTh6Dflp4=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-mscmBJFsTrAe0H/SoknylPnukiQX2yfQ/zSnbR4B75k=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-VTD6ojjZPJHbt/kSqWnE0wwsEUoL20GpYpfgZveLwZ0=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-y6x9nQqkv3mW+Dvmm6Pvh+h0ixHfY0RLzrX6ZlktoG4=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-iD+5PrJoh5XNhYO07bM2aQMkOpGE0A82RtIZZKMO+EQ=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-gaJG5hSZtirjMt9Hj1BFXdC8Ws9785FEmwzdZszLRYk=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-S2GJqKqmOoZfEoGPydcbDoo+LYBGxYUd4w8sCLhknmY=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-VyhJgq8po3mud6FSP2a9ENksqEZN5jW2kGxLQC+F154=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-gq+8QIq4OhB6tEo4EB87HIE0qq6RJf8A379Kc7e3gUo=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-tRcVAq9DGc0nyvTuxUpiBTY8PaxnC6deHLSE8Ri1PMg=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-yofVgOguPkztYFuj9WrFQ4OH8t7dDCgXPRg7yIa1yXg=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-8SboVj83HQXFMcGRasZldmR8v7dhNNIfCMqOYn2nTfQ=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-4CSX54QEX1aYO+cAyBDEjWs044HbpvOU9F0jJ712WhA=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-HYNTnwNf3xj899KPdiKwmD1e5t3XRg9VaQgB1ZOvKeI=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-W8Sngznqn7kdzq6El4Hmx3bTnL1eY75v6lZNhXul5qo=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GFU2mt0A9T8j9YMwMQqIUmdziKNDuPppDCn2o37LV2E=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-w19GkrV3axM8c0MUUU9w6PnwqTUmqO8xv7L3rJi0cSU=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-jl6yGniuOaLQTXd36jhE7+/dH86dwgPNpHgSvBiQxxM=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-UgKMXwCkrTN0h4grdnwXq5lcGZFXsaWgzrOETTMDa5o=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.aud5xbqvgp.bundle.scp.css"
    },
    {
      "hash": "sha256-jvdEwbPP9ySWwm0cTSiOqdIfO15rtDmoxKmiqmFQR/A=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js"
    },
    {
      "hash": "sha256-y7L+XtwoUJtcUnvXGeRLVrLj2uLMTgPyNKJlEJnFbpc=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js.map"
    },
    {
      "hash": "sha256-pCIEjwDATOwa31+YvucoW1WTxT4YiQVDFhw94hu6wx8=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js"
    },
    {
      "hash": "sha256-MTgEQwaemErPPoFSvy9/AvhoR7QaOAVkSgXh+Gs5jmY=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js.map"
    },
    {
      "hash": "sha256-la7lyIF2RfLmzbgQq451BnkJEU/wykMPE6pCn8Po4pI=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js"
    },
    {
      "hash": "sha256-HQWKRYNJ6U0CQ6cjuHiZNYzn9EyBxinvWwT2zctFdWE=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js.map"
    },
    {
      "hash": "sha256-YQqC+x+db2pnQw/gibR4ai58y8WWbVsaiM7Dg/5ZjmQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-YEIKzZHjTFrB0PdPq+MUTCQVa9BXJOk4GoWEv21FNno=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-eM8DTi6b6DvS8NIedSLSGsOM4Y0OGeQUae6fmc0F5HQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.map"
    },
    {
      "hash": "sha256-tmxVjsHcxYihEtmXEJz2gJejcMpa2tNP2K5IAMBUwls=",
      "url": "_content/Z.Blazor.Diagrams/Z.Blazor.Diagrams.ezdqu7jd9f.bundle.scp.css"
    },
    {
      "hash": "sha256-s7EEPdhBW2P8sjiCOtar0D9cqNeKSPOwBxqj89twi14=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.css"
    },
    {
      "hash": "sha256-tjG7h09kCbOtLws3pLFB95nmOYxMZl7c8jbGPTarGBc=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.min.css"
    },
    {
      "hash": "sha256-DPGv+cCxzPgtITUub8yFS2/hFYsTZvuV+MX2hT1/C58=",
      "url": "_content/Z.Blazor.Diagrams/script.js"
    },
    {
      "hash": "sha256-LgAw9yB0DF0MNdupxctpNfEU7NoB56YJnh9QpuwRcI8=",
      "url": "_content/Z.Blazor.Diagrams/script.min.js"
    },
    {
      "hash": "sha256-EntOrNcHrVMAVfWpFhvF7p3Dlm2ljQBZcZQoK9/ENig=",
      "url": "_content/Z.Blazor.Diagrams/style.css"
    },
    {
      "hash": "sha256-UKzIp+VqUElrrWqYXITbK2mVVp6d5hx2LP+pnMfozLA=",
      "url": "_content/Z.Blazor.Diagrams/style.min.css"
    },
    {
      "hash": "sha256-qbG0STeTRSjScVJ9SBP9y6zl4YpUsBt317lGajCmB8Q=",
      "url": "_framework/AutomaticGraphLayout.Drawing.rfmvbsf468.wasm"
    },
    {
      "hash": "sha256-G5FHc2TipvCo7po6ZTAuX5MXPHgkB4E+CcQNvwSgIvo=",
      "url": "_framework/AutomaticGraphLayout.xhitsgdb3e.wasm"
    },
    {
      "hash": "sha256-W5jAEh1BJpID2KOjfMO9vOPVsdrYaro2ijjK6RlgFTc=",
      "url": "_framework/Blazor.Diagrams.Core.z625myqj9k.wasm"
    },
    {
      "hash": "sha256-zGXooQdLm05nUxu/a1HW0N8h1onvcACfrPx+R+fpsFI=",
      "url": "_framework/Blazor.Diagrams.ckfoh8zkyc.wasm"
    },
    {
      "hash": "sha256-4Oeo8/KDTym/CblLRv6nEV9S1CDpm+rU4UjbGfjgDyM=",
      "url": "_framework/DotNetGraph.8ylozkoln5.wasm"
    },
    {
      "hash": "sha256-UUDdQpFUY9H2fvZxvGhWLfifbi0vztUkLr14L1HLE9U=",
      "url": "_framework/ExCSS.vo340561u5.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-9ojaJq8QVQe1GDuUrd8bTKQGAxng71hpdqUPInGCjUw=",
      "url": "_framework/Fluxor.Blazor.Web.iqdy5uevtp.wasm"
    },
    {
      "hash": "sha256-wP4CcQHweQbQvb9MBDs5LrkAWwkXbobpXKt+tOdDELo=",
      "url": "_framework/Fluxor.gots0vufd2.wasm"
    },
    {
      "hash": "sha256-K5pxlJkbf1x5oDeFe+ixz1vdLu4WgNO6ibRz9qKCCFQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.frdis2mxg4.wasm"
    },
    {
      "hash": "sha256-EtmNkXEggINcE1Un7oLH/JCuXdp2EY8OTmmbZALuZrQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ul4b1b8v9j.wasm"
    },
    {
      "hash": "sha256-BURB4oaueS4D11NBQEDbr1feOVXYOchLUlflulg2ijI=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5sp2teayo4.wasm"
    },
    {
      "hash": "sha256-QeKeySGHEefQEOvMtJobrZp1qBm1iXSHOr35HrqGg84=",
      "url": "_framework/Microsoft.AspNetCore.Components.bpzg9jjogo.wasm"
    },
    {
      "hash": "sha256-5dLKFNJehwBcQ8fyL5CtPGI74kgAs105j8KCU1Cng8M=",
      "url": "_framework/Microsoft.CSharp.11gbhz98t9.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-5X64MJdbn85UIW0ZVRs0kcitI/5TpKCi+Hn5YZuy+1g=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.l0tomc93py.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-Pmq0WBMgjHXH2dCCDxV12WW8lvXrO4ctTn4jmRDjM4E=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.6zla843dui.wasm"
    },
    {
      "hash": "sha256-9tmL/XPHdZ+Wk8REQsCcROqifFIQm6fY+dCNz+HP9X8=",
      "url": "_framework/Microsoft.Extensions.Options.q4yl2lleuk.wasm"
    },
    {
      "hash": "sha256-iOXJ6xMILdIdSWDD2fNHtnrXI0YtuWx4chp/bwgCVgc=",
      "url": "_framework/Microsoft.Extensions.Primitives.8omryeirak.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-i2NNuy1PimwurDsFzbOtebAE5XaRagwFiN+BAMJI66o=",
      "url": "_framework/Microsoft.JSInterop.fbbpyjtwh3.wasm"
    },
    {
      "hash": "sha256-YTClAmn7Yn87tjPZjaW+lgo+yxcpipBgKzp4Rw494/w=",
      "url": "_framework/Microsoft.Win32.Primitives.p6zpa6xuil.wasm"
    },
    {
      "hash": "sha256-n1DGlrxsDyEOE9ZJimNPCQuAvCnNqZKq/WmH13naJvU=",
      "url": "_framework/Microsoft.Win32.SystemEvents.fsq8rzntw0.wasm"
    },
    {
      "hash": "sha256-l2qEfPM/BjYyiblhUW+zUgDUT7vciCSwbC6Vj2Klbeo=",
      "url": "_framework/MoreLinq.zdi2h46g68.wasm"
    },
    {
      "hash": "sha256-2JOU8zeWdEZTA4obwcsoIEQUNMQqugVLX0xg5jhcn4w=",
      "url": "_framework/Radzen.Blazor.sz5uao3t1x.wasm"
    },
    {
      "hash": "sha256-Ru4ZF7km+hWPH7Xztz7vSu4el147yZEKLx20rqQ2ltI=",
      "url": "_framework/Shared.md9tl6vl9w.wasm"
    },
    {
      "hash": "sha256-owhhFW/UE/vxeRf6XOr5XbvzRShsI6t7SABbJa5HIgM=",
      "url": "_framework/Siteswap.Details.l2omw5sbzg.wasm"
    },
    {
      "hash": "sha256-WfPO7dC/QUaJ/hoD4zKpTiqT5VVdAKsWUB3stFk3E4Y=",
      "url": "_framework/Siteswaps.Components.788038ifmp.wasm"
    },
    {
      "hash": "sha256-VG5TPSFmrxM274Q6DJrF+nmQVIxOAmNQyuDNOuLm55k=",
      "url": "_framework/Siteswaps.Generator.4g10vq0db0.wasm"
    },
    {
      "hash": "sha256-7NTqb7pi4uJaaxSuMaHorqjBqkZE3IkwphDT8F+FIU0=",
      "url": "_framework/Siteswaps.Visualization.kmwrnsdnsm.wasm"
    },
    {
      "hash": "sha256-eV3F6NH5/nfLcQMQAloe6sGD4/VtH983nxzPYykRU30=",
      "url": "_framework/SkiaSharp.Views.Blazor.74nar1fiep.wasm"
    },
    {
      "hash": "sha256-YpiBjyOkEX60o700c0IrZjeEkLxyWZm+w09gBEoO2f8=",
      "url": "_framework/SkiaSharp.mislgdk5az.wasm"
    },
    {
      "hash": "sha256-k46YDqsBQ84522ERaK6jUsIe7mlIJ4lIxsWnckhxyvw=",
      "url": "_framework/Svg.3wlfysmzyb.wasm"
    },
    {
      "hash": "sha256-mnGtUMBNvStqULzvqZhBxCYgBKXWHcsZGJ33qucDawQ=",
      "url": "_framework/SvgPathProperties.ebwgyay2jc.wasm"
    },
    {
      "hash": "sha256-nmhUPBjB8ZbEN0U5j2acgnW4fkbSYlov7U3e30Lsp8A=",
      "url": "_framework/System.6bp5k9v1ih.wasm"
    },
    {
      "hash": "sha256-YQyFsKeonZB46H+IZzfCukS6kkN+QGmOBm94Kn3zZOw=",
      "url": "_framework/System.Collections.Concurrent.pexpbn7yix.wasm"
    },
    {
      "hash": "sha256-srKIKgxKqG7696iHMqy83L1T0VY+f9/92ZKYEj+uD0A=",
      "url": "_framework/System.Collections.Immutable.qdixq29tvf.wasm"
    },
    {
      "hash": "sha256-Datnin36mCCveAdCFwz/17zdq3ixEIM2wXUBALVq9Ok=",
      "url": "_framework/System.Collections.NonGeneric.rea55nbw24.wasm"
    },
    {
      "hash": "sha256-WY58y6kHc2Kmh0wd4CgoiJuGF41YyyjYntDEKkC2j90=",
      "url": "_framework/System.Collections.Specialized.jd0zxltmzr.wasm"
    },
    {
      "hash": "sha256-xi0JaDwZ7W/hSYs3QBzHzarxQB/lnQhWQXCSO5H0aw4=",
      "url": "_framework/System.Collections.yeqqq8dud6.wasm"
    },
    {
      "hash": "sha256-r0aqQF7LCCyN277oQe1JXF+JIRqbcZG8T8cTG0XZE50=",
      "url": "_framework/System.ComponentModel.Annotations.dl587pkdky.wasm"
    },
    {
      "hash": "sha256-ql1BGccQ1qa2XvXN4oh48Xcts197tb/TuQuPvzPk+sg=",
      "url": "_framework/System.ComponentModel.Primitives.ei0rjl4jiq.wasm"
    },
    {
      "hash": "sha256-qCsCvhXtOP8fhvtreuAzA7FucQ4CUi698Ge79yYlvhU=",
      "url": "_framework/System.ComponentModel.TypeConverter.gq3fn9nf65.wasm"
    },
    {
      "hash": "sha256-WpICUPAzU5ZLpaW8OWTsJnTgo8gidkkK2uj9K6RG3/k=",
      "url": "_framework/System.ComponentModel.q8ywh73jxw.wasm"
    },
    {
      "hash": "sha256-yoX9HpRSJ2VqFDfZt7Weg8PqlPTCMFrBonRQ7sgfyPI=",
      "url": "_framework/System.Console.qodel1rbbw.wasm"
    },
    {
      "hash": "sha256-vsTs7klbhnnwc8V4HeTq8ghSvndyhUTGwZsmA0sDHxs=",
      "url": "_framework/System.Core.upy2331lm5.wasm"
    },
    {
      "hash": "sha256-DpXnRV0e7N3isu3DTTwiq1dfwcbaXACcMfM8QWO5L/g=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ay6j18k77x.wasm"
    },
    {
      "hash": "sha256-Q5VDkQLAhGavC3Ua1qWMHVaqF8pTelJQ/cxD2JqCT3Y=",
      "url": "_framework/System.Diagnostics.Process.hnnki5n7l2.wasm"
    },
    {
      "hash": "sha256-XlSd0o+rEwCKjA0+JwPeJi2qsYIKZaNG3ifa67Cvxi4=",
      "url": "_framework/System.Diagnostics.TraceSource.qqm2k66wug.wasm"
    },
    {
      "hash": "sha256-UmOKXys2ycEew1eIehBnh1Ps4VWdgloSacnXu9l9r/w=",
      "url": "_framework/System.Drawing.Common.e9ggxjkqjx.wasm"
    },
    {
      "hash": "sha256-nlb7zcXtvwBY85f28CszWJmvPuqVsPdIkPCxnQurBCA=",
      "url": "_framework/System.Drawing.Primitives.uo63uh97g2.wasm"
    },
    {
      "hash": "sha256-7OYyS/EvxxJePK8hvB0aD96TeLlyptw5TWV6IDYwhc8=",
      "url": "_framework/System.Drawing.w36gg13qvp.wasm"
    },
    {
      "hash": "sha256-H/Je1Qk8nE1DQ+U/1qLXy6ajDLk06Pw2a6D4bMDk0Rk=",
      "url": "_framework/System.IO.MemoryMappedFiles.j79e8x261p.wasm"
    },
    {
      "hash": "sha256-JA6sPl6GA5NH8pNdn7k4E0ophulug+EchR9kvweDkS0=",
      "url": "_framework/System.IO.Pipelines.g5ih8ovpg3.wasm"
    },
    {
      "hash": "sha256-c+20tL5bIZpWZzMYp+VbKJmexOE3ViGChp9yQxz8d5I=",
      "url": "_framework/System.Linq.3ccwrf5s47.wasm"
    },
    {
      "hash": "sha256-CH9HlSymBG/b7dH7jcPxKNmsHaT3OBrjgrUGQqTWkBo=",
      "url": "_framework/System.Linq.Async.k9im717kse.wasm"
    },
    {
      "hash": "sha256-zY4O55eQ9gC1F0jl4MFsfpX6oCP3eabUwmK1PIrgx3Q=",
      "url": "_framework/System.Linq.Dynamic.Core.v56k5wbbs8.wasm"
    },
    {
      "hash": "sha256-4qEfymsjNxV+ZzNMh+EyNQTuKL2CjHtq/c8nLbb0RJ0=",
      "url": "_framework/System.Linq.Expressions.mvve1yu338.wasm"
    },
    {
      "hash": "sha256-8+EDGZut0cde3lpuynrxial9skMpzbFPvXVXJqFL6MM=",
      "url": "_framework/System.Linq.Queryable.3kaainw2wr.wasm"
    },
    {
      "hash": "sha256-OOe+L4RWmcBtySHYsGe1o2P35Dc4BUe8993XLydII9A=",
      "url": "_framework/System.Memory.wy93yoh7mb.wasm"
    },
    {
      "hash": "sha256-qP2IBT6oNMe3LKP19EU6csD/XwTHq6xCSMQV80L0smc=",
      "url": "_framework/System.Net.Http.80dell6j2e.wasm"
    },
    {
      "hash": "sha256-rGsc0Rj+aWTuEy/xrVLyqYbtC/7f6oRKD/zu7TpfU0Q=",
      "url": "_framework/System.Net.Primitives.01n7ob4nyz.wasm"
    },
    {
      "hash": "sha256-uYwUgpiOEGehEWuRRq0kXDSaD2MMXiCfTC6aCB7dmig=",
      "url": "_framework/System.Numerics.Vectors.nop1vf2gir.wasm"
    },
    {
      "hash": "sha256-SeIFk2r4Msa+24JHI/iObm2W2Ojn4k7IQr5An1JfWx4=",
      "url": "_framework/System.ObjectModel.r37fo5ww1i.wasm"
    },
    {
      "hash": "sha256-U/SEV7FQu/5rRxOWUzxixZfG7S/QBQ/KrPIjYoEDR/0=",
      "url": "_framework/System.Private.CoreLib.7zu6mrfw73.wasm"
    },
    {
      "hash": "sha256-WJuC56tdG988mNg1wXCGO34QOiaAn+olJ/4lBKgS3io=",
      "url": "_framework/System.Private.DataContractSerialization.wi3qbbxsth.wasm"
    },
    {
      "hash": "sha256-Fq8gO1gC6N4rFuJ2p3X2+BtUbHbGNmYjYLzSsmqVnEo=",
      "url": "_framework/System.Private.Uri.2lq6nnf70x.wasm"
    },
    {
      "hash": "sha256-mSlUely/6iu2xeUC4F5asK7VmC1VhAjLpGAozZPSy4c=",
      "url": "_framework/System.Private.Windows.Core.zhe0h333oa.wasm"
    },
    {
      "hash": "sha256-tjDlTNg/HPm2m8q0Q385avxQV+N5uHKPSjoUww41e6s=",
      "url": "_framework/System.Private.Xml.6lprtuqkc8.wasm"
    },
    {
      "hash": "sha256-Gxq+HubpmXUmJVS/hjxXljki80v36mY9p20yoBpYQzQ=",
      "url": "_framework/System.Private.Xml.Linq.fr01kfv53k.wasm"
    },
    {
      "hash": "sha256-XoAwpsDdffD6HOOUoL9rHEEUkwWzFVLa4pMtm9EEMGE=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.y43jlprgfl.wasm"
    },
    {
      "hash": "sha256-yE/8McjfrOS8bz3ZqcEGCTVgcMoys3qsqoUQDdIViSg=",
      "url": "_framework/System.Reflection.Emit.cn3bd7qi0n.wasm"
    },
    {
      "hash": "sha256-96Ee8FMLvBoBCgrebA8COZOi9e4K1cc/oUzv2gWeXLs=",
      "url": "_framework/System.Reflection.Metadata.f610oh6hea.wasm"
    },
    {
      "hash": "sha256-YQDKI2k1d6ATDOvjsrM7U4AN4tjTJw6nlAo/0GnC1rQ=",
      "url": "_framework/System.Reflection.Primitives.pi8p9sv67y.wasm"
    },
    {
      "hash": "sha256-jGXd3r0kryiqPMj+xaFukTCHB66GX++iH+WoWV2R308=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ortnca79qo.wasm"
    },
    {
      "hash": "sha256-GzTPQh/umeVbfus8CTkHtZbUjuynJYUSNah4ErbQL1A=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.zuwj7cjbjk.wasm"
    },
    {
      "hash": "sha256-+zjhycR8PSuRx0ZUPV/r8eSqr1/yLWbNqwQSzFq+VmI=",
      "url": "_framework/System.Runtime.InteropServices.pjkw3lk4x1.wasm"
    },
    {
      "hash": "sha256-xLeNk8AXM/K7JPVhhxFW1zxfNDOwideZioXy8NpkhZI=",
      "url": "_framework/System.Runtime.Serialization.Formatters.skhhtaj8gh.wasm"
    },
    {
      "hash": "sha256-6VovIEMZ6jeBrwgZIsMT69ruya5LnhGkTGjiTPBu2Bs=",
      "url": "_framework/System.Runtime.Serialization.Primitives.j5tuanjyvh.wasm"
    },
    {
      "hash": "sha256-jyk2pvHE3BoVzBhVrVKMslOGgSFDBq9V+RkeMLAVsro=",
      "url": "_framework/System.Runtime.vot15e07ol.wasm"
    },
    {
      "hash": "sha256-tvEHYSg4et4UZxvTobQ87UdIEBxn2Ab3Td0HOEnINHM=",
      "url": "_framework/System.Text.Encoding.Extensions.6sc4w2va2i.wasm"
    },
    {
      "hash": "sha256-K0a2+/Q0wj9REnO++W2ZYzEFcZ1KQ3XU4J2ggDQoOiA=",
      "url": "_framework/System.Text.Encodings.Web.7hk6pkd9k5.wasm"
    },
    {
      "hash": "sha256-B1kS3wRjMDH44DomKNsy4bxXcuzfTyqkrMTguOjm3wo=",
      "url": "_framework/System.Text.Json.tfohxsih8o.wasm"
    },
    {
      "hash": "sha256-ZF9ogwtAPBOGxZNnhUJ1wlddVMa66pBRXVlAibwp/zo=",
      "url": "_framework/System.Text.RegularExpressions.c83tvflquf.wasm"
    },
    {
      "hash": "sha256-pAeVaHR+GMNmH0HYFou87tXHtKU9Ibfw84MJ/kYqfz4=",
      "url": "_framework/System.Threading.0xgsb68ius.wasm"
    },
    {
      "hash": "sha256-9+ESbpF9WqseVAn1ROhuL7MCjXhEXWOTp8lq57NiSBA=",
      "url": "_framework/System.Threading.Tasks.Parallel.f61ct1bbit.wasm"
    },
    {
      "hash": "sha256-dntizySw98t70xxX9kZmRAoNrsNDYTJmjV0SFaYy8eg=",
      "url": "_framework/System.Threading.Thread.29b65ixh3u.wasm"
    },
    {
      "hash": "sha256-JNwY9ymWcfzQOoEPDizXA2d7Uik3Ehq57OVHW6mg4ww=",
      "url": "_framework/System.Web.HttpUtility.072zm64hke.wasm"
    },
    {
      "hash": "sha256-50dVChh2QJYCLLia2vmYR8/Cyxw2D7Y5dFwnnzVUiZ0=",
      "url": "_framework/System.Xml.Linq.bbx5kr3gw0.wasm"
    },
    {
      "hash": "sha256-Whme+liCiSB4LP1WwYzMLXnXBaWaYm0Y7Pm3jaml6BE=",
      "url": "_framework/System.Xml.ReaderWriter.yqpcs4uks0.wasm"
    },
    {
      "hash": "sha256-k1o9Mfqf50cxtPyrISfIbbqE/sEZWR4QnXXtl4CURrQ=",
      "url": "_framework/System.Xml.XDocument.3cax41wye8.wasm"
    },
    {
      "hash": "sha256-GqbYZLBITO3dqqsJ4DPwOeElXCpYNCbHhlrTpj+c2wY=",
      "url": "_framework/TextCopy.m05mv6487u.wasm"
    },
    {
      "hash": "sha256-ULsvyv7nl6doDq/7V6xScA4P8bEScbsCcPFBlPnaS7Y=",
      "url": "_framework/VisNetwork.Blazor.4fraq2v2tj.wasm"
    },
    {
      "hash": "sha256-4o0BU32lzIgiK1tt1uQNy4HleQW1q/hg+JgsaaRNVvc=",
      "url": "_framework/Webassembly.2c7r0wza8d.wasm"
    },
    {
      "hash": "sha256-JOQmjiQN2ihdl5SvSAmGL1pLSBwbrWj4kUMETpMkeqE=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-GbKWK+esqeL1E24rCVsCvsQCzaJM65aknWOT1UhUYa4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-WEBsx43VFEV/VJSpc0n21+cjwGpY3feQqLGpNPgSHng=",
      "url": "_framework/dotnet.native.c7tqa0a5fz.wasm"
    },
    {
      "hash": "sha256-zV6wdZxlgLSgDDeZRNR99FcQF6SouQ0GaNcmRFjqO3s=",
      "url": "_framework/dotnet.native.j88m6qeqgz.js"
    },
    {
      "hash": "sha256-uD1t4tsPtmIHsx30SC4OztehGGaHVDksFD38rL2e3P4=",
      "url": "_framework/dotnet.runtime.o8gq1i8bk6.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-4GTAZZst5z3A3rrl17Lil8P9g7mjAIclFSDvsrrW8Rs=",
      "url": "_framework/netstandard.k7h4frbs4x.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-09VebyP3cmcqW0qsQOmksCQiWz3PxGUhZ2dYCX482eQ=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-RjGqlb+v4hs6Z8DhVwFlLwazJijnGl/PtULIRisOQfM=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-G2Gt/NEghVOb03D3TQ6vquZsg+CQiQ/oUFIZblldNJQ=",
      "url": "sample-data/weather.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    }
  ]
};
