self.assetsManifest = {
  "version": "oJO6Yj56",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-f028uc2y913T5CHs9m4/BRg8QiXMvF5j8UWuf++bHxI=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-Iwb8JSLjk7Czwmc2t7PCspmhKD8/O5CxPnavVqy7hos=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-xkTDeVREAEK0DMnNe9AqoTKpbfa24bXrPcOPOixg0qA=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-ePb6nMgeJyFTPx46bzXwAzJEFghQ10QTEpF/lKlfHk8=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-oUqzDxYNe80U+p/qGo910JR5uFQIteOxLz1nRjlOAi0=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-jrmjkEodn2+wgv81t8A8mWa69vXzQOiO9rFEOxNF/1A=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-Y68bSDnl3YdhofYW49t6as4WRxDYshlZAAaswG0H7Mg=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-lYiMLG73UrqjeD3Xr0zwkygnPDSAQXeAo1554Yjqjkc=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-XQMs498wg+6qpbKWzM1iN8Hd7/VPvC3sWc8xUxUPXdI=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-NygjhSUlfsTDX5CQs8mBFU5gct/uFnLPciXyItgcAIY=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-tKIiAWZpYEHp8VKx+w880Y7gQJf3T+N7QYnFLjz9sV4=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-+PA/TMpN+uUgTwqwLmA/nfoyXy9AzOtxFRb9Ejy0j6k=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-q22qt3Fc3vH9p+5JX4eOK7bD8QLJ9pJUfnzsUL1U4tM=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-J8kJYxpBFMrMjHMBSdDlq1lYqyntxOrDZ8AW5FrxH8U=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-F+1PUL0oZn9isIDXKBXT6AsDjrZ+k/ZlgHvpk4qv5h0=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-y4Z34nJS2wVRkJegJweZW3I77wgsnnLEhHQQVJTj6uw=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-Y1augwmb0gWg/E+MRnE7uRbpdoa/mfNoiFB6CjCPqAc=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-mscmBJFsTrAe0H/SoknylPnukiQX2yfQ/zSnbR4B75k=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-54YQ3J6Q8S+MIbWfotuo4Gt0r+x5LO62tqyZUP+/Tg8=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-y6x9nQqkv3mW+Dvmm6Pvh+h0ixHfY0RLzrX6ZlktoG4=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-4N97x0l/mg5xkcGhfhcKyEicSbmRH7Fpowe0fOMehy0=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-zUj85J9E5sExVQ7VO3W/NIJ5IeO7N8hcwI61NcW2zEQ=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-OupwwJyfvZ0qDkVrxxMhVkViaYiW0T4sxDA9Fatboxw=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-mHh6OGo9cpMZlZptx+gUmbVAY28oSpRtDR7lsb98WKk=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-OUQjzic9++/8iHzq0aMbc8G5yrKtXZLkMfz8TJ9Vz/0=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-tRcVAq9DGc0nyvTuxUpiBTY8PaxnC6deHLSE8Ri1PMg=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-vRoJw3CE+re6yZ/axSnBsZ/4+UH/csLGmxsROuTIlgY=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-5b/loSylJ4zvdfG2ngIwWuIUAma0i4vaLq7f6ijGC8c=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-gc9405+cUBREnDCK5QDWBnYmHLEd97jL3m5lVfwQgDQ=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-HYNTnwNf3xj899KPdiKwmD1e5t3XRg9VaQgB1ZOvKeI=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-wC0utcJSDzWehLAmPISRtkgwte0g+YhYkhHq9lDqqQw=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GFU2mt0A9T8j9YMwMQqIUmdziKNDuPppDCn2o37LV2E=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-MqWf42csNg7OVfZ8PNlybT1LssWH3OJ7nm4jRFByYFM=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-+eSpwuS0Mx0DVjyuFo3DoQXiI+Mp+4I1MtdWSbDcZK4=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-8kZcrnldrkkLW30p/g/K9p+NC6jEXOKGglC2qZfmqDE=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.ulmmvjocnf.bundle.scp.css"
    },
    {
      "hash": "sha256-jvdEwbPP9ySWwm0cTSiOqdIfO15rtDmoxKmiqmFQR/A=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js"
    },
    {
      "hash": "sha256-y7L+XtwoUJtcUnvXGeRLVrLj2uLMTgPyNKJlEJnFbpc=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js.map"
    },
    {
      "hash": "sha256-pCIEjwDATOwa31+YvucoW1WTxT4YiQVDFhw94hu6wx8=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js"
    },
    {
      "hash": "sha256-MTgEQwaemErPPoFSvy9/AvhoR7QaOAVkSgXh+Gs5jmY=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js.map"
    },
    {
      "hash": "sha256-la7lyIF2RfLmzbgQq451BnkJEU/wykMPE6pCn8Po4pI=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js"
    },
    {
      "hash": "sha256-HQWKRYNJ6U0CQ6cjuHiZNYzn9EyBxinvWwT2zctFdWE=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js.map"
    },
    {
      "hash": "sha256-YQqC+x+db2pnQw/gibR4ai58y8WWbVsaiM7Dg/5ZjmQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-YEIKzZHjTFrB0PdPq+MUTCQVa9BXJOk4GoWEv21FNno=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-eM8DTi6b6DvS8NIedSLSGsOM4Y0OGeQUae6fmc0F5HQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.map"
    },
    {
      "hash": "sha256-tmxVjsHcxYihEtmXEJz2gJejcMpa2tNP2K5IAMBUwls=",
      "url": "_content/Z.Blazor.Diagrams/Z.Blazor.Diagrams.ezdqu7jd9f.bundle.scp.css"
    },
    {
      "hash": "sha256-s7EEPdhBW2P8sjiCOtar0D9cqNeKSPOwBxqj89twi14=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.css"
    },
    {
      "hash": "sha256-tjG7h09kCbOtLws3pLFB95nmOYxMZl7c8jbGPTarGBc=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.min.css"
    },
    {
      "hash": "sha256-DPGv+cCxzPgtITUub8yFS2/hFYsTZvuV+MX2hT1/C58=",
      "url": "_content/Z.Blazor.Diagrams/script.js"
    },
    {
      "hash": "sha256-LgAw9yB0DF0MNdupxctpNfEU7NoB56YJnh9QpuwRcI8=",
      "url": "_content/Z.Blazor.Diagrams/script.min.js"
    },
    {
      "hash": "sha256-EntOrNcHrVMAVfWpFhvF7p3Dlm2ljQBZcZQoK9/ENig=",
      "url": "_content/Z.Blazor.Diagrams/style.css"
    },
    {
      "hash": "sha256-UKzIp+VqUElrrWqYXITbK2mVVp6d5hx2LP+pnMfozLA=",
      "url": "_content/Z.Blazor.Diagrams/style.min.css"
    },
    {
      "hash": "sha256-qbG0STeTRSjScVJ9SBP9y6zl4YpUsBt317lGajCmB8Q=",
      "url": "_framework/AutomaticGraphLayout.Drawing.rfmvbsf468.wasm"
    },
    {
      "hash": "sha256-G5FHc2TipvCo7po6ZTAuX5MXPHgkB4E+CcQNvwSgIvo=",
      "url": "_framework/AutomaticGraphLayout.xhitsgdb3e.wasm"
    },
    {
      "hash": "sha256-W5jAEh1BJpID2KOjfMO9vOPVsdrYaro2ijjK6RlgFTc=",
      "url": "_framework/Blazor.Diagrams.Core.z625myqj9k.wasm"
    },
    {
      "hash": "sha256-zGXooQdLm05nUxu/a1HW0N8h1onvcACfrPx+R+fpsFI=",
      "url": "_framework/Blazor.Diagrams.ckfoh8zkyc.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-4Oeo8/KDTym/CblLRv6nEV9S1CDpm+rU4UjbGfjgDyM=",
      "url": "_framework/DotNetGraph.8ylozkoln5.wasm"
    },
    {
      "hash": "sha256-UUDdQpFUY9H2fvZxvGhWLfifbi0vztUkLr14L1HLE9U=",
      "url": "_framework/ExCSS.vo340561u5.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-EBslmZvfsvpTBdvOmv3rEOEg7Pc+HAABf7+3bJOokfc=",
      "url": "_framework/Fluxor.Blazor.Web.cl1oh36s39.wasm"
    },
    {
      "hash": "sha256-APyVBDq93FhhHXOm8kB0Guo/oYk+VcKmObk/+HK6CAI=",
      "url": "_framework/Fluxor.spaznd1495.wasm"
    },
    {
      "hash": "sha256-Nh17pnLD3GP2Yyzf+0wIvhA1baSdi4m10/ci+69HDhc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.imqknm5h5r.wasm"
    },
    {
      "hash": "sha256-6wHBBaxKXJgvLQXmPKnYD+n4B+oT3IWflpZvrXOG2ew=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.nlq1pzu3c4.wasm"
    },
    {
      "hash": "sha256-lFa9xXepJk5e7Z68gIzH4jRbXdx+IRD8N8qEW1pzWIA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.83qq0c2igv.wasm"
    },
    {
      "hash": "sha256-Jv/sMGqYKf/E0zlEl++DkTqcFitCVRVHAbYqAgC1VmE=",
      "url": "_framework/Microsoft.AspNetCore.Components.i284v43vwh.wasm"
    },
    {
      "hash": "sha256-B8IangUERK+Pw2BxuunqdGQ7NIuTQtB3gGJxzkJJSAE=",
      "url": "_framework/Microsoft.CSharp.d3wewh26us.wasm"
    },
    {
      "hash": "sha256-VcpjgiVQGVhlsFFL+GzVh/tl1ycxkiTzhb3zMyKI0Yg=",
      "url": "_framework/Microsoft.CodeAnalysis.CSharp.p31rc0goqn.wasm"
    },
    {
      "hash": "sha256-UrCKIA7ySpcVuJFCzqzHYPujBSMtSeyQCqfCmliSttY=",
      "url": "_framework/Microsoft.CodeAnalysis.ux1aktmc0y.wasm"
    },
    {
      "hash": "sha256-XmI2e4usTUn8mjG/nUVaZbYCmaAS+ClB/WG24O4bc9k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.qycoarjeru.wasm"
    },
    {
      "hash": "sha256-i4UmIVmRYt9sXQYxprJFXFivAl11xAcf9azr6KH7EOw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.j66pezmcjo.wasm"
    },
    {
      "hash": "sha256-FaaaOUKTSpAYkiRXlXvtko5FVnHLdZR5AardvxtziDM=",
      "url": "_framework/Microsoft.Extensions.Configuration.pvawjtuhi4.wasm"
    },
    {
      "hash": "sha256-D23orXdJMPxOz2IYSzx+p7py9Oq/4UgVcGexisMbdb8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.v8xv30xz1o.wasm"
    },
    {
      "hash": "sha256-Ta3surCTEATmQUY4SQ/wpAIdyxK5fNnI4bm05ePwAsw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.vdgbrs4or0.wasm"
    },
    {
      "hash": "sha256-Sz6VMIRSae0gQA3wmOXNUfTECvZ3ypnE8PEzwSqPb8k=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.vbuziuf17i.wasm"
    },
    {
      "hash": "sha256-m2ci2/3UUoSj+LBjDg24wAVdJ7/OshaoahXtPt74ak4=",
      "url": "_framework/Microsoft.Extensions.Logging.dypcmt2k1c.wasm"
    },
    {
      "hash": "sha256-lzKAqT1IplKru8kCF6TqrvE4vx6KsSmOvEC2N0LPYO8=",
      "url": "_framework/Microsoft.Extensions.Options.pciamnodx7.wasm"
    },
    {
      "hash": "sha256-zPXs1ZxaGv/gjScqkSbos0m3HyxJufpF3haxdyuT0QA=",
      "url": "_framework/Microsoft.Extensions.Primitives.wdgxpgsqcr.wasm"
    },
    {
      "hash": "sha256-63bzxZLVvNOmTsso6iLrptxGmKBQh2HUIEGtPUrRPeQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.lsljofql11.wasm"
    },
    {
      "hash": "sha256-Ca0MI/Gtb9BdRoj0uesn2b9CNZxiGE7YJS1dbyiuiic=",
      "url": "_framework/Microsoft.JSInterop.huodaddut7.wasm"
    },
    {
      "hash": "sha256-gB8vHGRFFiw+63fVR2xiI25rqX5Jmn7VsceipGFyqJ8=",
      "url": "_framework/Microsoft.Win32.Primitives.0c9h2xngu1.wasm"
    },
    {
      "hash": "sha256-jBbO59Pk7m6OWiTwPycB0F8NuJfalrxfiDI8uUuo0oA=",
      "url": "_framework/Microsoft.Win32.SystemEvents.0x99na7ga3.wasm"
    },
    {
      "hash": "sha256-l2qEfPM/BjYyiblhUW+zUgDUT7vciCSwbC6Vj2Klbeo=",
      "url": "_framework/MoreLinq.zdi2h46g68.wasm"
    },
    {
      "hash": "sha256-aBx5C80VUpSyrATybkZwzen89LjHbmNkrG+Y0mMi1iw=",
      "url": "_framework/Radzen.Blazor.0m8s1ye2k7.wasm"
    },
    {
      "hash": "sha256-eplIztK6b6PYMbOvjhk6VDAM+yuqkRvAfOnEGC/zdiQ=",
      "url": "_framework/Shared.qvdpsq1woh.wasm"
    },
    {
      "hash": "sha256-h2puYfRYCjhDLRThi4yUOcizTL5njADxDRYbeX8zFCU=",
      "url": "_framework/Siteswap.Details.vqk2973d1l.wasm"
    },
    {
      "hash": "sha256-XXLGL4wn9v59aizUxt0I0aP0qq/OEWK1U2L6MO4KSFE=",
      "url": "_framework/Siteswaps.Components.tkz9eed3tm.wasm"
    },
    {
      "hash": "sha256-hCUvd9mzieb7Kvjo3LSAB2V9khFGtmBh10tB+PbIkaE=",
      "url": "_framework/Siteswaps.Generator.8l8wbfqbod.wasm"
    },
    {
      "hash": "sha256-7Ll9B+p+R4kP2y8S8BeIClGmqjvQVRK7Riak14/kAeA=",
      "url": "_framework/Siteswaps.Visualization.8xcyonbz5f.wasm"
    },
    {
      "hash": "sha256-eV3F6NH5/nfLcQMQAloe6sGD4/VtH983nxzPYykRU30=",
      "url": "_framework/SkiaSharp.Views.Blazor.74nar1fiep.wasm"
    },
    {
      "hash": "sha256-uR6oKkgUwjDk1/tUffARfYBE2e0hbro7wn7QpNvF3lY=",
      "url": "_framework/SkiaSharp.j5guk4pyiy.wasm"
    },
    {
      "hash": "sha256-k46YDqsBQ84522ERaK6jUsIe7mlIJ4lIxsWnckhxyvw=",
      "url": "_framework/Svg.3wlfysmzyb.wasm"
    },
    {
      "hash": "sha256-mnGtUMBNvStqULzvqZhBxCYgBKXWHcsZGJ33qucDawQ=",
      "url": "_framework/SvgPathProperties.ebwgyay2jc.wasm"
    },
    {
      "hash": "sha256-Un0kXut/rdOdd21vCA8cviPLzRGRFiK3+1gJ4YZRw5I=",
      "url": "_framework/System.Collections.6mxaqsbvsp.wasm"
    },
    {
      "hash": "sha256-+jzx1Ywqf/R/zAXHA4RZs1aUvADTYAY0UYQ0ZjLcCnk=",
      "url": "_framework/System.Collections.Concurrent.ymgnxqqa06.wasm"
    },
    {
      "hash": "sha256-W4T7Q/o9Pi2WtlmKkiuLSVsPK5XpB7RHnUiio1EW8uk=",
      "url": "_framework/System.Collections.Immutable.50urntu3om.wasm"
    },
    {
      "hash": "sha256-BdBdQzbMnFdNRFUjyzPWjv8zCIt5q8wWX3UYyDaG+eo=",
      "url": "_framework/System.Collections.NonGeneric.l4ajy19iyp.wasm"
    },
    {
      "hash": "sha256-RHksO4PuBl4YwS2knh4+aRvSGYCBo84+p9WBHGQf+kk=",
      "url": "_framework/System.Collections.Specialized.wl7rqom4nh.wasm"
    },
    {
      "hash": "sha256-DFJntwUHseBjN9KOsWHbf4AOHZkA+35NL663BUUoIFU=",
      "url": "_framework/System.ComponentModel.Annotations.sotjtadn8x.wasm"
    },
    {
      "hash": "sha256-1XOReYPWpr38x9XVlQM8CI7ixdMmC70YZ9TnIElJgEY=",
      "url": "_framework/System.ComponentModel.Primitives.rwt7djq0qs.wasm"
    },
    {
      "hash": "sha256-TigoGPyR2XWtZ6TsZ6/FhFov+ugvwE0tBRPdoNsNPEA=",
      "url": "_framework/System.ComponentModel.TypeConverter.mvcujyc3yo.wasm"
    },
    {
      "hash": "sha256-6f2Biny+SKrMkYL2siUt+TaDmORTFcMXp4MMJ3fFxDk=",
      "url": "_framework/System.ComponentModel.rb3t0jy0j7.wasm"
    },
    {
      "hash": "sha256-5JmkyTi3SGgoxg7deJ5UuMkq3UEwzUiRGDhS3LgXB44=",
      "url": "_framework/System.Console.gtkehqu0iv.wasm"
    },
    {
      "hash": "sha256-4GkFCX7RWkso9O+YvNL0YV/fhGS5WiRCxZN/GbOH4NQ=",
      "url": "_framework/System.Core.4jz0uajxxp.wasm"
    },
    {
      "hash": "sha256-qQBSIukM56HeEESc0I03rqi3+of1LXXN+jTaWBDJWbw=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.rfqy1pa4ud.wasm"
    },
    {
      "hash": "sha256-zI/U9CqAf8Rm4A2Nnwjb0dV7YEw8DUUsTKT5a4h307E=",
      "url": "_framework/System.Diagnostics.Process.0b8rxjk8uf.wasm"
    },
    {
      "hash": "sha256-c/Wvh9TpIIY5/U9+XKATqS+ueaq0owqUy0oIrW9yAs4=",
      "url": "_framework/System.Diagnostics.StackTrace.fx0vrxotwo.wasm"
    },
    {
      "hash": "sha256-jtx9SZtMXpxPc9u/ALaByt5g4bw9TWHOwoszuhlDDDA=",
      "url": "_framework/System.Diagnostics.TraceSource.axyzh4shuk.wasm"
    },
    {
      "hash": "sha256-aadRPkhisIg2JMjCN5TfWpQsMyNCb8Qvec7zQT3e2g8=",
      "url": "_framework/System.Diagnostics.Tracing.988fgch0hz.wasm"
    },
    {
      "hash": "sha256-vpju3MwrtwpxAmg8Mdv/Vp3XYsjbAzsKvUnn5y6/Vdk=",
      "url": "_framework/System.Drawing.Common.iv54u5tzy7.wasm"
    },
    {
      "hash": "sha256-YCriDVLLRLpMo6I2ksWK8AxlLRw5pu/rx2zmK1Xal+A=",
      "url": "_framework/System.Drawing.Primitives.kvrtwyl7bp.wasm"
    },
    {
      "hash": "sha256-ducFCgiJEvd0YKqregBanI7SOQY0pHqIYo3WGHyfgj8=",
      "url": "_framework/System.Drawing.qrlpt0785n.wasm"
    },
    {
      "hash": "sha256-UW4kolElMc/FSCAPhpkuadfFzyGvit5txWhlcy8OLc0=",
      "url": "_framework/System.Globalization.7ubbpis6cj.wasm"
    },
    {
      "hash": "sha256-iuP1Kt3yI0AmnT51yDxIUARczviiNvmMcfkjBkjvuaA=",
      "url": "_framework/System.IO.Compression.y6hi8d258x.wasm"
    },
    {
      "hash": "sha256-5V/dcI0S+OTc9T1r2EuBVEmge03UC+vUCCfNWQ6NDqA=",
      "url": "_framework/System.IO.MemoryMappedFiles.vjl46p5pod.wasm"
    },
    {
      "hash": "sha256-uEVVMYx7abWgasKfPzSB6wOMoCpVEVv4EcEAOCa4ph0=",
      "url": "_framework/System.IO.Pipelines.0uhw8kopg1.wasm"
    },
    {
      "hash": "sha256-GxiqH86SXFOFPA7kLv4S8sQLveOWoHxk4YQGgzBwReM=",
      "url": "_framework/System.Linq.1dx0nywgsz.wasm"
    },
    {
      "hash": "sha256-CH9HlSymBG/b7dH7jcPxKNmsHaT3OBrjgrUGQqTWkBo=",
      "url": "_framework/System.Linq.Async.k9im717kse.wasm"
    },
    {
      "hash": "sha256-8gX6kR2XBWCzxTL59zM8Ixmpj6nrpv6CfNXObAHXlq0=",
      "url": "_framework/System.Linq.Dynamic.Core.6ykcdy14yj.wasm"
    },
    {
      "hash": "sha256-h1HhavIS01C3cp4DD9p2vl3nvxSdILjm9anS9VZo4j8=",
      "url": "_framework/System.Linq.Expressions.d7bj7ehigi.wasm"
    },
    {
      "hash": "sha256-VL/FGtWkH/2l0oQxQypeTPXiwJfG4twcVfTP+M9vszk=",
      "url": "_framework/System.Linq.Queryable.c0yy0s39er.wasm"
    },
    {
      "hash": "sha256-e1N+pTy05hCzIh2pbkAIMG/lps/353uiKz5ShgybYjE=",
      "url": "_framework/System.Memory.xlv2k36bow.wasm"
    },
    {
      "hash": "sha256-eBpczgHUcF+t8N+dS0WxkGrCIQK5H35f++tygpVAAIU=",
      "url": "_framework/System.Net.Http.k5o9r6ryec.wasm"
    },
    {
      "hash": "sha256-5fJ22s8mcRnRmxSxEo5y1LX6IzYGAZEd6rBpbmlhyQA=",
      "url": "_framework/System.Net.Primitives.3qbvoenl1w.wasm"
    },
    {
      "hash": "sha256-Torjo9i5c4S7uuk5QkgEdUybT3m3NV5DquhEzPR1euo=",
      "url": "_framework/System.Numerics.Vectors.63syb2cv6g.wasm"
    },
    {
      "hash": "sha256-HD9nCAGHN1fEECNVzczdJGNV/Oy3sgbGxxOLHKpmoSI=",
      "url": "_framework/System.ObjectModel.cqfhrjbqmg.wasm"
    },
    {
      "hash": "sha256-e1hGm79cOpI3TNUgbCcFepKUdPVjj+MszWt4aJmhtfo=",
      "url": "_framework/System.Private.CoreLib.row0vtachd.wasm"
    },
    {
      "hash": "sha256-vxj1ePVCyanAlJ9Aw7s6IFKAZLZd78WZWC06CtPzEZQ=",
      "url": "_framework/System.Private.DataContractSerialization.lb6x5h4w6p.wasm"
    },
    {
      "hash": "sha256-7Ttu8Cza/yRPY4xpd6qTvKRfIXpixGR1BqmnwG7xK3s=",
      "url": "_framework/System.Private.Uri.xj63sb15nz.wasm"
    },
    {
      "hash": "sha256-M2NllIitOkFI6URUPKd4deAx4lgtz+hiCfMw7l/2TJU=",
      "url": "_framework/System.Private.Windows.Core.rilxcby7pm.wasm"
    },
    {
      "hash": "sha256-s9XxdGNaJeYrBM2CKQW1iI36P+4+CjQQSk8VdM9Obu4=",
      "url": "_framework/System.Private.Xml.Linq.fx8mjbkrkl.wasm"
    },
    {
      "hash": "sha256-tLq/I3S8WP1unyaZAHQknF14kTaFsmJDWC0MpdB0tLU=",
      "url": "_framework/System.Private.Xml.or1n2gt0ly.wasm"
    },
    {
      "hash": "sha256-4U28PQ+EpQ8dK77p/J32swBPNR0GPE/h0mHANiWz9Wk=",
      "url": "_framework/System.Reflection.Emit.1giq27je6o.wasm"
    },
    {
      "hash": "sha256-hDWMKOoir5/6ASysh9df0KYEfVZ3zgmxyC+lbBo9yto=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.wjzu7twn07.wasm"
    },
    {
      "hash": "sha256-2iOT4zP0+7URLkmbq4U2UvxFr5dP3/pjeie1KuUTEgc=",
      "url": "_framework/System.Reflection.Metadata.u7swh72qp9.wasm"
    },
    {
      "hash": "sha256-gkIaotTvPbUYkx4Aa+dTzs95Or7dVVNHwyQ9GB9fRAY=",
      "url": "_framework/System.Reflection.Primitives.iop2gd72ad.wasm"
    },
    {
      "hash": "sha256-+hx6zKcUdqMcMJf9lRvlE1Uk30gsN6ZxYeZRiD60KUQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.q06agorruh.wasm"
    },
    {
      "hash": "sha256-rV/FrcWMw9z4pGF+h/gDZDsehu2lOcVItJ99LSA+Wek=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.v5gmhtmki6.wasm"
    },
    {
      "hash": "sha256-ey/0dLH31GHB1gUgRDEc9WJMG7UZ2X04dCe7QLHjx6E=",
      "url": "_framework/System.Runtime.InteropServices.loth82xfaf.wasm"
    },
    {
      "hash": "sha256-m5wiwZL56F7wnht8csqDPuJw9aO5KKnZcXCPjYhXx8s=",
      "url": "_framework/System.Runtime.Loader.hd0m06uo0p.wasm"
    },
    {
      "hash": "sha256-5d1Fmo+1BnrM4NOK3noSt3poXSlGntB7CLYtivRusUI=",
      "url": "_framework/System.Runtime.Numerics.7xrza4hbxa.wasm"
    },
    {
      "hash": "sha256-lvxEm9zQn7ULP+jhtSZaACQ8FehzD8NSwEzGJIZSo3w=",
      "url": "_framework/System.Runtime.Serialization.Formatters.i5lqvsii6u.wasm"
    },
    {
      "hash": "sha256-1MxC5SAHvQCOuJ+3KeS7zloAD+f2IMKlFZMH1DCzROs=",
      "url": "_framework/System.Runtime.Serialization.Primitives.07nzfxs6dv.wasm"
    },
    {
      "hash": "sha256-EXq21YLmh2m5jP1Vz7iqNsA1NoYM6rYPLaeXuSz+Q4k=",
      "url": "_framework/System.Runtime.ney39ndq1t.wasm"
    },
    {
      "hash": "sha256-Chizf+/lQoR4YUMSNZ1sZZNaAdvMIsAz1KElT6FihYc=",
      "url": "_framework/System.Security.Cryptography.ye7qkvcxvf.wasm"
    },
    {
      "hash": "sha256-ysxBl0BI38FDVzhy56YGR3RmBaevRUYdb7BkENqtNu4=",
      "url": "_framework/System.Text.Encoding.CodePages.e7o96pywr1.wasm"
    },
    {
      "hash": "sha256-mP2WOMTKiVYTGgG0NgtxM3E1l8xl8NDMAhn5pqQ1+as=",
      "url": "_framework/System.Text.Encoding.Extensions.o4bhvre84y.wasm"
    },
    {
      "hash": "sha256-1RSjQEUK0B/JzHm8Vxjb5AH7OEd/bRnR03PmVIV8/5c=",
      "url": "_framework/System.Text.Encodings.Web.rsu1x60o8g.wasm"
    },
    {
      "hash": "sha256-XGsyah42vBKWmsfnZwE0yCAvPBnC+SEgBnu9/He1710=",
      "url": "_framework/System.Text.Json.glya3d1a92.wasm"
    },
    {
      "hash": "sha256-h/kbrcynVKel0xnyG9/4/Txx/FHajlP43A8rR3Jd+68=",
      "url": "_framework/System.Text.RegularExpressions.pgux2vtk5m.wasm"
    },
    {
      "hash": "sha256-HPDGCntzUfnAbhQBQ7Pog24uvTVUmMn9I+MZTZB4jzE=",
      "url": "_framework/System.Threading.Tasks.Parallel.sam4a3t3m8.wasm"
    },
    {
      "hash": "sha256-B43TVUmrYQx7lof4ohxc6IsxOm0aZQ6xYM7BczBE3us=",
      "url": "_framework/System.Threading.Thread.bzpue8oxay.wasm"
    },
    {
      "hash": "sha256-+zy3A8wMseqdM+8AkRTM/trSrTuzu+DcELkwk9oteGI=",
      "url": "_framework/System.Threading.ThreadPool.1djwhiu2a5.wasm"
    },
    {
      "hash": "sha256-SthjeyJg89hCOGuqLDsWI0Ls0erL4f1MJtA5E2Dr+2s=",
      "url": "_framework/System.Threading.i6ajahv84i.wasm"
    },
    {
      "hash": "sha256-j73fvnSTctJHs2wHk5f5msQ9jFCM5LUVIhMw7qQphsU=",
      "url": "_framework/System.Web.HttpUtility.nat5q8mr8a.wasm"
    },
    {
      "hash": "sha256-UugB5P9eGQHDIgrdxmssbIT8HjAPz0j6jk7e8xF0pOE=",
      "url": "_framework/System.Xml.Linq.mixoc3e4x3.wasm"
    },
    {
      "hash": "sha256-CS0VHP4OS3WVPns412iA8w8djZoLdfhdHLP8MMGQcvU=",
      "url": "_framework/System.Xml.ReaderWriter.fm95rm8ul0.wasm"
    },
    {
      "hash": "sha256-hcgpkYU+jvlPmdwW0VNTuZujXrPG1aPphghgK5GjkTA=",
      "url": "_framework/System.Xml.XDocument.hlwqx8opy5.wasm"
    },
    {
      "hash": "sha256-sh+P14K5YvC+LDpsEyTyXbyFroIK5MD0VQVkdHvguzI=",
      "url": "_framework/System.Xml.XPath.XDocument.m6itvwq9d2.wasm"
    },
    {
      "hash": "sha256-v1DeJU321NUwk3KJ0Lf8lQA3zwRfrxNommmMBs1s3Gk=",
      "url": "_framework/System.f0fr8djds0.wasm"
    },
    {
      "hash": "sha256-GqbYZLBITO3dqqsJ4DPwOeElXCpYNCbHhlrTpj+c2wY=",
      "url": "_framework/TextCopy.m05mv6487u.wasm"
    },
    {
      "hash": "sha256-ULsvyv7nl6doDq/7V6xScA4P8bEScbsCcPFBlPnaS7Y=",
      "url": "_framework/VisNetwork.Blazor.4fraq2v2tj.wasm"
    },
    {
      "hash": "sha256-LIXcLZtwS+V+iH81Z7THQOQLBJCebrAstTIuAPcGiPM=",
      "url": "_framework/Webassembly.kq3xo7m006.wasm"
    },
    {
      "hash": "sha256-6MzHek4XjbRFnEAjmOJDLDikAPLbRrBmS3cNZMZWCx4=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-NyqJWAQffi5s2B7+jr2gd4NGYR1uGQU3ugVMslD15Co=",
      "url": "_framework/cs/Microsoft.CodeAnalysis.CSharp.resources.vylskahzzd.wasm"
    },
    {
      "hash": "sha256-L3bKdVeK4S0Y6aWqPts668EX9n2zkOL6TqgUzlASxv8=",
      "url": "_framework/cs/Microsoft.CodeAnalysis.resources.vceumzhqml.wasm"
    },
    {
      "hash": "sha256-aoMjXlggVRObU8Fi12eR7M6hky7HTvuodgMZqURQh74=",
      "url": "_framework/de/Microsoft.CodeAnalysis.CSharp.resources.itrvy704bc.wasm"
    },
    {
      "hash": "sha256-7X63txji8CRVNINAmel5bUHinrFp3g7ieHLz2sM9x4I=",
      "url": "_framework/de/Microsoft.CodeAnalysis.resources.to7s51asb6.wasm"
    },
    {
      "hash": "sha256-5TAd2is0AgjjYIAuEN8Bd5ZPoTk8dKE9RRtIQr4H5Lw=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-2mteZ0AjUu35rkNHkUtfya4VdqR9xpYLs6y1sBq/suk=",
      "url": "_framework/dotnet.native.ix7sphec6h.js"
    },
    {
      "hash": "sha256-4C6T3i/fzhm8zaYJv8K4zXS3ywNtePxflp2JpOf4xCc=",
      "url": "_framework/dotnet.native.kju6xcsbwu.wasm"
    },
    {
      "hash": "sha256-dCmS9Zx4egtLYSUgTI3R6gMS+Yg8MkzxW1CgEMJKAEw=",
      "url": "_framework/dotnet.runtime.cymp1amu5g.js"
    },
    {
      "hash": "sha256-NXEmu0iSMse7rCCuGQ37z1EXcx43ZgSZvs2x/xYEjfM=",
      "url": "_framework/es/Microsoft.CodeAnalysis.CSharp.resources.ff6petsiqz.wasm"
    },
    {
      "hash": "sha256-Uh9Oeki14vqSrSMueTb++lYjt1j7RjWJhBExSX/2phY=",
      "url": "_framework/es/Microsoft.CodeAnalysis.resources.me6h21w7u9.wasm"
    },
    {
      "hash": "sha256-l+BbxzrrOid2ArJyD5uSb3KoeUetmb4/Pkh6fIdYctE=",
      "url": "_framework/fr/Microsoft.CodeAnalysis.CSharp.resources.3xb5pvc7h5.wasm"
    },
    {
      "hash": "sha256-R/p6rSzNfHwN9vIXl20l+HdlxjDgJH02ujXITSaAbdw=",
      "url": "_framework/fr/Microsoft.CodeAnalysis.resources.j933nglr8j.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-VWB38g4CaKU00JtNZr5LfBmrfWCTLPagpowJXgNOq4E=",
      "url": "_framework/it/Microsoft.CodeAnalysis.CSharp.resources.xlsme6gyj6.wasm"
    },
    {
      "hash": "sha256-oHeY9/V1n4CJRGTiLT9rJfBAn5S8YHqysdxSeh0MyVY=",
      "url": "_framework/it/Microsoft.CodeAnalysis.resources.g83krw0vfe.wasm"
    },
    {
      "hash": "sha256-3BAXPNBL6akRlFzhYSFgye4I9p+Mb+MBioYO2/SRTOY=",
      "url": "_framework/ja/Microsoft.CodeAnalysis.CSharp.resources.skjrh1aqwb.wasm"
    },
    {
      "hash": "sha256-Cc4fdG4NwA+RTo9DT7F9Sbhv0kpsKZ3S7Nc5RT3rasg=",
      "url": "_framework/ja/Microsoft.CodeAnalysis.resources.7swctlh1au.wasm"
    },
    {
      "hash": "sha256-MPj6p69oheP7XsyvKgZIXp1vyRNT4X4yxSmdUDwFZ0A=",
      "url": "_framework/ko/Microsoft.CodeAnalysis.CSharp.resources.0sm6bhok3u.wasm"
    },
    {
      "hash": "sha256-uWFHPvAgn8I3ZZzG62SJxDqim5XJ1Nl00+hkjYQ7X2c=",
      "url": "_framework/ko/Microsoft.CodeAnalysis.resources.989426cy45.wasm"
    },
    {
      "hash": "sha256-X8wDf5s4DmP/2WpqRt9+JW+vFpIy/W1kZtCAUWk80Sw=",
      "url": "_framework/netstandard.1s320dqvb5.wasm"
    },
    {
      "hash": "sha256-sxwDwwrPt5JfmJ1O/dyIUtEGQ7TAatqnCZ3xpwX7Txk=",
      "url": "_framework/pl/Microsoft.CodeAnalysis.CSharp.resources.zorauptvam.wasm"
    },
    {
      "hash": "sha256-E9DhkvWStAmI/pIFbJuoZ7IymnFENRUtmJxMHJmxSx0=",
      "url": "_framework/pl/Microsoft.CodeAnalysis.resources.1bqfl6r9eh.wasm"
    },
    {
      "hash": "sha256-AwBtAuX3y8JuLD66WMgOkw3SsJ2gZmZ7tgQhjPSdgos=",
      "url": "_framework/pt-BR/Microsoft.CodeAnalysis.CSharp.resources.nnv74sjfz0.wasm"
    },
    {
      "hash": "sha256-p2wHOUhg+WLHoaTyB1+Q5wAA7f8EfKp6bH2AQPrY6jY=",
      "url": "_framework/pt-BR/Microsoft.CodeAnalysis.resources.1m4c920cpk.wasm"
    },
    {
      "hash": "sha256-gyvuLjq56xJ52UJ4PYF5kNrg/0o7U+fwNd7Y/ymQ6KA=",
      "url": "_framework/ru/Microsoft.CodeAnalysis.CSharp.resources.73tx2uqww1.wasm"
    },
    {
      "hash": "sha256-+7mZeRjGc2M6hJ1qiMRJ8OEm5UyZWf3qPw/Z0sZUQcc=",
      "url": "_framework/ru/Microsoft.CodeAnalysis.resources.jasfdca8tn.wasm"
    },
    {
      "hash": "sha256-OowbIL5ac+p0DilPW+iu1yXTSqqZcWbh7HEgwNXVn4o=",
      "url": "_framework/tr/Microsoft.CodeAnalysis.CSharp.resources.6pvz9eylvv.wasm"
    },
    {
      "hash": "sha256-gqd81F4jNypiqxlOrU8EwRHawcFDnr4kBcOs+jTsGpg=",
      "url": "_framework/tr/Microsoft.CodeAnalysis.resources.6n8brj49y6.wasm"
    },
    {
      "hash": "sha256-blb8qJxNtyTL5n3Q0mtUkbE56uV98Eo9aj8RQt5a6Jc=",
      "url": "_framework/zh-Hans/Microsoft.CodeAnalysis.CSharp.resources.ehmv21sa71.wasm"
    },
    {
      "hash": "sha256-ztaU1ohgQYAeC1Q3IltD5DYmkXv0Lgz9mQBsUssQ2a4=",
      "url": "_framework/zh-Hans/Microsoft.CodeAnalysis.resources.m2f69v8d2f.wasm"
    },
    {
      "hash": "sha256-IMqU+o7J2aQWaVQIPaCReB1GsG6WoH4fYK2Djri4ilA=",
      "url": "_framework/zh-Hant/Microsoft.CodeAnalysis.CSharp.resources.g0tdy5e2jj.wasm"
    },
    {
      "hash": "sha256-zFLRkAZCZbhRpwNfnTOr862AwXfo7UhDnhJH7ZfKB8w=",
      "url": "_framework/zh-Hant/Microsoft.CodeAnalysis.resources.oxl7kl6ueq.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
