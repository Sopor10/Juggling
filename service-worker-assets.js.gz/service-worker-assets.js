self.assetsManifest = {
  "version": "W1uJ9jLh",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-f028uc2y913T5CHs9m4/BRg8QiXMvF5j8UWuf++bHxI=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-iybf90y3kfW5bciTdjo7Kd4sQAffs/Ofr5q6N3ZEGmM=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-uaaWzzzDvusck4fl7NvTVyovIRj0jwWPBSinh7QoXyI=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-M9oCY0HEHaFPTMj7CLTxNBT7/8jUvcI3/3q27/kphek=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-AbUoh0WyJ6vVwP1Q6ca8WDzLK65RR3t5PQ5vD5wcSCU=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-VJHVdYDKwbz3M2/fsz33dbLmYsN6mqaOk13BJD6TYRc=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-lYiMLG73UrqjeD3Xr0zwkygnPDSAQXeAo1554Yjqjkc=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-+5xlKXTbNn3amd8ctMbF/O+QSkDtblcWi3as4tjyqC4=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-zXR4gEQow7grOiRYHwxRqmvmyWcFEIOoqPS6Bf6R/ls=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-/hsME0qpR/RIO3FWsiOtOXcoBfGZqlNkQ2bvmfdutoE=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-wsCFo85Tm++Hir55ycJcA850vMHr3ejT4YmaO32HaNc=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-fs2yqLp42sHAOey3Lex+cLbc6KGeJOynIB3HxZSUXR0=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-J8kJYxpBFMrMjHMBSdDlq1lYqyntxOrDZ8AW5FrxH8U=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-KKOTpPcyok2gwrLQNPe/HiIKgkCNxPPJVckvuNasQb0=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-qHtHCoERbW0+9gmM+3kn38gIOUs1idusCneg8KV+tJU=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-HXiIa+QpGuVO49oCyMw2rUWHH6CzufGWdwYNahx1qhU=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-mscmBJFsTrAe0H/SoknylPnukiQX2yfQ/zSnbR4B75k=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-xy//ZEyuuRCEAmG9E8A5Z2msJUF/ZMyZ2/+QekjM0j0=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-y6x9nQqkv3mW+Dvmm6Pvh+h0ixHfY0RLzrX6ZlktoG4=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-vc5Z5QAv3MvTQuJOrfBNegQxtr2kxqlHRRlR6L7iRH8=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-NrIE/sKBe0hlpKndnimZZSXSz7MR7szifPNm5hzjfFw=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-3Vn8Mjf4xHGoyuMl9RAiRp9l3WYxRkndR0u4A3k2UHE=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-VyhJgq8po3mud6FSP2a9ENksqEZN5jW2kGxLQC+F154=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-wNqrxSoWJioBUPqjZlTmLXixTNpDhSvFwwfgjBR+JAI=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-tRcVAq9DGc0nyvTuxUpiBTY8PaxnC6deHLSE8Ri1PMg=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-YoXTDttK//JX03GPHqAvSvxtUnSWW6tyKKSh1RzYp0E=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-B38BpIHJKsv4NfVCL4O5O/51XBIDUqdeL0Ui4k/A9e8=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-enRhK0aVsdphwSjuaFWUBGDUsWX4TflmAxzQbFaMdVg=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-HYNTnwNf3xj899KPdiKwmD1e5t3XRg9VaQgB1ZOvKeI=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-6LN5H5yixTF6AdyqzRJvlyXcbDqyxg1Nq1rAOo957g4=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GFU2mt0A9T8j9YMwMQqIUmdziKNDuPppDCn2o37LV2E=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-H2aC0DX2lYA1/ZrJcA6ZJ6Y7qmvkuwTfK+Ape9nbfhY=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-jl6yGniuOaLQTXd36jhE7+/dH86dwgPNpHgSvBiQxxM=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-8kZcrnldrkkLW30p/g/K9p+NC6jEXOKGglC2qZfmqDE=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.ulmmvjocnf.bundle.scp.css"
    },
    {
      "hash": "sha256-jvdEwbPP9ySWwm0cTSiOqdIfO15rtDmoxKmiqmFQR/A=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js"
    },
    {
      "hash": "sha256-y7L+XtwoUJtcUnvXGeRLVrLj2uLMTgPyNKJlEJnFbpc=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js.map"
    },
    {
      "hash": "sha256-pCIEjwDATOwa31+YvucoW1WTxT4YiQVDFhw94hu6wx8=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js"
    },
    {
      "hash": "sha256-MTgEQwaemErPPoFSvy9/AvhoR7QaOAVkSgXh+Gs5jmY=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js.map"
    },
    {
      "hash": "sha256-la7lyIF2RfLmzbgQq451BnkJEU/wykMPE6pCn8Po4pI=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js"
    },
    {
      "hash": "sha256-HQWKRYNJ6U0CQ6cjuHiZNYzn9EyBxinvWwT2zctFdWE=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js.map"
    },
    {
      "hash": "sha256-YQqC+x+db2pnQw/gibR4ai58y8WWbVsaiM7Dg/5ZjmQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-YEIKzZHjTFrB0PdPq+MUTCQVa9BXJOk4GoWEv21FNno=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-eM8DTi6b6DvS8NIedSLSGsOM4Y0OGeQUae6fmc0F5HQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.map"
    },
    {
      "hash": "sha256-tmxVjsHcxYihEtmXEJz2gJejcMpa2tNP2K5IAMBUwls=",
      "url": "_content/Z.Blazor.Diagrams/Z.Blazor.Diagrams.ezdqu7jd9f.bundle.scp.css"
    },
    {
      "hash": "sha256-s7EEPdhBW2P8sjiCOtar0D9cqNeKSPOwBxqj89twi14=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.css"
    },
    {
      "hash": "sha256-tjG7h09kCbOtLws3pLFB95nmOYxMZl7c8jbGPTarGBc=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.min.css"
    },
    {
      "hash": "sha256-DPGv+cCxzPgtITUub8yFS2/hFYsTZvuV+MX2hT1/C58=",
      "url": "_content/Z.Blazor.Diagrams/script.js"
    },
    {
      "hash": "sha256-LgAw9yB0DF0MNdupxctpNfEU7NoB56YJnh9QpuwRcI8=",
      "url": "_content/Z.Blazor.Diagrams/script.min.js"
    },
    {
      "hash": "sha256-EntOrNcHrVMAVfWpFhvF7p3Dlm2ljQBZcZQoK9/ENig=",
      "url": "_content/Z.Blazor.Diagrams/style.css"
    },
    {
      "hash": "sha256-UKzIp+VqUElrrWqYXITbK2mVVp6d5hx2LP+pnMfozLA=",
      "url": "_content/Z.Blazor.Diagrams/style.min.css"
    },
    {
      "hash": "sha256-qbG0STeTRSjScVJ9SBP9y6zl4YpUsBt317lGajCmB8Q=",
      "url": "_framework/AutomaticGraphLayout.Drawing.rfmvbsf468.wasm"
    },
    {
      "hash": "sha256-G5FHc2TipvCo7po6ZTAuX5MXPHgkB4E+CcQNvwSgIvo=",
      "url": "_framework/AutomaticGraphLayout.xhitsgdb3e.wasm"
    },
    {
      "hash": "sha256-W5jAEh1BJpID2KOjfMO9vOPVsdrYaro2ijjK6RlgFTc=",
      "url": "_framework/Blazor.Diagrams.Core.z625myqj9k.wasm"
    },
    {
      "hash": "sha256-zGXooQdLm05nUxu/a1HW0N8h1onvcACfrPx+R+fpsFI=",
      "url": "_framework/Blazor.Diagrams.ckfoh8zkyc.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-4Oeo8/KDTym/CblLRv6nEV9S1CDpm+rU4UjbGfjgDyM=",
      "url": "_framework/DotNetGraph.8ylozkoln5.wasm"
    },
    {
      "hash": "sha256-UUDdQpFUY9H2fvZxvGhWLfifbi0vztUkLr14L1HLE9U=",
      "url": "_framework/ExCSS.vo340561u5.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-EBslmZvfsvpTBdvOmv3rEOEg7Pc+HAABf7+3bJOokfc=",
      "url": "_framework/Fluxor.Blazor.Web.cl1oh36s39.wasm"
    },
    {
      "hash": "sha256-APyVBDq93FhhHXOm8kB0Guo/oYk+VcKmObk/+HK6CAI=",
      "url": "_framework/Fluxor.spaznd1495.wasm"
    },
    {
      "hash": "sha256-r5Z5TzGqrMIuWSJXK0jmGQJENOcmefKLR2x1NxLkqlk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.jnu2zj29eo.wasm"
    },
    {
      "hash": "sha256-Kfx5oKWxddB48RClvEDBhnfC99JSQcIyq8vA2LLuTC0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.t3qcxbaq97.wasm"
    },
    {
      "hash": "sha256-FY9DWKytQwG7sSg1w2/3uOuXw5RS1pR6W0KUiL8ENBU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.r40d3bw5wy.wasm"
    },
    {
      "hash": "sha256-tq/NgQaq87uOlr7+7m6GDqtRJcoQbmb4UlNF4KorKXk=",
      "url": "_framework/Microsoft.AspNetCore.Components.qgf06z1jy5.wasm"
    },
    {
      "hash": "sha256-BE38zi5I+UW+QcdQwETjhcxTjng5vIO0EzG2i2Y393c=",
      "url": "_framework/Microsoft.CSharp.0bbfgzh9ym.wasm"
    },
    {
      "hash": "sha256-yxPiW+l2bwpbqQMt+LqIVyoudbaoHWuYPnD4DDJUr88=",
      "url": "_framework/Microsoft.Extensions.Configuration.7p4o2tpul4.wasm"
    },
    {
      "hash": "sha256-Vaey6KNbQjvV5f4sgTb9Z7DpC7i8fKGaG8HGFaV0O8k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.79qfazjlcu.wasm"
    },
    {
      "hash": "sha256-e7KqvUYccR78CImWVq5kLp49gK7pPVNLuAnrrJ59tXE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.lo1485j0el.wasm"
    },
    {
      "hash": "sha256-e8G0JQI0dUUudPzWdfamVDGrSV+tqr50McBL0FMtaGo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ynt3oix6u.wasm"
    },
    {
      "hash": "sha256-kTAlZoNmRoWWSaioH4wef127PJDJMeb/4oEuNmvUuAI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.v0xh6qa0dn.wasm"
    },
    {
      "hash": "sha256-MFB5EtcD1XqYwTheZ3IWOsPfIWutpvK0MzF+GSwrl8I=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.sxddgq7smo.wasm"
    },
    {
      "hash": "sha256-Rw3p7P7cbetsRUa1O+Q7ltdFAmR7kf26guR3xO9aq3s=",
      "url": "_framework/Microsoft.Extensions.Logging.fugc9tzrx1.wasm"
    },
    {
      "hash": "sha256-XeR26x6ku+5dHZZCcX4Uiaanx8jfeXYNjeJFBU75vnw=",
      "url": "_framework/Microsoft.Extensions.Options.l2knz7uflb.wasm"
    },
    {
      "hash": "sha256-kvH0PWaEihTjfJSm4b+K3UHAQau8H9u9OsWrrZj/Chw=",
      "url": "_framework/Microsoft.Extensions.Primitives.mytv1lpnrg.wasm"
    },
    {
      "hash": "sha256-PNEDV+xipLuvR317S6a9u1afGzemESKRb3t3u2Wajts=",
      "url": "_framework/Microsoft.JSInterop.0hi1zeigqe.wasm"
    },
    {
      "hash": "sha256-sGms9Oai1ztzgfMsqBvmeKwa5ZyGWr/AEXr6thw0lso=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.8eb000j8w7.wasm"
    },
    {
      "hash": "sha256-i7oFvvqnjdFaKG3p9tV3yY9GCdDiuqiUNxeKKtxA7AQ=",
      "url": "_framework/Microsoft.Win32.Primitives.frj61gbyb2.wasm"
    },
    {
      "hash": "sha256-x5CLifPt6r+FGRA99XzWCNuEHo8g2B7zaDIEcPr1zwY=",
      "url": "_framework/Microsoft.Win32.SystemEvents.9wv7q2f5ei.wasm"
    },
    {
      "hash": "sha256-l2qEfPM/BjYyiblhUW+zUgDUT7vciCSwbC6Vj2Klbeo=",
      "url": "_framework/MoreLinq.zdi2h46g68.wasm"
    },
    {
      "hash": "sha256-L35LpopwBfUGUBjdl6stjznvbvyOpvsFMQgf0b6U8Fg=",
      "url": "_framework/Radzen.Blazor.n2dc57xsoc.wasm"
    },
    {
      "hash": "sha256-m4meHLMUAvq7lEIUgVUBUBgHP1IE10VQvr52rvjDXeo=",
      "url": "_framework/Shared.1t152ni38l.wasm"
    },
    {
      "hash": "sha256-XxJP/3wW4fXX3Uf3SiCHqjT/yhqLnFriW3M2+KTGLaI=",
      "url": "_framework/Siteswap.Details.dtw2zaz9w1.wasm"
    },
    {
      "hash": "sha256-uk4lTQLDlKeWSZJYtG7SpHTI9v+ikHMzaKpExhDoVvs=",
      "url": "_framework/Siteswaps.Components.e6e609euwi.wasm"
    },
    {
      "hash": "sha256-S+DrK4kkF2fJZDecjasHFYdv5rdFyVOKcE4eA8uNSks=",
      "url": "_framework/Siteswaps.Generator.1lgj5ok64o.wasm"
    },
    {
      "hash": "sha256-zbYwROO0k69U33Ne3ggQXbLsXK7hxznyA9gUhKqha6Q=",
      "url": "_framework/Siteswaps.Visualization.hrzni87rn3.wasm"
    },
    {
      "hash": "sha256-eV3F6NH5/nfLcQMQAloe6sGD4/VtH983nxzPYykRU30=",
      "url": "_framework/SkiaSharp.Views.Blazor.74nar1fiep.wasm"
    },
    {
      "hash": "sha256-uR6oKkgUwjDk1/tUffARfYBE2e0hbro7wn7QpNvF3lY=",
      "url": "_framework/SkiaSharp.j5guk4pyiy.wasm"
    },
    {
      "hash": "sha256-k46YDqsBQ84522ERaK6jUsIe7mlIJ4lIxsWnckhxyvw=",
      "url": "_framework/Svg.3wlfysmzyb.wasm"
    },
    {
      "hash": "sha256-mnGtUMBNvStqULzvqZhBxCYgBKXWHcsZGJ33qucDawQ=",
      "url": "_framework/SvgPathProperties.ebwgyay2jc.wasm"
    },
    {
      "hash": "sha256-C0Ri1oJawF3T8f59GXUb9HZxMxkaK+KSw4IFX0AJ7Ag=",
      "url": "_framework/System.Collections.Concurrent.1t2nq9zsxt.wasm"
    },
    {
      "hash": "sha256-rSvgp9NkPyWECmaIwR1j3dhwuNVBsnQ7UJPTcp4B//A=",
      "url": "_framework/System.Collections.Immutable.3k0afp4028.wasm"
    },
    {
      "hash": "sha256-19fY00dvwD818SBjFujR4hysxnAf9ecYedJ3HzfBNj8=",
      "url": "_framework/System.Collections.NonGeneric.3to9ex8mu3.wasm"
    },
    {
      "hash": "sha256-ijojrRqO92ydG+6BqqcpxO58xJShANYtmzik9jLak+M=",
      "url": "_framework/System.Collections.Specialized.i5jiwloevz.wasm"
    },
    {
      "hash": "sha256-ltNu4JROEz47vXE+vt0lrFNKB5KY6tKxPZljRRHDkoE=",
      "url": "_framework/System.Collections.qbvkgymroe.wasm"
    },
    {
      "hash": "sha256-Z9vjeOXJV5/r1AffYx7BaOGp0qSOhTPuLjszKhutIk0=",
      "url": "_framework/System.ComponentModel.Annotations.tviwxjp6jr.wasm"
    },
    {
      "hash": "sha256-s5rxcQ4OdDzS+tFWnkOWkgUFz0vaWpMQZOLrl7wUJbk=",
      "url": "_framework/System.ComponentModel.Primitives.pdmkb3uw6h.wasm"
    },
    {
      "hash": "sha256-wawAKJn3gttNiwBPR+/FV9qJ5lCJu1ZToybiaxf/F54=",
      "url": "_framework/System.ComponentModel.TypeConverter.1ouafhmxe9.wasm"
    },
    {
      "hash": "sha256-EhirUygKZLJOkB/C6o4wV0Kh43aSRURk8QCmhki4+LE=",
      "url": "_framework/System.ComponentModel.uta1zimhw7.wasm"
    },
    {
      "hash": "sha256-E5mWWpTXdoirPotSreJtcjcNS1BuPfreK8NDYxx1QX8=",
      "url": "_framework/System.Console.pxzglydazl.wasm"
    },
    {
      "hash": "sha256-tPcpGpdG/M1j5W1RL+cf7Gz5EE+MGXq9l4P4JUNS1Nk=",
      "url": "_framework/System.Core.k0eb8xf359.wasm"
    },
    {
      "hash": "sha256-mPXh53MMYsZTp+L7rAZoMo6EKUtuxL5dxuVfdNwpmMs=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.crwz9broo6.wasm"
    },
    {
      "hash": "sha256-s3AQ8o3VCHHvZY95Km8uOYrzg9Cb9kqR/If/CEYeV34=",
      "url": "_framework/System.Diagnostics.Process.plwpqp4ulv.wasm"
    },
    {
      "hash": "sha256-3dtw9zj4DR3fQLIs5Gvzblpd+IsYLJ5pIOvnJa7paq8=",
      "url": "_framework/System.Diagnostics.TraceSource.jwdnizwvh8.wasm"
    },
    {
      "hash": "sha256-zcqU4bLpKQ2pq4uHcy/xso1tunN7P/fStG6uOZdOlqY=",
      "url": "_framework/System.Drawing.30nntpi0qg.wasm"
    },
    {
      "hash": "sha256-2jXcLHpFOxw5ynaFNJ758A9FjyVbk2rYfk/vLn1cyu4=",
      "url": "_framework/System.Drawing.Common.i6rdziyf4m.wasm"
    },
    {
      "hash": "sha256-KbyOqdhMZ5bVkAW/0mnhoP82/ja9B8HfCtzVoq5fbCU=",
      "url": "_framework/System.Drawing.Primitives.z1pghgvqqi.wasm"
    },
    {
      "hash": "sha256-s3mF8hj6p5jfmOjrbrivLkjPT7oAJ4eX5EIb4XDEFXg=",
      "url": "_framework/System.IO.MemoryMappedFiles.d4v3i9bs68.wasm"
    },
    {
      "hash": "sha256-A/zbBw0DrouhwRThvr8F1IcKa5ApGW5BE01HoHB7igA=",
      "url": "_framework/System.IO.Pipelines.twix2pm6u4.wasm"
    },
    {
      "hash": "sha256-CH9HlSymBG/b7dH7jcPxKNmsHaT3OBrjgrUGQqTWkBo=",
      "url": "_framework/System.Linq.Async.k9im717kse.wasm"
    },
    {
      "hash": "sha256-HNMBMfyCfoBZZnrfTE52EKS1el1DYMq7hEGt1V4QkyI=",
      "url": "_framework/System.Linq.Dynamic.Core.c0pyo63s64.wasm"
    },
    {
      "hash": "sha256-Um1jDgNS9JOC9DPOqTTsK/LbiMKabMQ8+k4HVUKlWfg=",
      "url": "_framework/System.Linq.Expressions.u8vyc1lts4.wasm"
    },
    {
      "hash": "sha256-Tz4ykfsiPVa7zJMXkFeQX7b9Yzw+Bqa7AyM10hJzlH4=",
      "url": "_framework/System.Linq.Queryable.l7ml2j7mu8.wasm"
    },
    {
      "hash": "sha256-AtEc/Sp47HrAXD2MAa8VhPJ5O78eaDTwPXrThN1b3X4=",
      "url": "_framework/System.Linq.u0ijdwagha.wasm"
    },
    {
      "hash": "sha256-LcgZ1Jj/xldiD1yk5/6RZUUrj1yDmG+R1YbpUMEc0XU=",
      "url": "_framework/System.Memory.xzud22moi5.wasm"
    },
    {
      "hash": "sha256-132otII1jqQLeU5CtvS2kRHGVfPzX1bEYeW7as/Yph8=",
      "url": "_framework/System.Net.Http.3lqhxj7yqf.wasm"
    },
    {
      "hash": "sha256-Veph07He3TSSf+3cu5ruZk1lvh6cN+E2+LMd/PcVgG0=",
      "url": "_framework/System.Net.Primitives.bg60hpoftx.wasm"
    },
    {
      "hash": "sha256-yaXyvKtGITZwsrjbu9a3KgVkYIQsiatL2x37qBp5TiI=",
      "url": "_framework/System.Numerics.Vectors.9w0d002tug.wasm"
    },
    {
      "hash": "sha256-82gRnB6iFJK6/HJKYXm4mc/Cct9VInv7xyBDtfprcTM=",
      "url": "_framework/System.ObjectModel.tgfvbnhqn8.wasm"
    },
    {
      "hash": "sha256-1PxJ408HyYlajh8HiuGAH2cukty0pvEg9pp6bvI+68A=",
      "url": "_framework/System.Private.CoreLib.cmff4vm9bm.wasm"
    },
    {
      "hash": "sha256-n6kdHmCnBfadlXk1G/fMlbRXs/xacHUWilMfFtD3JhY=",
      "url": "_framework/System.Private.DataContractSerialization.hcyi4xrm7u.wasm"
    },
    {
      "hash": "sha256-gNcnvThS2Kh+TrFKOU7BSOdKoQKcejlWSBa98xyUbwU=",
      "url": "_framework/System.Private.Uri.431cjtgzgs.wasm"
    },
    {
      "hash": "sha256-yU74HYj198VSOrD572K+nDK0qkT1b3Gks0fg/WmrabM=",
      "url": "_framework/System.Private.Windows.Core.hyb1soemmm.wasm"
    },
    {
      "hash": "sha256-YrGfTbnSnKJOzVvYFJrxFtJyzI0PSrPCCPUlzXvCk+s=",
      "url": "_framework/System.Private.Xml.Linq.uhucsswg59.wasm"
    },
    {
      "hash": "sha256-oVkBYrO6wuioro/L/b661qWUgwc94KH8bkeqMBIQUDE=",
      "url": "_framework/System.Private.Xml.vou4utodzw.wasm"
    },
    {
      "hash": "sha256-HJXBs0D7qWG+SFlfo4uNJ8X6Ohr+AYPVFAZYwZlktO4=",
      "url": "_framework/System.Reflection.Emit.4waj5u5giw.wasm"
    },
    {
      "hash": "sha256-GSZ3erXu5eKPr3at6igPu4lQqivSXg/JoTD0lN5VVm4=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.fqn3fw5g67.wasm"
    },
    {
      "hash": "sha256-PGe0JO29sSXPAInwp58IS6MQBzV4H9QT6qxekERJSMw=",
      "url": "_framework/System.Reflection.Metadata.kkm6xkprz6.wasm"
    },
    {
      "hash": "sha256-5xC6Wp31dYBKSHnmvb7Jb37NP8Y9rELxQvkaPbCwFvw=",
      "url": "_framework/System.Reflection.Primitives.bjj4tmk12m.wasm"
    },
    {
      "hash": "sha256-MX8LpJpHEAecAarFdPQs7Jj0L9fNiKuIir1r5N+hA1Q=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.nyfk34cn6r.wasm"
    },
    {
      "hash": "sha256-VS3kWrvOVqTezDP4f7Mfd6o1ut9k1JQK0RGvs6zPOGw=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.z28v4l613d.wasm"
    },
    {
      "hash": "sha256-6PpqoyOreKqMNbAKtkTqJGhY9LJWR5Fk9Q8uKXIGR4w=",
      "url": "_framework/System.Runtime.InteropServices.cz2k5lu9jg.wasm"
    },
    {
      "hash": "sha256-RvC8mMYc0/Dm7Kti8gyt1L5Vjjelw3v3b0ZluOH3jIM=",
      "url": "_framework/System.Runtime.Serialization.Formatters.yqbxmwknqt.wasm"
    },
    {
      "hash": "sha256-0FQdRk+GQBMJezxsh5P5cGF14HkVhiNDVwK60yUoCcQ=",
      "url": "_framework/System.Runtime.Serialization.Primitives.oe4aggplqx.wasm"
    },
    {
      "hash": "sha256-n9iocY40wUO27eciOJlN/S+JO3Xa7DFtddMQrpRL8cA=",
      "url": "_framework/System.Runtime.h4wje4e3mh.wasm"
    },
    {
      "hash": "sha256-7avVR4IptfMcj6RRPitVFoUlkyfgWGAURXiyZseqDIA=",
      "url": "_framework/System.Text.Encoding.Extensions.dktlzgmib1.wasm"
    },
    {
      "hash": "sha256-2iawAcamkbvdFlRLtNLEoRnPv0gvF1i1QTceWH12XS0=",
      "url": "_framework/System.Text.Encodings.Web.y1u40ejdcx.wasm"
    },
    {
      "hash": "sha256-uzKB9+PZObeqAx8OBtAiJFksZe00nRuXMiE81zXcm04=",
      "url": "_framework/System.Text.Json.pfdptc996e.wasm"
    },
    {
      "hash": "sha256-AOQHZUwAZXvGh34RC7tzBJGgSqUoHzyWC94HlkogE/U=",
      "url": "_framework/System.Text.RegularExpressions.4versvu99o.wasm"
    },
    {
      "hash": "sha256-iGxH6rH+Jk4danMsDZwcL1u5ebjqjVMTwh+Q0xBLb9o=",
      "url": "_framework/System.Threading.0iwst7ysik.wasm"
    },
    {
      "hash": "sha256-b7dVBRJz8A0ORyMlDrQLjwEyYadd/7qUVSsw76IIenM=",
      "url": "_framework/System.Threading.Tasks.Parallel.jfw1la0ve6.wasm"
    },
    {
      "hash": "sha256-5sU2nxaf4oynNHHyxYqqanc2FtGROqak+u0sEHES6tg=",
      "url": "_framework/System.Threading.Thread.6xbblhpmc1.wasm"
    },
    {
      "hash": "sha256-iKcNI3HmtuGwXo1luA8GkOKXJ9picmxK35g2J45BizQ=",
      "url": "_framework/System.Web.HttpUtility.wyxyc7zd3o.wasm"
    },
    {
      "hash": "sha256-R9FktnaduRAvMaZfcRZAXAs4UUQFRWQ+IzNgO/1vj8I=",
      "url": "_framework/System.Xml.Linq.no17d80mwx.wasm"
    },
    {
      "hash": "sha256-CKy6qOqhxo68XdQXjrAFhYy3bVGrIfLDmcq26Boz74Y=",
      "url": "_framework/System.Xml.ReaderWriter.8ke9auy0bl.wasm"
    },
    {
      "hash": "sha256-Qk0OnBPIVf0WwbuMAZArUbwYYLUI9VrdKwlO0/QulkM=",
      "url": "_framework/System.Xml.XDocument.yg2v7uxmvf.wasm"
    },
    {
      "hash": "sha256-JTFuCK158shXIWK3NjdzwK5OZag1jcRJzsH8H5Gd6OA=",
      "url": "_framework/System.pndwwxah3a.wasm"
    },
    {
      "hash": "sha256-GqbYZLBITO3dqqsJ4DPwOeElXCpYNCbHhlrTpj+c2wY=",
      "url": "_framework/TextCopy.m05mv6487u.wasm"
    },
    {
      "hash": "sha256-ULsvyv7nl6doDq/7V6xScA4P8bEScbsCcPFBlPnaS7Y=",
      "url": "_framework/VisNetwork.Blazor.4fraq2v2tj.wasm"
    },
    {
      "hash": "sha256-ncHQZC4f8H3Zx5Gmsa1/kXT1DcHxOGbuFPXxtjaWeeo=",
      "url": "_framework/Webassembly.vlhhj60g45.wasm"
    },
    {
      "hash": "sha256-+hlz6Ghg0G1PDTJUV8Fn7N2u+zdTDwJFVWcZYS0QaWo=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-lIFBSyH5fOmCyz9NzfVceXU09qRLS0mn0JZG0tuYWBo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-yKD/LNfqN1x/19hoGsDTaL1XFo4+gDqCDrZgQgT+Hsg=",
      "url": "_framework/dotnet.native.84bu9534cz.wasm"
    },
    {
      "hash": "sha256-t+CRqPWTvodJ57O1qSXhCJPb+eBkfTaSL2bZWpuJ5rA=",
      "url": "_framework/dotnet.native.van7rtqhur.js"
    },
    {
      "hash": "sha256-gypqZnsxxUh4y4EJmawvOCaX4hoTaesVGwIgWXwZcNw=",
      "url": "_framework/dotnet.runtime.rubq0v1yiy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-ha3b7mHozufMTjagOexWCbPR4d/J84Oe/q8PMrD/F7Y=",
      "url": "_framework/netstandard.zuut9a8ipn.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
