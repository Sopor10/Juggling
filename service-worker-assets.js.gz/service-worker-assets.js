self.assetsManifest = {
  "version": "ba6qGpyL",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-UTsdNt4S8WyekD6NaMRXv0cUB1GhhGX+w1UuwMVxBeM=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-jiVNSdSlwgNj/X5JwguTaZqglGwc5DnUtiyLfsNE9OA=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-yatIo2ozy6Blq1xQG8vv6adktohT/Wzf/FR9Z0FBZ7c=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-vioHXy5W1V7GsWlxpp5EjANMoU6wvjCT5C6QhoiIFRE=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-oUqzDxYNe80U+p/qGo910JR5uFQIteOxLz1nRjlOAi0=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-OzryqgrBmCLXZeMdorJ2mKtCFPWnoi7NAeelJOBkopU=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-Ey4ZdNzgxXumHPyyz6jjW6zI1S5Ae/yMXoTw8IPfdMg=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-lYiMLG73UrqjeD3Xr0zwkygnPDSAQXeAo1554Yjqjkc=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-sf6h/7PKGZuF3KiwozC0n73/d6+hfOlzglPB+Bha6cM=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-U+P/96/oeAyr9FYH6r/1APAYzndW0R3WUDtNLkQZLe4=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-4aiWnQ2ZUz++crl2BKckZ7gbJcqZcPpshYXSd6kXhws=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-+PA/TMpN+uUgTwqwLmA/nfoyXy9AzOtxFRb9Ejy0j6k=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-bmPCi2udY3Yc0S9Z5qITmVKioW7GLNdNuybhwClmdOw=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-J8kJYxpBFMrMjHMBSdDlq1lYqyntxOrDZ8AW5FrxH8U=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-yV8qU9HynxxYKO57IHiPukwU5ZhyqjQhXECX/i+yvzM=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-EmB2FqmOEqvH4ZnO2uWxV2ywxgWlU5TA28P+u7eDjyg=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-xtC0fozyBMwpMqIr8frBj3cqKxurU6+0js9KT8FUYWM=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-mscmBJFsTrAe0H/SoknylPnukiQX2yfQ/zSnbR4B75k=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-lfvoIpxCrVpwJk0X4TH6FV2MW5tbnUH436i9C9sfzEI=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-y6x9nQqkv3mW+Dvmm6Pvh+h0ixHfY0RLzrX6ZlktoG4=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-BMvcGATV5HusruJSLx5N5CsoW3hfXAkOazuaDVng/p8=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-fzXK/2BQ8C/lABKJC6dsV+cXmFHprEg2ICoPIqt6r2E=",
      "url": "_content/Radzen.Blazor/css/math.css"
    },
    {
      "hash": "sha256-0XlxpaPpNLLR5zgdb9NpAF2kU+gHdwLJKNiryHVKuFs=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-HILeP2gHYKKY2hgZn3ofT3dPyJo+jOiVnr2B9QJNtGE=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-mHh6OGo9cpMZlZptx+gUmbVAY28oSpRtDR7lsb98WKk=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-Wy1uxKHv+7tqupikvCZkCh5NTWTBw3Za4bDEt6OcKyI=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-tRcVAq9DGc0nyvTuxUpiBTY8PaxnC6deHLSE8Ri1PMg=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-TswCyHWaVdwx7uC0O9uXb0pznbKDMOAKLLE4zr3+Azw=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-7tlQxYAxVxT5SZZ6wRc6Stc3gwD1qcKBOEdJwjn3r5U=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-bZp9fHCZtcbPKiiiHSzT70Edoq32krvBbipmuFAldPo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-HYNTnwNf3xj899KPdiKwmD1e5t3XRg9VaQgB1ZOvKeI=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-ExByOCIBi8jlV5ejgumLqiqRX8DyYBzp9ujstL3IDy8=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GFU2mt0A9T8j9YMwMQqIUmdziKNDuPppDCn2o37LV2E=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-XJSjZ7g0fZwzFkaDztnyeocqJUgpvxGSzTYvVE4q8KY=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-+eSpwuS0Mx0DVjyuFo3DoQXiI+Mp+4I1MtdWSbDcZK4=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-jvdEwbPP9ySWwm0cTSiOqdIfO15rtDmoxKmiqmFQR/A=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js"
    },
    {
      "hash": "sha256-y7L+XtwoUJtcUnvXGeRLVrLj2uLMTgPyNKJlEJnFbpc=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js.map"
    },
    {
      "hash": "sha256-pCIEjwDATOwa31+YvucoW1WTxT4YiQVDFhw94hu6wx8=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js"
    },
    {
      "hash": "sha256-MTgEQwaemErPPoFSvy9/AvhoR7QaOAVkSgXh+Gs5jmY=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js.map"
    },
    {
      "hash": "sha256-la7lyIF2RfLmzbgQq451BnkJEU/wykMPE6pCn8Po4pI=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js"
    },
    {
      "hash": "sha256-HQWKRYNJ6U0CQ6cjuHiZNYzn9EyBxinvWwT2zctFdWE=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js.map"
    },
    {
      "hash": "sha256-YQqC+x+db2pnQw/gibR4ai58y8WWbVsaiM7Dg/5ZjmQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-YEIKzZHjTFrB0PdPq+MUTCQVa9BXJOk4GoWEv21FNno=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-eM8DTi6b6DvS8NIedSLSGsOM4Y0OGeQUae6fmc0F5HQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.map"
    },
    {
      "hash": "sha256-tmxVjsHcxYihEtmXEJz2gJejcMpa2tNP2K5IAMBUwls=",
      "url": "_content/Z.Blazor.Diagrams/Z.Blazor.Diagrams.ezdqu7jd9f.bundle.scp.css"
    },
    {
      "hash": "sha256-s7EEPdhBW2P8sjiCOtar0D9cqNeKSPOwBxqj89twi14=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.css"
    },
    {
      "hash": "sha256-tjG7h09kCbOtLws3pLFB95nmOYxMZl7c8jbGPTarGBc=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.min.css"
    },
    {
      "hash": "sha256-DPGv+cCxzPgtITUub8yFS2/hFYsTZvuV+MX2hT1/C58=",
      "url": "_content/Z.Blazor.Diagrams/script.js"
    },
    {
      "hash": "sha256-LgAw9yB0DF0MNdupxctpNfEU7NoB56YJnh9QpuwRcI8=",
      "url": "_content/Z.Blazor.Diagrams/script.min.js"
    },
    {
      "hash": "sha256-EntOrNcHrVMAVfWpFhvF7p3Dlm2ljQBZcZQoK9/ENig=",
      "url": "_content/Z.Blazor.Diagrams/style.css"
    },
    {
      "hash": "sha256-UKzIp+VqUElrrWqYXITbK2mVVp6d5hx2LP+pnMfozLA=",
      "url": "_content/Z.Blazor.Diagrams/style.min.css"
    },
    {
      "hash": "sha256-qbG0STeTRSjScVJ9SBP9y6zl4YpUsBt317lGajCmB8Q=",
      "url": "_framework/AutomaticGraphLayout.Drawing.rfmvbsf468.wasm"
    },
    {
      "hash": "sha256-G5FHc2TipvCo7po6ZTAuX5MXPHgkB4E+CcQNvwSgIvo=",
      "url": "_framework/AutomaticGraphLayout.xhitsgdb3e.wasm"
    },
    {
      "hash": "sha256-W5jAEh1BJpID2KOjfMO9vOPVsdrYaro2ijjK6RlgFTc=",
      "url": "_framework/Blazor.Diagrams.Core.z625myqj9k.wasm"
    },
    {
      "hash": "sha256-zGXooQdLm05nUxu/a1HW0N8h1onvcACfrPx+R+fpsFI=",
      "url": "_framework/Blazor.Diagrams.ckfoh8zkyc.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-fMK+NZ4d4f3Cu2k2Jb6c6p3x8UkoVOuL4PUI3X76ZKo=",
      "url": "_framework/DotNetGraph.cy7hbw1uck.wasm"
    },
    {
      "hash": "sha256-UUDdQpFUY9H2fvZxvGhWLfifbi0vztUkLr14L1HLE9U=",
      "url": "_framework/ExCSS.vo340561u5.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-EBslmZvfsvpTBdvOmv3rEOEg7Pc+HAABf7+3bJOokfc=",
      "url": "_framework/Fluxor.Blazor.Web.cl1oh36s39.wasm"
    },
    {
      "hash": "sha256-APyVBDq93FhhHXOm8kB0Guo/oYk+VcKmObk/+HK6CAI=",
      "url": "_framework/Fluxor.spaznd1495.wasm"
    },
    {
      "hash": "sha256-c1e9Fx8R3oc4G9UHPzY1t7nT9QZmH3Estrxj7VltxYw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bqwrtn8smk.wasm"
    },
    {
      "hash": "sha256-ASzXo+oMkkaK6eAWdFnIRbugRtJYZOiqfjpelm9J5f0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.j7zn6fyd15.wasm"
    },
    {
      "hash": "sha256-d0s0wnF7oRkO/OrU802Rr5TK7JUcrQZzAepPEnUVg14=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.3h5bvvwcnl.wasm"
    },
    {
      "hash": "sha256-3XfEDOSempIK+JyjmY3u1NSxJL9X/hC3NCFp209NGqI=",
      "url": "_framework/Microsoft.AspNetCore.Components.tgg2svg5z8.wasm"
    },
    {
      "hash": "sha256-tMvj2vSWOmZLgfgkPG3X998A3VVgv2tmRB97u6veAho=",
      "url": "_framework/Microsoft.CSharp.kga7jac2c0.wasm"
    },
    {
      "hash": "sha256-Bjx1+qelDpa0ZwgfuNzBPRFUId1YrUV4ewnF9w/Uthg=",
      "url": "_framework/Microsoft.Extensions.Configuration.2myvfdg1e7.wasm"
    },
    {
      "hash": "sha256-73vrNN0AOVVoO5v9WUY/eY7XR3c3SY/BIDRFLM4a0Q4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.rphttcps45.wasm"
    },
    {
      "hash": "sha256-iY6mGzFqdkViRAURvuiU6xZ4IlIqAwMLJpL0OkLWeVw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.xi2jfvrc17.wasm"
    },
    {
      "hash": "sha256-Sc7Z5jPLun7BN1LZf1XCKmNyFyw8eCnIkzXQdCRtSqI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7gn4i8bn3w.wasm"
    },
    {
      "hash": "sha256-IR1UnlulhXLKbAr2lt8ES9hfZk1gHlB/WtAfbCNHggc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.33zp9ful8z.wasm"
    },
    {
      "hash": "sha256-VG+rDQivc1WjdKZ9RxmuGdYpva5X/cLKIfhna2K4cyo=",
      "url": "_framework/Microsoft.Extensions.Logging.0njds877v3.wasm"
    },
    {
      "hash": "sha256-IbpO9YGJVZUeY3/8hhT0+8y7LV4RML9tvXHFhTTv3jk=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.1w6tq2htlu.wasm"
    },
    {
      "hash": "sha256-7FKOPCgSjEjGBjWYraAHz3K5lmaedflVACYppDXnLIg=",
      "url": "_framework/Microsoft.Extensions.Options.0le93mknvs.wasm"
    },
    {
      "hash": "sha256-xemQ38+33bD3ZoI8JWPXYhdkE6GWU48Joume84DHElk=",
      "url": "_framework/Microsoft.Extensions.Primitives.fb26p7p8dq.wasm"
    },
    {
      "hash": "sha256-GaWH3/h+jMiywp+g7vt6i3wRVl+RkH+TV4HWg12yYXM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.j5m7jjhb9v.wasm"
    },
    {
      "hash": "sha256-Yvj/xHVikAWJL+g5+luS9ZjXVJZXA67r2ab2uBD5TBE=",
      "url": "_framework/Microsoft.JSInterop.qlhefq26pp.wasm"
    },
    {
      "hash": "sha256-1TQykZCCq5pPA6QxHP9aOgBQyBBNHSUvnjaB1YhF7mU=",
      "url": "_framework/Microsoft.Win32.Primitives.pvmsuhdlt3.wasm"
    },
    {
      "hash": "sha256-vDbyxiNfsGvyrSM8BpHhiKXbCD+Ax89eLk7FFQRACNk=",
      "url": "_framework/Microsoft.Win32.SystemEvents.k896h5jh82.wasm"
    },
    {
      "hash": "sha256-l2qEfPM/BjYyiblhUW+zUgDUT7vciCSwbC6Vj2Klbeo=",
      "url": "_framework/MoreLinq.zdi2h46g68.wasm"
    },
    {
      "hash": "sha256-eiNSRA71VRxAK9pBjsycT5staA6hI9GKscVKmoJ4IR8=",
      "url": "_framework/Radzen.Blazor.qk1ad8v7ae.wasm"
    },
    {
      "hash": "sha256-uIcQGJIrpVcIPiod7zuPZF3AMr3Omv4tnOOEhDOhdEo=",
      "url": "_framework/Shared.szze6d4u6h.wasm"
    },
    {
      "hash": "sha256-G0e/SvuXpU/uzmRdj3R5Z17EcXXnfS8cEHEUHtsFLNo=",
      "url": "_framework/Siteswap.Details.t2ktegiyfa.wasm"
    },
    {
      "hash": "sha256-GPKQ508pkyN8XNYwBxKrN66JyLOIhb8mBmgzy6qU6EQ=",
      "url": "_framework/Siteswaps.Components.kt7ackhl6g.wasm"
    },
    {
      "hash": "sha256-ihUAhwkN3e5zIvSRls8SxuwGsgxCK3nSqM74McBaN+Y=",
      "url": "_framework/Siteswaps.Generator.efarc7ejtg.wasm"
    },
    {
      "hash": "sha256-X+9F4cwGvN1+FZ8gK6wfZ/0rbMs0Msf4LDvwG3rS7C0=",
      "url": "_framework/Siteswaps.Visualization.z31btms0z5.wasm"
    },
    {
      "hash": "sha256-DKKfshozscJuj8Bu3AMR1WMZ4zuzcZPVAEG84+uWxqI=",
      "url": "_framework/SkiaSharp.4utg70glsy.wasm"
    },
    {
      "hash": "sha256-+5lFYk11wwtJKUvTMwXiuQWKVngS/3Y0LQV5hARgV2Q=",
      "url": "_framework/SkiaSharp.Views.Blazor.rwyxjek1ea.wasm"
    },
    {
      "hash": "sha256-k46YDqsBQ84522ERaK6jUsIe7mlIJ4lIxsWnckhxyvw=",
      "url": "_framework/Svg.3wlfysmzyb.wasm"
    },
    {
      "hash": "sha256-mnGtUMBNvStqULzvqZhBxCYgBKXWHcsZGJ33qucDawQ=",
      "url": "_framework/SvgPathProperties.ebwgyay2jc.wasm"
    },
    {
      "hash": "sha256-oEOgavNPVsXLjfgrjcfzM8rX3tGKdDizAVYisUT7XOE=",
      "url": "_framework/System.Collections.Concurrent.8ypk0j9l8f.wasm"
    },
    {
      "hash": "sha256-hEGGoo/9iI4rNSWMNAc6EJ2o/mMgrE3KD3go6Y4c94M=",
      "url": "_framework/System.Collections.Immutable.gp7uforx0x.wasm"
    },
    {
      "hash": "sha256-UEytWcAaj9xQ93mi9i9CDUblyIl85A5aXXTzO6AfzIA=",
      "url": "_framework/System.Collections.NonGeneric.wgfo8owan2.wasm"
    },
    {
      "hash": "sha256-a8GKsUTtOLeyKPctY6IIRbwWG9EQKLumIAadIHpjxqk=",
      "url": "_framework/System.Collections.Specialized.hxi3cwr8ic.wasm"
    },
    {
      "hash": "sha256-MgEIy5abOscyr5vK6VSBHHw12G9O3wrJm+lG2NRXAFM=",
      "url": "_framework/System.Collections.ycand00txz.wasm"
    },
    {
      "hash": "sha256-NiTQJ8jVOpVPJOWyDePcw49plhrlzVb7ysGOBKgSAn4=",
      "url": "_framework/System.ComponentModel.Annotations.yhjei2r20w.wasm"
    },
    {
      "hash": "sha256-vVqKjQVCH1bRGzKZZx7MZuixkdVGqkr1xehvd78u1Xk=",
      "url": "_framework/System.ComponentModel.Primitives.3s5oaaw31z.wasm"
    },
    {
      "hash": "sha256-Z5kOLp+f+LTYYv1WYUmXM2oMRq7Tl9w2tZ9aCJgbl6o=",
      "url": "_framework/System.ComponentModel.TypeConverter.p0waq71jnw.wasm"
    },
    {
      "hash": "sha256-muZHx1UJtOxrv3wfKa5/Yho89NSTAd8N5ImsNL6DfzE=",
      "url": "_framework/System.ComponentModel.e7tzgu6jwr.wasm"
    },
    {
      "hash": "sha256-VSLkT2ufP+rwNQK1sFUHaO2bIOHa8BmND8npOOYrtuk=",
      "url": "_framework/System.Console.nh7f6lds9j.wasm"
    },
    {
      "hash": "sha256-s+okOvdAvvC3Ing88q/V0dYlCxramHaMt7/rwpWYBO4=",
      "url": "_framework/System.Core.1fzc3977wq.wasm"
    },
    {
      "hash": "sha256-+veuX8DWoEb0kYxNq0haS8KcLMGlABRM7u0HEWbduyM=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.2p4h6car0p.wasm"
    },
    {
      "hash": "sha256-jaJgs/+/FP4A6EBnsCrTdmBfs1XTfu8tPdEaWMYfMnw=",
      "url": "_framework/System.Diagnostics.Process.tc4ike3sik.wasm"
    },
    {
      "hash": "sha256-WdFoILnv5w8/bp/hZuShFudXw33NxFEBEuz+dd87MDc=",
      "url": "_framework/System.Diagnostics.TraceSource.xi71pvih81.wasm"
    },
    {
      "hash": "sha256-jjH3iYBveDnDBZXs2jk36ZFPHb8DCSNfT9bJoAzff/8=",
      "url": "_framework/System.Drawing.Common.6bmqjur404.wasm"
    },
    {
      "hash": "sha256-eWDE0b11SbEiYNZHHdTLFTOT+QAGXrRi5iU8/5C++VY=",
      "url": "_framework/System.Drawing.Primitives.9odpfsbxgb.wasm"
    },
    {
      "hash": "sha256-BQVqh10/miWXV7ylhdX3h4ZFbA4z4gInC/Q797FWiVA=",
      "url": "_framework/System.Drawing.ndt5n06kpt.wasm"
    },
    {
      "hash": "sha256-RZEb1BybSwgJfIiIJuJo+4pn3fTDzThR4QSOpdVUwMU=",
      "url": "_framework/System.IO.MemoryMappedFiles.5wg31ec3vz.wasm"
    },
    {
      "hash": "sha256-LHmn3NZ0cYl/sD4s/EA26iSAYqDCycxgYdwt6suIKLM=",
      "url": "_framework/System.IO.Pipelines.wfn2m8uvna.wasm"
    },
    {
      "hash": "sha256-EfdBKDbvGV9+uu8gn66X/62vVvJdcmaSt9PTUIs5t5s=",
      "url": "_framework/System.Linq.5rwhjdneqe.wasm"
    },
    {
      "hash": "sha256-ZBX4y7qqNxAG2D1pxGD0kUN3ABBDQEQP0PY+XFZ7Y1Q=",
      "url": "_framework/System.Linq.Async.ovfc2irvky.wasm"
    },
    {
      "hash": "sha256-gXm1JEiDjoAy1MfcNYShf53JjvO0hQfz2GkRaJyHtdI=",
      "url": "_framework/System.Linq.Dynamic.Core.l3chai15f5.wasm"
    },
    {
      "hash": "sha256-D7F+dfeF2GXJbcQaoAV7vCMVD1F0rIKDtF4trXW3B/8=",
      "url": "_framework/System.Linq.Expressions.l72feuha67.wasm"
    },
    {
      "hash": "sha256-KqRbAGuMwIjxSBGLAWO/qgAuXl5TYiwl7hyLr0r9htY=",
      "url": "_framework/System.Linq.Queryable.a3ueo5c7pn.wasm"
    },
    {
      "hash": "sha256-GM/jqtS/d6GVtOoWdoTcGgzTbnMv/BB1xnx3NRG2+64=",
      "url": "_framework/System.Memory.wi8z7taaee.wasm"
    },
    {
      "hash": "sha256-x3ug73yqTdD1l43ayRoTG8pT9HhHbc9YhdDp+JhKetQ=",
      "url": "_framework/System.Net.Http.d7jotsewex.wasm"
    },
    {
      "hash": "sha256-UWz8Xc3aMOOTtjyxXS9iphkcGf6l5buhiMUj+mgIxRU=",
      "url": "_framework/System.Net.Primitives.neyihtxzev.wasm"
    },
    {
      "hash": "sha256-F/r8zRJU9Gpri3BS29isTEINVjCD7Ej52tn1/Wk1q/4=",
      "url": "_framework/System.Numerics.Vectors.brcqrrb52m.wasm"
    },
    {
      "hash": "sha256-neuncGOHsxSy7r4Xm4yJcLyQtFgXhishJAph4A1ETdU=",
      "url": "_framework/System.ObjectModel.f13sqjh6ie.wasm"
    },
    {
      "hash": "sha256-f40Q6Myi7fMsWvbziD7V/+5MtrG3whSoq2QOC8HzN6E=",
      "url": "_framework/System.Private.CoreLib.blcbpgwmam.wasm"
    },
    {
      "hash": "sha256-U3D6I6zlxxyJQczTdDyZN5IvIS2FZTH2+nWcJZGGDI4=",
      "url": "_framework/System.Private.DataContractSerialization.1jg8qs8v55.wasm"
    },
    {
      "hash": "sha256-W54FWBxXRR2scQj7h+AOZKQRgllyhgPitbUbRvm0kCo=",
      "url": "_framework/System.Private.Uri.x9onrr0thu.wasm"
    },
    {
      "hash": "sha256-rUhnYTOivF4HdVp4dhCb50u+zb49NO2SUKjeGSTWtlc=",
      "url": "_framework/System.Private.Windows.Core.hjjrl2ruqu.wasm"
    },
    {
      "hash": "sha256-bHPJ0LYx/TkJAhLbk8KH9KHumkRRuaVaKPUQzOsPdwQ=",
      "url": "_framework/System.Private.Xml.0nzssd2vxd.wasm"
    },
    {
      "hash": "sha256-BgE81DkB4/lYA3MLcuOdc020lRE/hkok2KZBJ1G8rKs=",
      "url": "_framework/System.Private.Xml.Linq.yhcvgcbx47.wasm"
    },
    {
      "hash": "sha256-/BL6DJT9xsoxQa5HHjm0Jm7dX05JjNbD8tezIktYs5U=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.k22udwc9ij.wasm"
    },
    {
      "hash": "sha256-p0J8eeNY6bfN1FlzCdY5nuYNGoyJGmNbPlHTjB8BZgU=",
      "url": "_framework/System.Reflection.Emit.lpgff7l6s8.wasm"
    },
    {
      "hash": "sha256-vyIHC11RpXmnT238GkSNdQYLyDSPHmkH912eGxnaiaw=",
      "url": "_framework/System.Reflection.Metadata.pymobialw7.wasm"
    },
    {
      "hash": "sha256-n0dXDCI2fXe2MIzaTJ2Z6/I/3rm38ohYN8/AEy7LUsM=",
      "url": "_framework/System.Reflection.Primitives.dhny9hcbnv.wasm"
    },
    {
      "hash": "sha256-1EMyCrKcIhvKMjfCZXMCgLynM73ilKW0CSeNjCznHMM=",
      "url": "_framework/System.Runtime.42uk7wchw8.wasm"
    },
    {
      "hash": "sha256-0qyu49VBEk45erFNwqnlJWZUmeN+jiQHbqBteewabq0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ed72n14juv.wasm"
    },
    {
      "hash": "sha256-sdFerliPqES0uadSvdtKYJL9o+nBhZmg6J8HpXSM9e4=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.zj885fhugg.wasm"
    },
    {
      "hash": "sha256-qRcWLll6z3Tz3cu3LR0E5pda1iyAu6hKQYyNY5hgYxI=",
      "url": "_framework/System.Runtime.InteropServices.z9zvovv9fw.wasm"
    },
    {
      "hash": "sha256-8TmPrgRDi/v2Xm5Qj2a/0AvHOUQsHRCudyKpQfSRts8=",
      "url": "_framework/System.Runtime.Serialization.Formatters.b9gveppwtb.wasm"
    },
    {
      "hash": "sha256-sqtMLQF8yQWskCY01JRJ0ckG7IgFRrlsvVj2sqpa+BA=",
      "url": "_framework/System.Runtime.Serialization.Primitives.ivahra61go.wasm"
    },
    {
      "hash": "sha256-29ICMQTcYh/qV89j5a9SEw3bP+DCFaAmJKwJysoVhJ0=",
      "url": "_framework/System.Text.Encoding.Extensions.h5m8b8c5wz.wasm"
    },
    {
      "hash": "sha256-ZfPmnXVJGL8ZDS+33YeQd2cQoeTLEjBUUg4sXYYxZoc=",
      "url": "_framework/System.Text.Encodings.Web.lwhf3uxf1y.wasm"
    },
    {
      "hash": "sha256-E2LX6T6xQ5Iw2ttih5cWw8nOgwIX3ln9Xp4Dc0zW/3w=",
      "url": "_framework/System.Text.Json.fl1oobe15d.wasm"
    },
    {
      "hash": "sha256-jsrkPukHtrlcblBlBhAJSRBKT5oMsjG8PraK+JIx6mE=",
      "url": "_framework/System.Text.RegularExpressions.yrq0vdbj3y.wasm"
    },
    {
      "hash": "sha256-ixYGmwX8jEYvMrKBT1LhIXw2BWyXr3SL084OzNi2mII=",
      "url": "_framework/System.Threading.Tasks.Parallel.nti97yi0nr.wasm"
    },
    {
      "hash": "sha256-s4grTgK2nbeHLmsD1JVNVE4wBYrDVe5plLdDgTc3eYw=",
      "url": "_framework/System.Threading.Thread.d4fv9gftec.wasm"
    },
    {
      "hash": "sha256-62a4tXqj1IGNWRC68y4vfVt/NQoWO/qPoxBlkR4U/1A=",
      "url": "_framework/System.Threading.hltdqa0of1.wasm"
    },
    {
      "hash": "sha256-htiDZmKv+bPmp/KF3dfV/ETSqFnswqnJwLQGmmxYcbQ=",
      "url": "_framework/System.Web.HttpUtility.26mdmweht2.wasm"
    },
    {
      "hash": "sha256-wwxsYRpXsPfLkFVXXX9uditc29XXKjAFv10/9OYAhf8=",
      "url": "_framework/System.Xml.Linq.hvxjxkvtb2.wasm"
    },
    {
      "hash": "sha256-ehuoKlK8qbB9pAHWRIVrF4/6hUcOUKxr9WkEF+3YRrE=",
      "url": "_framework/System.Xml.ReaderWriter.ym094jo6eh.wasm"
    },
    {
      "hash": "sha256-sO73DYFvR29/pZIOyUP0RjvTz46ZXie/Q39sKG6NiAk=",
      "url": "_framework/System.Xml.XDocument.w83pehuuzm.wasm"
    },
    {
      "hash": "sha256-/Imz/Enqa2AZc4T3k/CqtsM6674KRN9OUtvK4Nokhew=",
      "url": "_framework/System.wznexm8bk2.wasm"
    },
    {
      "hash": "sha256-GqbYZLBITO3dqqsJ4DPwOeElXCpYNCbHhlrTpj+c2wY=",
      "url": "_framework/TextCopy.m05mv6487u.wasm"
    },
    {
      "hash": "sha256-ULsvyv7nl6doDq/7V6xScA4P8bEScbsCcPFBlPnaS7Y=",
      "url": "_framework/VisNetwork.Blazor.4fraq2v2tj.wasm"
    },
    {
      "hash": "sha256-PyXkKS90akRgxP7cTqKKtPPx/BK6OB74chHi5b28FPY=",
      "url": "_framework/Webassembly.jvh3o8zlbs.wasm"
    },
    {
      "hash": "sha256-XbtFRwkrcOnGJM9gCCoTj7j0Pc5wmL7N7yTqiTeknfM=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-3MHpnImjcdbndre7BEBFmcZQ61mhKqldc9b5Bpp44Xo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-BVCVpvdWNkdE1HT8uV5hvHwLJ8GwahyU9HO6Eity24k=",
      "url": "_framework/dotnet.native.54b3pb7zlz.js"
    },
    {
      "hash": "sha256-1855Rqg+DLs3fZ1iWFiqzzXgbxApO3aDgrCGBPz1/Z8=",
      "url": "_framework/dotnet.native.vibi01iohv.wasm"
    },
    {
      "hash": "sha256-x+PnWU47EIr/zL3xxqIUMDJi/dy5904TVGunDqCvjIY=",
      "url": "_framework/dotnet.runtime.593bvuk5yc.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-KbrjdnkdTrEx09X4+K+8WQkQmN9DaRxZWMTFF2Cs+Ng=",
      "url": "_framework/netstandard.x281b07usi.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
