self.assetsManifest = {
  "version": "e0KPLRUW",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-Zj7sF25g49ZYgpgxmvvLs4xs7wWCla5f2cWoqW+r6/4=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-kYE8x9Fxto4kAa5rZOX7UoWbO/ezKh+gt2g0jSZWNtI=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-9t6EXWYnl/QKcjuT8/+OKfHA1pouuLwhKIYsHnsB1tA=",
      "url": "_content/Radzen.Blazor/css/components/_qrcode.scss"
    },
    {
      "hash": "sha256-YVOvEQpafIYbQ1C1wHpTmvQmix/J7IIM/s6bR15xzeY=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-gkui+AFMoSJ/CZpSzxAiT7olmWjNpYUjIBWOJI6wuMc=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-twSJ5g1IeBzpsxmHR3FNu7ItID6H3XbU1HZ/qJSWRFg=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-9ZPFj82lGG387S9bKduzkwVEZO4fdwo027aodi4LNVo=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-YmGG8kk6j+Dwd+oz9V/6BjCSaUsYklsZsy/ikfZnS68=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-vty/la3MXjb8+NihPQEMF9ijro+NPHFHsJOXoK4Mh28=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-4tmVJXuCBk2/QRsIy7dLf1bN3X2OolRLRGYmKeVi0zk=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-teD7Xp9KoEEbG4QaoWzAqntOrbHPWNULM3dsFVROfkE=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-F6ZGl/o1vaNUJUGMCDbYnYCswD583tEqbu+LSy+/0ho=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-4ZMduw+tDam6nGA8fEuuPFi23JFfcM2y2EDh3/5rKAw=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-VId/LOwa/fiUtA67BmPAvXp5phlsSyykd0Lw/Fc2DAM=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-h2e1Huh88KqwXtlPMXfdyz7KuPmGwRQ4mlMmmDB0ttM=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-fzXK/2BQ8C/lABKJC6dsV+cXmFHprEg2ICoPIqt6r2E=",
      "url": "_content/Radzen.Blazor/css/math.css"
    },
    {
      "hash": "sha256-wJ3Lb9vVJtckdL66r8uyArmsd8F8WDFB2tVJR17TJ/M=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-FC48ZdritMsdzEs4DD6VfaM2i2mQenOOvjOe4CKSJCU=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-tkEpeRJs4pAczrvwgj5NEuwRXunsC9lJYbx/prqb+IM=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-BR7Qlv0MDGLSKU4dbtBeCRDWQRHGoA4xs+85cVsXI2k=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-3zReFg9ZAhiu8VOEA3fk2vRjYcKthwM+mh8/Xs8S/tw=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-ioPJnBiXjLVLzXAmSiBh6j7e9/Z+OtdZ4+++6sqTfmY=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-6/nVMSZPj5TQ58+geQrVD21/1z5mCK1ktWtneQZzvaY=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-U9HViKHLkZ5sWC6DzhKOGlAyxEQWJKRSkwzvTPi63/A=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-f0uhXaNzSHCguW7IErTRjeiGQXPWEWl5p/eehMZkDdc=",
      "url": "_framework/Fluxor.9yjucuf12h.wasm"
    },
    {
      "hash": "sha256-DBC32gXCmb31ELcLWyN0VaYPespDZiNUhIL276D1X7Q=",
      "url": "_framework/Fluxor.Blazor.Web.4opwue5a6j.wasm"
    },
    {
      "hash": "sha256-88QJwfCtHfQjnIqJaqRECyUJalQRgwCRcQhfx+mACg0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ft1jd63w6t.wasm"
    },
    {
      "hash": "sha256-0yti3McUZj978/qCEe5PTDnIr4DTNx7MG1/0Nk3wIFw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.b67ivu4pff.wasm"
    },
    {
      "hash": "sha256-MI1kI/vs6lelL/gUXOGa1Vl1i1MBtV7zyVpShRwZrug=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.cp0xpq59bq.wasm"
    },
    {
      "hash": "sha256-E0Tr3KsgP/bjWNkbIup8CjVHuPSeOdVM+14AzfzzgME=",
      "url": "_framework/Microsoft.AspNetCore.Components.pxby7pa5x4.wasm"
    },
    {
      "hash": "sha256-zcRmCP79Iz3Jmmcnk8RxSvHdHZlCPfHjVDHwFFgMzJA=",
      "url": "_framework/Microsoft.CSharp.r6g1jk74uf.wasm"
    },
    {
      "hash": "sha256-EScOvyLYbGHyXzhFvrjRm2JZrZ6rIDhmUXRvPgDTopY=",
      "url": "_framework/Microsoft.Extensions.Configuration.33kpvunugc.wasm"
    },
    {
      "hash": "sha256-if+LK/X2QiubYZTpryZvRrMyTu2U2TFOuAkbwh3zGOA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.vydvg25cgq.wasm"
    },
    {
      "hash": "sha256-I9RchUtUIR389BC9FoYb+kicxmt1RhJha7WRlbfEbBQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dsinhvif0g.wasm"
    },
    {
      "hash": "sha256-o3DZ22g4zto3RmLtosapeKSFHJzL3VXoNJfcMmtGWGk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3snpc8ocur.wasm"
    },
    {
      "hash": "sha256-uPx70Q2NEO5Ibk5NE8O0dZAiPQ5WVdE6bU6cLkX2PEk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.cjspkbsdty.wasm"
    },
    {
      "hash": "sha256-Hu2MjLPZLBKV+cEj1/HeT9wXN2iKtKFeDehUgyhZTmc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.qqmv2j63mh.wasm"
    },
    {
      "hash": "sha256-2o41anbTbxpSDCdgiXgltHqZusjWuT1+M9amuIjDsAM=",
      "url": "_framework/Microsoft.Extensions.Logging.efb40z18hz.wasm"
    },
    {
      "hash": "sha256-XGj03JJMkTcDPtq85Ydyo4AsNodf02qW5HyESCu3exA=",
      "url": "_framework/Microsoft.Extensions.Options.w3dsngkxpb.wasm"
    },
    {
      "hash": "sha256-kB+vcJr9OWqlhFNDqdl4hrCesoHelSc6j+I64ymVhe0=",
      "url": "_framework/Microsoft.Extensions.Primitives.ggysv59g1w.wasm"
    },
    {
      "hash": "sha256-cwIV6cgn06BArLFl2PfLREMxRWH2iEw1GkvZ/MsWeWI=",
      "url": "_framework/Microsoft.Extensions.Validation.vpl6b9qgbk.wasm"
    },
    {
      "hash": "sha256-FTVJx7gilBV/VWu+ibz7K8ueo7JUXPGj94aH0rf2FXQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.58jjh3bwur.wasm"
    },
    {
      "hash": "sha256-gUnLgLrtC8/HlgyHO2z3vR0eZArtXGGG9wOsTbLVglA=",
      "url": "_framework/Microsoft.JSInterop.bxtconcgfm.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-qIHmYHu8Tx8xpLRm1wWccLL8BTvtOR33aCodIDqE7yY=",
      "url": "_framework/Radzen.Blazor.szeblzox47.wasm"
    },
    {
      "hash": "sha256-BWwY2dUZzHVD8MeYmtKYPL1n3/++QO2u6VVMOEli3j0=",
      "url": "_framework/Siteswap.Details.ti6swfef0q.wasm"
    },
    {
      "hash": "sha256-TVpFNyq3KwsHrRVB+AcnhhdL11fgkJ7Dge8ISABdpVU=",
      "url": "_framework/Siteswaps.Components.domadfc1yv.wasm"
    },
    {
      "hash": "sha256-ld/Nc9XCkunpeEgZmPp5UGA66XQjsVnzirdamDV/agQ=",
      "url": "_framework/Siteswaps.Generator.Core.fvg4u9t6kk.wasm"
    },
    {
      "hash": "sha256-gnzmGj67hQ2h6a/Z6cLyC8IkCe+8DdaSuw+ERLVEuCU=",
      "url": "_framework/Siteswaps.Generator.invte4i3hi.wasm"
    },
    {
      "hash": "sha256-hrllQmn+m0Cgi/tM0Yj7aNJ1AEgL3MyuhU/BW8RSkWM=",
      "url": "_framework/System.Collections.Concurrent.yablujxcw1.wasm"
    },
    {
      "hash": "sha256-U5L+duX3dAxD50fAuQoIq0KSiI+L0bKaMbJhYk31pLE=",
      "url": "_framework/System.Collections.Immutable.ralimkzu6m.wasm"
    },
    {
      "hash": "sha256-o9UOZmL2NGykFMuCYPKlrA0WrIOwdjqyo1aScL4mN1U=",
      "url": "_framework/System.Collections.NonGeneric.hjiqachlz8.wasm"
    },
    {
      "hash": "sha256-/CQxHw36vff4Y8Ky+gdVjAF/chqMCHvrjNIMSxMNw2U=",
      "url": "_framework/System.Collections.Specialized.ojsaopdx8h.wasm"
    },
    {
      "hash": "sha256-RoVq1NydMhUai8P+iZU+xoxf3G6yIn84fSQnFMKJw8U=",
      "url": "_framework/System.Collections.qjkdw3d0pw.wasm"
    },
    {
      "hash": "sha256-dHiqjK5aENcSF7BH33uOecgRhszgyl3XHq4DjebBCp8=",
      "url": "_framework/System.ComponentModel.Annotations.o3rpjckl1m.wasm"
    },
    {
      "hash": "sha256-bHEx087sTvkS/hsG+9mT4wMO07Xmn17FszL0vSHX59k=",
      "url": "_framework/System.ComponentModel.Primitives.keeyovs9qi.wasm"
    },
    {
      "hash": "sha256-lDXFKoFpAJiR+p7udulqTgUhGQszvxI5oScRcP+2tSc=",
      "url": "_framework/System.ComponentModel.TypeConverter.8lfa9hdsti.wasm"
    },
    {
      "hash": "sha256-0ziwZjBchC21l/Xxwu8RK/GtO5Mx4LcNziMfzEhQUn8=",
      "url": "_framework/System.ComponentModel.to7xi487g5.wasm"
    },
    {
      "hash": "sha256-kkwtyVwgWz1S7r86k2Ja6whLJ+dcjyx4etW2iqtV2wE=",
      "url": "_framework/System.Console.a2se3hwwv6.wasm"
    },
    {
      "hash": "sha256-ClkRunIKwPDnYS7DtqeoRFyo/qZYK1qcdDs/LQyVngU=",
      "url": "_framework/System.Core.mszblqghkw.wasm"
    },
    {
      "hash": "sha256-JosLlD5HZ+KzcFk7s+Hf/VfCkHD/S2sIvwrbpNrtOr0=",
      "url": "_framework/System.Data.Common.2eapcq096x.wasm"
    },
    {
      "hash": "sha256-wuan0LPo3bd8x6b/zwSUpdcVQhzNJrf6NMuKoEZnEVU=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.aqxg0e6qi2.wasm"
    },
    {
      "hash": "sha256-I5FbkocpKgNYsdPzMAdcQ5wFWBltzgsF8I5N9qQijH0=",
      "url": "_framework/System.Diagnostics.TraceSource.f9tkchx5wn.wasm"
    },
    {
      "hash": "sha256-xYl+klCpZxUOShdaByTfB9SUN52ad9QwSceu6rXRdVg=",
      "url": "_framework/System.Drawing.Primitives.xhkwm166db.wasm"
    },
    {
      "hash": "sha256-WKUq/8/T1LPe2Fyy4LLvvyl4FHtt6T7zCREMzthqeDs=",
      "url": "_framework/System.Drawing.sfv6afh671.wasm"
    },
    {
      "hash": "sha256-X+FBHTC+LzL3fo1DVoxoScxQ0/8KEzYthSmt6G5A/GI=",
      "url": "_framework/System.IO.MemoryMappedFiles.18crcv0hje.wasm"
    },
    {
      "hash": "sha256-U40nDmWhvki2ysl5ZN4nXTJ/25f2Owz3e9BIBOqLS1Y=",
      "url": "_framework/System.IO.Pipelines.5ujx8ulk75.wasm"
    },
    {
      "hash": "sha256-kCn05pitMJb4HeHW8//LYoOnmmVre2ARo/2fCjaKzd4=",
      "url": "_framework/System.Interactive.Async.w4ccatvl43.wasm"
    },
    {
      "hash": "sha256-e7f/b+XuYlL7gnMn3ZSLldZLWLhnjmjnS9e/lc9nFhI=",
      "url": "_framework/System.Linq.Async.9ng5pnnqa8.wasm"
    },
    {
      "hash": "sha256-l3Hj1w83v6n5Mlo8xSznTdMhZ031SyRINY1zESErPVA=",
      "url": "_framework/System.Linq.AsyncEnumerable.tnhca8gle9.wasm"
    },
    {
      "hash": "sha256-5mMcR6Lmx8cWJWZek6QwlfKvlcYMgwRBLA5/5KeAVes=",
      "url": "_framework/System.Linq.Dynamic.Core.yt3i0kvfqy.wasm"
    },
    {
      "hash": "sha256-6WKX5C3xCjHQu/ocKiL3QlxYRIjls5T0akPRNx5AnVc=",
      "url": "_framework/System.Linq.Expressions.7ob4ldwo55.wasm"
    },
    {
      "hash": "sha256-4DSlSc9DuO1s3gB3UjQ1eQVRse9MgNtaTPwJMI2a3eA=",
      "url": "_framework/System.Linq.Queryable.ch7wz1iq57.wasm"
    },
    {
      "hash": "sha256-+bl/6bnHECzDrggGQ5S0vscaQFj1dFA0Ss7SftvaUGI=",
      "url": "_framework/System.Linq.n81v2jc0wa.wasm"
    },
    {
      "hash": "sha256-/6aDVMsCo/xAsPm8uq2Zvs/mPp8NSnLBg80wHKYVatw=",
      "url": "_framework/System.Memory.r1ckp544m1.wasm"
    },
    {
      "hash": "sha256-m5VUwFZec4u865EMT1cH3OTVr68vign4CPv9vv0Pakg=",
      "url": "_framework/System.Net.Http.hhf003bil4.wasm"
    },
    {
      "hash": "sha256-64fWWqjptfExUUYS/t2CQE2OsRglPaOI2oUXbCye2Aw=",
      "url": "_framework/System.Net.Primitives.7t134mcgzu.wasm"
    },
    {
      "hash": "sha256-+UNRJDxb+b8vEpfBbPibiDc2oRkxJM9yMCtpmAe0Fug=",
      "url": "_framework/System.ObjectModel.9grkcgjagu.wasm"
    },
    {
      "hash": "sha256-daPvyl3ler0LkL49UauFpSl+YeANhiIsk1i/or50i8E=",
      "url": "_framework/System.Private.CoreLib.lgud49o4xn.wasm"
    },
    {
      "hash": "sha256-VXoSBbwxPpOaiGXt0AUG64ek6XILG74J+AHim0kXYbQ=",
      "url": "_framework/System.Private.Uri.bo4sfovnvs.wasm"
    },
    {
      "hash": "sha256-RPB/iCxCbQbmxjhQHKNvQvCQQ75s4Eg/1SmGiQvIzL8=",
      "url": "_framework/System.Private.Xml.Linq.4if5ut4uvg.wasm"
    },
    {
      "hash": "sha256-mLl+A6V6cvxfXKwqWOch1GY1apN1MGUImEBtEIOnKEY=",
      "url": "_framework/System.Private.Xml.k983lq9szd.wasm"
    },
    {
      "hash": "sha256-iS6rCDwm3hDfashhiGmVOApiVdu6rVQ0EhRJ9aURqGk=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.jpqlnszj4f.wasm"
    },
    {
      "hash": "sha256-N0SLaw+MRUzvo8oLlc+AKIBkAxnAMlj3vhy3h3BB5DA=",
      "url": "_framework/System.Reflection.Emit.h2vqgnds4f.wasm"
    },
    {
      "hash": "sha256-e93b5q2MgWZ1KnX/mnYSQ9jSV+nwt4IeQ7r34Y7uybk=",
      "url": "_framework/System.Reflection.Metadata.bw7uyifa7u.wasm"
    },
    {
      "hash": "sha256-0as3GpS5RofTsrGMXBcS34uPilKSzARn71mLryBe+bo=",
      "url": "_framework/System.Reflection.Primitives.fwq0oxl9pf.wasm"
    },
    {
      "hash": "sha256-jj+hXeHxXtNJ/yFTBFkWF83+YlrVlIlndehUiym2PoQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.yzg2xf6fe9.wasm"
    },
    {
      "hash": "sha256-KB0TE1OfMUz076x8jL3nYYLNyocTKdVnLtN6CB5wRMk=",
      "url": "_framework/System.Runtime.InteropServices.czq9qmgm70.wasm"
    },
    {
      "hash": "sha256-G2Bg5MzfBxTdrkntTZN915PeY4I+xsuLuHBEVHOBl2o=",
      "url": "_framework/System.Runtime.Serialization.Primitives.pndzshfo0v.wasm"
    },
    {
      "hash": "sha256-Ggot2ANlniPSPVhSKZ9JBw7eq6zZEZUuaDzMUFpCEaA=",
      "url": "_framework/System.Runtime.mkc1sxcmjx.wasm"
    },
    {
      "hash": "sha256-E04MD5+M8yUnUB3bCz1aqecOvGzLKoWYaMzJ+vxfHro=",
      "url": "_framework/System.Security.Cryptography.js9a235qw5.wasm"
    },
    {
      "hash": "sha256-p0I/gu1hfXiqySJ0vHMhSHtvZJzEZT0WOYNWq4peun0=",
      "url": "_framework/System.Text.Encodings.Web.5h7q1pbb0u.wasm"
    },
    {
      "hash": "sha256-dk+cpnFpFX3IpXbXnpR1bWlcebsYZqh3pP1JqW6CfrU=",
      "url": "_framework/System.Text.Json.yej1gqmmrl.wasm"
    },
    {
      "hash": "sha256-HQZHqnBdNXv7Hpw9MMbc1ia3Pd0w+S+ITogOiR9OREw=",
      "url": "_framework/System.Text.RegularExpressions.bite5i8lro.wasm"
    },
    {
      "hash": "sha256-Rzr3hUNRgvkL4MnG9Lmx7QadniwZlb8lzsD6h4nGGKo=",
      "url": "_framework/System.Threading.rrmk6lxpyq.wasm"
    },
    {
      "hash": "sha256-tX/JbNS/m1t9QwF5G1uCbsMVasI7qr9K4iqR1KMSUAY=",
      "url": "_framework/System.Web.HttpUtility.5olguwlgg6.wasm"
    },
    {
      "hash": "sha256-x8MB2DkAOXhOCsJ/AzpobuVUqt727s2bp6fDdDQ1d8A=",
      "url": "_framework/System.Xml.Linq.bno46imr5t.wasm"
    },
    {
      "hash": "sha256-+Gif8+ZkUfFHYl2jBZ2iUkO0Q7IKlJXxUhQ8ow2uSuo=",
      "url": "_framework/System.Xml.XDocument.guz2zhmw0p.wasm"
    },
    {
      "hash": "sha256-d1dcH2nxptL8QLqZqtRI5G+lrjrbUKrUOnC/yloVB98=",
      "url": "_framework/System.l9jolnojrw.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-alAcGwbnD0Czjxlj4yf2Lx3cA4GENa/CwtZ/aCs39a8=",
      "url": "_framework/Webassembly.uesfy4ocmf.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-z4pgesCkgmRYbnvRLBo0IncaMw2BrAVBXNZrMKodNKs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-Pmnf4KlkCOdQHxefP1dCJZrtG3hC0rH+VsXPV3tJvTw=",
      "url": "_framework/dotnet.native.eod43mlovh.js"
    },
    {
      "hash": "sha256-ktuhYimzdZMXPabh4gC0tyuc+5jmdWnT8LRkYF+eIdc=",
      "url": "_framework/dotnet.native.uhh46h82j6.wasm"
    },
    {
      "hash": "sha256-2lZh9yO0fnzm3Xt7yV+Kox3DH3nK7L8hDhm84VT1xco=",
      "url": "_framework/dotnet.runtime.2tx45g8lli.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-JQjQU6HsuDSrwQdR5C5gjqbs3z2deRP5slxWTvNw7S0=",
      "url": "_framework/netstandard.71v7fscxh1.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
