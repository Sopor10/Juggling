self.assetsManifest = {
  "version": "FPYBkSiU",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-PSNvnV24ag+SGg1IqoZFElEhYwFbJesli8dTjeVrRs8=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-GUGE4Ic53vgY1z+S0Tjuyq3nNLZuPHhrn2WIUADyKqY=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-EqekAACIvGn+BzEQNyKtrBnMxa4TJKka4nvfJCxWI1s=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-oT0AFvDMScxXr9NJOSkkExxIjxdlCW54rFaObRj8168=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-ONPJMnz+8ymywSQcf2SNu1/JyLjZ82vh63Aw4W837XA=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-e+ez+HsLmQBtb1rJ/dmNL5wzbeRwbKdfvhwKqSWI7aI=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-0l/BVYcWLkQUmSombv/xeg/2EID0oor31p+4I/GETW8=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-EYr43ww4zQp88+PiLhoJiz6WhsP5Etm4YPxX7ukp/ZA=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-LUkl9GDNHWfNm5WKFHPAMLGKtrMdSQYO2FCmGz0VOSw=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-G1vX7rSefBwvqDj8sQkCb2s/AMzSPRsrpvhZ50fv3vk=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-W3my/u11XGlNQgdRGAB9SfHGevH8Tz8JJGOGF18lp8I=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-GH+pZhFw/ttZyUlYERg5MymsNmdCDxNHlRxc0Zg/XvE=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-RrbfvEKPx2i+7DwnVAwIawaNmNdY16z+2opp+wyYy+A=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-IbXcLhCGLLiwfZP0XoE4LwogjxJpuCsxt2bLxYtsK1U=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-FQFhpNMcxu6iJB48WEAOIbI54wb4GZw8eUS5jc5ZS9M=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-IqebHpObFfJwt35zLUkNRhwRRPu43+GjGYwuuv80vsQ=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-7Ybjf86BTTZE8vtvQDMit4Qziy+JgVQWaaTvnizcl2k=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-J3xX0NyH4GX7TFMBl2jv3+YQCKaS31liM8LIyElsYlU=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-ES+IU6suO8xnaTREbUqzWHMFfHJ9OTq4m9QIWqffK5k=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-KgNWfaF1iIh/HoGqRO2a+o1ljg8JZRxQ+JNQjHbZeNs=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-4yq2FvfFqifIk1NPw343s3q2ZGM0dHNJrH4fux869Uc=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-sRLBWmFIh1BpCYWUffUu/wQPvd4HqTzuBTc6ATVYdDI=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-Ei9xUUNVuLD49lEsXfW8TX8Kxmt8+bo+tZyR75qHecE=",
      "url": "_framework/Fluxor.Blazor.Web.q1j6vb2ay7.wasm"
    },
    {
      "hash": "sha256-ASpfANUD0+QbO1vvg5xO5SqBbTNDW8FZd1jd/lQlFgY=",
      "url": "_framework/Fluxor.dlg0eaereb.wasm"
    },
    {
      "hash": "sha256-x4OZ34vzk+smNBTVDO0X1fONp0vYPzg/TpNplBGcXrw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bfujbirxhp.wasm"
    },
    {
      "hash": "sha256-gqkUy66t3eWa6R+puuqCUwZqGGChovxYRS1xbKXSFTw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.mm1t5p4t7f.wasm"
    },
    {
      "hash": "sha256-zry26eJypYx4o2K3qfwApszsPt3SOYnZkZ2jtvYs2sM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.qdmy7cs13p.wasm"
    },
    {
      "hash": "sha256-VakU9JmNqyrvt4EQCQI+4Lg4ZDXNWPt425QyZxF2TfM=",
      "url": "_framework/Microsoft.AspNetCore.Components.f7ascurvon.wasm"
    },
    {
      "hash": "sha256-/1p2aEs88mAtEdH+P77W1csyxu+/u5i6fBLk9X/74ng=",
      "url": "_framework/Microsoft.CSharp.bpz92jhne7.wasm"
    },
    {
      "hash": "sha256-LOBBULi/XW4t2ARw193f39bYefcOCpZQu9Pnx/xG6+M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.4ascqjkgzo.wasm"
    },
    {
      "hash": "sha256-VlasUHL3ewmPDatuOzkCrOTyTwPkIVd24650+2CW75g=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.iitlxos134.wasm"
    },
    {
      "hash": "sha256-Y630CXldwUrJGf3O/yGiTNE/FOC4PhRpBYK+w5He9Kc=",
      "url": "_framework/Microsoft.Extensions.Configuration.xnovko9l24.wasm"
    },
    {
      "hash": "sha256-REUC3Flk7UFExEWikuLNxQdtV8wQHG8JvtuD/eSSyOg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ofhwh548wt.wasm"
    },
    {
      "hash": "sha256-cz1Zot0busqSISH6LUmoeZwyy3joC96syZfHS2R1g9I=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.pdq83eroqe.wasm"
    },
    {
      "hash": "sha256-ED3btvQNynKkxhlZtG5I2E+X1528YLLk4sDWh80texw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.4vhiktfaqi.wasm"
    },
    {
      "hash": "sha256-fED0AC2P9vox8e6kgxvz0ISVfhAlQhsZX33zoA9Zk8I=",
      "url": "_framework/Microsoft.Extensions.Logging.grenq3p3q7.wasm"
    },
    {
      "hash": "sha256-AQhhfhLMv+vwCiCQeW4MP+PDX6zfp618jfAvEhlGEzc=",
      "url": "_framework/Microsoft.Extensions.Options.rpe6kdgyiy.wasm"
    },
    {
      "hash": "sha256-ZBy3LVR1MRfpTzx1Oh4qiMpv0ZdTFGJwv8GsPfK9U0E=",
      "url": "_framework/Microsoft.Extensions.Primitives.072etlnfwu.wasm"
    },
    {
      "hash": "sha256-cgmXidzz7CoeFsl5yxjG5f+5moq0I8EiKUGIXMx2018=",
      "url": "_framework/Microsoft.Extensions.Validation.u5qkcvapwo.wasm"
    },
    {
      "hash": "sha256-f+I2R08bHmRaAE3/piqZWaqWiQb6TBqG7lPslmC9YXU=",
      "url": "_framework/Microsoft.JSInterop.37wmaf32t8.wasm"
    },
    {
      "hash": "sha256-KBkrmyz1+94H8YEVvIm+A6GPyvHKGGl8MFQONEwpVkM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.cbdj3f5i9f.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-gRqidccyOGLar8/gvj+n01eKP/Tmhp1FuhZgJtIYW/w=",
      "url": "_framework/Radzen.Blazor.nuvdnvvzj1.wasm"
    },
    {
      "hash": "sha256-kby1g5DKb8hvpUQuimqynCSi2r2mFKfWamZenDnvt0c=",
      "url": "_framework/Siteswap.Details.xw7i09w8lk.wasm"
    },
    {
      "hash": "sha256-ot7cOmuvcqw1UkqmtyDBh94r0toQySocNxphs+XPGs8=",
      "url": "_framework/Siteswaps.Components.20ymhemaqc.wasm"
    },
    {
      "hash": "sha256-w/+JYUeqh6bQ1bTm9jwMukRsRAT2UuB02UCrrVPX5So=",
      "url": "_framework/Siteswaps.Generator.Core.d46la5n42n.wasm"
    },
    {
      "hash": "sha256-cftgFY+I53kk9N9ebDCbJ/Y66ZJjtlH1/ZweJpNR/Qo=",
      "url": "_framework/Siteswaps.Generator.ho4z9k0q6l.wasm"
    },
    {
      "hash": "sha256-No8Ue3LDOl5gu+1cCUQ7QTW+JjFkhKn+jrlnv3W+hIM=",
      "url": "_framework/System.Collections.Concurrent.ix4tttoqcj.wasm"
    },
    {
      "hash": "sha256-vunHVdn+AEYwDME061oY05T2Ar94rTBeRtov31nVxmY=",
      "url": "_framework/System.Collections.Immutable.uguuseipod.wasm"
    },
    {
      "hash": "sha256-az83sY0OurBvWoKbCpKNpD2edxCBL72/jJFyd5uf284=",
      "url": "_framework/System.Collections.NonGeneric.jm8z1mr78a.wasm"
    },
    {
      "hash": "sha256-1+cP1Uh/SXSOhh/YdbY3umYHntX8pflnDmrQPZ7O884=",
      "url": "_framework/System.Collections.Specialized.l17qik54nk.wasm"
    },
    {
      "hash": "sha256-ldvu8teZb3/eFv30LYu+AIzPR11ygP7bcWYOMDGEHqo=",
      "url": "_framework/System.Collections.booe0s4u5o.wasm"
    },
    {
      "hash": "sha256-c4WYN0Ul7GWOXTD0lWVmoxmDBlDlJsh7uo+uCKnFbWQ=",
      "url": "_framework/System.ComponentModel.Annotations.hnk8om38ho.wasm"
    },
    {
      "hash": "sha256-sPpxu4zMP4zQpq0DJnJE8s9pDUhsgW/StOEsdQ6yJoM=",
      "url": "_framework/System.ComponentModel.Primitives.820gl3gyfl.wasm"
    },
    {
      "hash": "sha256-Qc1CcmqMV6aLiJfbmI2GUDgwCgFlds5FvlJi4Fyx1pg=",
      "url": "_framework/System.ComponentModel.TypeConverter.bdu4oa8zd8.wasm"
    },
    {
      "hash": "sha256-J1lLLtC4XYSVr/33KkpAPwfdmdFAm0Tg4PkXsl7XfLw=",
      "url": "_framework/System.ComponentModel.llxzyckf9y.wasm"
    },
    {
      "hash": "sha256-s9eN0UubkwQWPLDZ2/Rsu+VxVlB7OAVD3ClfmaCc4SM=",
      "url": "_framework/System.Console.v1b3dg96rr.wasm"
    },
    {
      "hash": "sha256-ag/nuu8HxQvPxf3zsc3bc72vsB5Sh8AZzLuZdPQ4tNs=",
      "url": "_framework/System.Core.q78gfdimq4.wasm"
    },
    {
      "hash": "sha256-gmKCzYWeWZJNY+bm3TqgY6ZkFSZSWMJFlwQOyaMg8wI=",
      "url": "_framework/System.Data.Common.e58dc3wmqc.wasm"
    },
    {
      "hash": "sha256-QG32hX/a8Hnb2TlaKiu13vKNl4VoD2V8euI5if7NrQo=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.oi2khari25.wasm"
    },
    {
      "hash": "sha256-An4YfZg2VCLmeHYJVJyKzYpuAWQFCaSeCQTRLARLtSY=",
      "url": "_framework/System.Diagnostics.TraceSource.m61wko4q2k.wasm"
    },
    {
      "hash": "sha256-dcVFgmMVBRxuz54Q5i7gffR+bvgR/STsHXBj7gbRIjY=",
      "url": "_framework/System.Drawing.5wzvqdpfg3.wasm"
    },
    {
      "hash": "sha256-l/Jx1RRsae1b+4vGlfUUuDfzEbzujQMTRFTL0XblDlQ=",
      "url": "_framework/System.Drawing.Primitives.nouhd0pq5i.wasm"
    },
    {
      "hash": "sha256-6qdYCxcMX2fcCNysALQOyqvqgmPPYhEMC82v3HOpT6Q=",
      "url": "_framework/System.IO.Compression.2d4wq8sdaq.wasm"
    },
    {
      "hash": "sha256-i8qCdBUEXc3ymRNVvSNrEEznrZkFeUBCVYyffI83aUw=",
      "url": "_framework/System.IO.MemoryMappedFiles.pbp1zj1bh1.wasm"
    },
    {
      "hash": "sha256-VAItgUEBvLcUdhWi2dVGBp/lsYOLjES6nhQF93Gd1m4=",
      "url": "_framework/System.IO.Pipelines.0luqpzcwkx.wasm"
    },
    {
      "hash": "sha256-a8sIspKRsVcSOPusqEHzyr7IyaBGIEjgcq910v01os4=",
      "url": "_framework/System.Interactive.Async.juae56i6ub.wasm"
    },
    {
      "hash": "sha256-+H+PL4ozZ167jwAlf/toNTlEoM7C9aiP8MPZ0kyllGQ=",
      "url": "_framework/System.Linq.Async.0udklamc7c.wasm"
    },
    {
      "hash": "sha256-frco54jjBlsmZAVr0JCTDyNVtMjNXur2NNp2ka0oGCU=",
      "url": "_framework/System.Linq.AsyncEnumerable.ynqelxmeet.wasm"
    },
    {
      "hash": "sha256-gGPmfZIowoY2Wr2QIrt34PKngwwLTbUIx6oLsb4AOZw=",
      "url": "_framework/System.Linq.Dynamic.Core.spqx2v4wpx.wasm"
    },
    {
      "hash": "sha256-QTHDvmw35Xs1fefQpZ2FsdDirFBVwM2iKri4qeKZzWA=",
      "url": "_framework/System.Linq.Expressions.hswxtofm9g.wasm"
    },
    {
      "hash": "sha256-2WdPayHXlc5XwlRyB31+6yG3wLiRt/20b/RVGY2v9K8=",
      "url": "_framework/System.Linq.Queryable.hmjutrykee.wasm"
    },
    {
      "hash": "sha256-QddAjIjUORpxrHNgydQRu6mrgKP4VQkiRiXFWORUUwI=",
      "url": "_framework/System.Linq.t14njw7qpw.wasm"
    },
    {
      "hash": "sha256-9OllrsjdZObEgSKXMVvO/UgEEA7JYrVgNOJlJgQaGYI=",
      "url": "_framework/System.Memory.071cpnd9cn.wasm"
    },
    {
      "hash": "sha256-HHUP9uIihOhH5dgItKGgY3OrKqpYM/ZBJ2G0i4nc5gk=",
      "url": "_framework/System.Net.Http.0b9ost0438.wasm"
    },
    {
      "hash": "sha256-1xoyMs5BiZDtqJOlM8OkkLhYkjNvc0wzFE/yO76wdW8=",
      "url": "_framework/System.Net.Primitives.5dpvrmwpzs.wasm"
    },
    {
      "hash": "sha256-p14I5p7g04TxC0bJuXhNvpvqlqh05qq//8zaLT8xsFI=",
      "url": "_framework/System.ObjectModel.9gtpww6t50.wasm"
    },
    {
      "hash": "sha256-VDOOEvrR9QfEjbRubIMFXCvrnLaujB9yeN83LyBlsT0=",
      "url": "_framework/System.Private.CoreLib.k21xxe16vh.wasm"
    },
    {
      "hash": "sha256-lCory85Gf5b+4Ts5iZ6Vq7cNt1gQ64YmVU+dl53yJAM=",
      "url": "_framework/System.Private.DataContractSerialization.olihpxwa4p.wasm"
    },
    {
      "hash": "sha256-ZLL2JdbVwExivgPsCXgJ+D4JvL5pv2J+oXuSH+qPnmk=",
      "url": "_framework/System.Private.Uri.gxzamqemuv.wasm"
    },
    {
      "hash": "sha256-aJbaUk7gVR96bMBVp61T1RbdIr5GmQSc7ksg2jnEiZY=",
      "url": "_framework/System.Private.Xml.849psc1p84.wasm"
    },
    {
      "hash": "sha256-qmh3YJ/xg2qs9c3/eNxvY0mHKpX57OXBxuf8kavoX0k=",
      "url": "_framework/System.Private.Xml.Linq.2h7ixwilvg.wasm"
    },
    {
      "hash": "sha256-AsKTV4uKws29scnDzXbazwEsweByxfjw8QVV0rXvlF0=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.qp6omod8mv.wasm"
    },
    {
      "hash": "sha256-dfyKRAmUU/ylby1MRibmIYmEv7q1MH9dg/tzYX81/zk=",
      "url": "_framework/System.Reflection.Emit.nx5qft2tyg.wasm"
    },
    {
      "hash": "sha256-4bo9Gu3ajxhKT2j9+pzpzHtFupoGjWVmAKVyBHRuS2E=",
      "url": "_framework/System.Reflection.Metadata.9id2ac140x.wasm"
    },
    {
      "hash": "sha256-AlwoS7lmuxVzz+JVwEHJGXgFHhp22BPataSHTYdY2a4=",
      "url": "_framework/System.Reflection.Primitives.6n0zme69c4.wasm"
    },
    {
      "hash": "sha256-8dAeYP1ooz071MHVhHIVl6ljhupDIHU5h6aDO7fhLBI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.xs6yu76bks.wasm"
    },
    {
      "hash": "sha256-mFgg+qcpzec/UPCag2xkzpzp5RQwaPGVCXYpSyyECBw=",
      "url": "_framework/System.Runtime.InteropServices.kdrgmxrrq0.wasm"
    },
    {
      "hash": "sha256-lnKcezElXz/FBFOOxLLDVco9r+AivdpYu6l5DGihRlo=",
      "url": "_framework/System.Runtime.Serialization.Primitives.mdgerqqoz0.wasm"
    },
    {
      "hash": "sha256-TKIFkDD2RXDyYIrLEtkegtEkqBFZKy6vK89/9H58vrg=",
      "url": "_framework/System.Runtime.Serialization.Xml.4so90me2mp.wasm"
    },
    {
      "hash": "sha256-GhdgE0qatBfgyLyei+eONxqTuSL4K9PwN0BPPMH9ml4=",
      "url": "_framework/System.Runtime.aznqlqtto9.wasm"
    },
    {
      "hash": "sha256-mGKYRB8NlacLJJ8k8zj4tdQsDtJ/77l3jOLg+2cUyAQ=",
      "url": "_framework/System.Security.Cryptography.4liykvih83.wasm"
    },
    {
      "hash": "sha256-bQwr0yZ2Vy+E57aGNk84lo2p2tH+APqeqqQ0ZmhIEi4=",
      "url": "_framework/System.Text.Encoding.Extensions.zswydz4t9a.wasm"
    },
    {
      "hash": "sha256-iOQnC0EO6NhznNY2aKsBkxLd8b1TRGZqnbNDyg91eK8=",
      "url": "_framework/System.Text.Encodings.Web.0uxxf7995q.wasm"
    },
    {
      "hash": "sha256-buCD0c4MIXqG0/bgFq1WUPryzD/wD74e6xHjwmTDIU8=",
      "url": "_framework/System.Text.Json.2gpj8kk8xj.wasm"
    },
    {
      "hash": "sha256-8Mmh6d6Y84JgujEfH5k/pWw0q/HCnIjryOXDV3bNwC4=",
      "url": "_framework/System.Text.RegularExpressions.4zcxm9jpw9.wasm"
    },
    {
      "hash": "sha256-5Avss/u3NAzn1o8Ppn6kFG2iOzu9A34Uhc2YphtK8Js=",
      "url": "_framework/System.Threading.gr05tlvbi6.wasm"
    },
    {
      "hash": "sha256-qgj63g79PE9uCs+nsacYdQId+bSEXU3JFdE5OZ+fvJY=",
      "url": "_framework/System.Web.HttpUtility.q4omxxkvaj.wasm"
    },
    {
      "hash": "sha256-cUe2Rpuwodxb9Zl4Aen3bgv8hlEah7r36PWyeIRYVWQ=",
      "url": "_framework/System.Xml.Linq.xorxxf2zgs.wasm"
    },
    {
      "hash": "sha256-HX5efHWECzB1YyqQ6/dxtu79cshBe1o0YcYY9TJy2ds=",
      "url": "_framework/System.Xml.ReaderWriter.l67v498anh.wasm"
    },
    {
      "hash": "sha256-j/CstLClYdDiBda/PZCJyzpHXAv99NCFnEyMyf4Wqy8=",
      "url": "_framework/System.Xml.XDocument.t1jku17uks.wasm"
    },
    {
      "hash": "sha256-GBsoWgsm7nTRKlb5Lr430r1XsgW1gVH+jeoGAIS2K00=",
      "url": "_framework/System.cvgusyd4es.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-7kb0NQlrJWyFqIjL4rIt/Mx3ZD8wezZIxzAH4qU4QHc=",
      "url": "_framework/Webassembly.ay8rnzrfyi.wasm"
    },
    {
      "hash": "sha256-A59Tr9HqEhHMu8kU7kruLI9ayw5MRS6Lvc6z7jCbghk=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-HD/OmJ53zTm/e3gyifk5zM/pryCB/1lAipQIfjritHk=",
      "url": "_framework/de/Radzen.Blazor.resources.4c731qz8g4.wasm"
    },
    {
      "hash": "sha256-+WvsUaSjVHi7zxnvayBbVHdd1mBJQXHXnnV7GffBzg0=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-tdU+G1tlFR0pyrK59+huCZHmYNy5d+HArja2MDBAnLg=",
      "url": "_framework/dotnet.native.1pry5ky876.wasm"
    },
    {
      "hash": "sha256-EIWrc/VZ6acKyRirnn/SeGfDdJeNOQmua7yuGX8dxL4=",
      "url": "_framework/dotnet.native.o62sndsgu6.js"
    },
    {
      "hash": "sha256-SOUHEQ3FhDAibBSR2u90NWZpoBjPuWRmH0BAATUlhJU=",
      "url": "_framework/dotnet.runtime.web2r9gqbh.js"
    },
    {
      "hash": "sha256-s7M+jKkQFrYLmAuNW97btq8KSDSsMVt5hWxTx7kR+Bw=",
      "url": "_framework/es/Radzen.Blazor.resources.fxwseozrwx.wasm"
    },
    {
      "hash": "sha256-sM9Zv3PE6mgB30oaWeHeSbeIfRWZ85p5xB8xoR0+Juo=",
      "url": "_framework/fr/Radzen.Blazor.resources.wkgzljbii5.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-YrqzI4lwcMAXMapOMAUtYLe0u5JIkQYYPvmWUbsYCSk=",
      "url": "_framework/it/Radzen.Blazor.resources.uxasw152tn.wasm"
    },
    {
      "hash": "sha256-mD6oELsmEMrc5VmbQIZ92qJ2Z1FMuVgye0ZhsMNbQQc=",
      "url": "_framework/ja/Radzen.Blazor.resources.802p324ynn.wasm"
    },
    {
      "hash": "sha256-lH946SwMqG2AEgQB3fCU2ZhjuVV1DVWQfptJZhtUeuU=",
      "url": "_framework/netstandard.4iek6pzsjp.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
