self.assetsManifest = {
  "version": "Si+8BFXh",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-wFQy3YZ5B8tDE7SVlSyd9DbC8XstJj9OyCDgmF82L18=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-z+X+dG5UyqqngwfUpSBk7xnunjafy3H7xTyJvw3Wp6k=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.puij8nbrfn.bundle.scp.css"
    },
    {
      "hash": "sha256-4WxQOlUyppqr8kLmbIRxdsocHLK9+f3eRHUQLKOtIMg=",
      "url": "_content/Siteswaps.Design.Fixtures/Siteswaps.Design.Fixtures.zvqgbbndl7.bundle.scp.css"
    },
    {
      "hash": "sha256-83Y3VqGBsLcjg5Utw3RDNG+auv6zqH4/PPwavI4QwIA=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingPage.razor.js"
    },
    {
      "hash": "sha256-o25z5uysRrF+qMuOVpDgeBLWXM3QNnTM7HO4fyvughg=",
      "url": "_content/Siteswaps.Generator/Components/Feeding/FeedingThrowChipRow.razor.js"
    },
    {
      "hash": "sha256-rWswo2OSS3ji2dvr19DmobleNULxHesPHT25kC7AG48=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/Controls/DualRangeSlider.razor.js"
    },
    {
      "hash": "sha256-lh2MEHR0WF9aZGtQjFkebCbG2xjz2nxN7sGOrJapDtg=",
      "url": "_content/Siteswaps.Generator/Components/WizardPage/WizardPage.razor.js"
    },
    {
      "hash": "sha256-oIr4oEdzBG5eCZDd/S+zoVGIgJ7sHsnpi+z3aVPFpkc=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.k7dz5ec6ww.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-FpAhVpaw9UJbej/kZuE9tEhHu6MMEafaUZ/Hv8zf8nk=",
      "url": "_framework/Blazored.LocalStorage.e6jo5xh325.wasm"
    },
    {
      "hash": "sha256-e5XY5HktztH1G5D+ivPnTci++hOmoHdvObQeIJGYtNk=",
      "url": "_framework/ExhaustiveMatching.pvh0005fqb.wasm"
    },
    {
      "hash": "sha256-h+4NkBcGpMpryz24i57eMNFypbX1JxWaAF1ski048XQ=",
      "url": "_framework/Fluxor.Blazor.Web.rfh5ngd69g.wasm"
    },
    {
      "hash": "sha256-kmFR937gjSMYaugBUj01ICEI99F6HFm/q+iaZQMcH+E=",
      "url": "_framework/Fluxor.qq9ltcdeo2.wasm"
    },
    {
      "hash": "sha256-sTbr5pym1Z/C3mJ9yoP+XEATsUjw7lbIeHFON+h1sms=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.vw7x7bvjv1.wasm"
    },
    {
      "hash": "sha256-6UECy2Seqt0TrYfGKznaUSaEkHg/DiPeS6j94f/0Emg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.1qghzse0o4.wasm"
    },
    {
      "hash": "sha256-8mK7hgJyBpE4ftjblkCC1xZZi5jcRcW7BSbdFd2K/Ck=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.isjvd0g342.wasm"
    },
    {
      "hash": "sha256-r5it75bbKDtLBIY/MU/JhD70sYb+nwmkiLrK302AhII=",
      "url": "_framework/Microsoft.AspNetCore.Components.jn6ox4tlc6.wasm"
    },
    {
      "hash": "sha256-l8xuMPBIytDlsVipKcny4/V0zbAjJckJxqbtWJcncis=",
      "url": "_framework/Microsoft.Extensions.Configuration.1ezpgdlkhk.wasm"
    },
    {
      "hash": "sha256-/Jk54D1KY5PHzM9dMnGK+L/e29BGWKMvya9e09ag6xc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s65zlvl4se.wasm"
    },
    {
      "hash": "sha256-yLeqa+N7rj/oA+/DuzjYNyfXd1ErXM5krBAglzElmtc=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.svkmtmeo3a.wasm"
    },
    {
      "hash": "sha256-aBvQ/hjvWjNCG089D7owVJIUPazDqP+mw4FMH7xN0Js=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.sfzkvj0etu.wasm"
    },
    {
      "hash": "sha256-BrnBVVkQUUWn49a3UoYb/va0kZecITaFa6mQwQu5SqA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.a0b5cprttj.wasm"
    },
    {
      "hash": "sha256-Rg8PdVvAN4koIJa8pDEq6txL4gbV9K21DdRvtIZyAmk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.ip3icowt8y.wasm"
    },
    {
      "hash": "sha256-bxbrpY2YsCSVCMsIcRGtsyzTZFDCOkF28N/S7Jvv710=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.53qylfq3cl.wasm"
    },
    {
      "hash": "sha256-zbB736aJ7w57K//Fi5jka+QJSJ+SwI9omdlKrcfv/h0=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.tgbvdusdia.wasm"
    },
    {
      "hash": "sha256-9VcgrXb+PiPyrTcxIe1L/cy7Z5ZWOur7GlJkoKubrKw=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.v3kxgx981t.wasm"
    },
    {
      "hash": "sha256-Eg9BbHp7owM8vj1uN9pIGgfaauETqGCijD5s7YHUfGo=",
      "url": "_framework/Microsoft.Extensions.Localization.28r9tszzb3.wasm"
    },
    {
      "hash": "sha256-uMeDMd0qS3mI/CdS7eCG6mKIYBTFA/uzTIQx3JtVGxs=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.szsqjwv7n8.wasm"
    },
    {
      "hash": "sha256-tA6FujJGXoXMLA2ZzRfywB+4hOHShyj7vrraJHaS9bg=",
      "url": "_framework/Microsoft.Extensions.Logging.89kvhi8fnr.wasm"
    },
    {
      "hash": "sha256-u3OW7K44+lwUtdvjpA6OYcDGXZ4A8UVJutzVHAtVsm8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.zydg9waks8.wasm"
    },
    {
      "hash": "sha256-zLD2EYKEjOwsy4WDByKUAXm82lDrcLe3yr27qOPiVkg=",
      "url": "_framework/Microsoft.Extensions.Options.kug6q39pk6.wasm"
    },
    {
      "hash": "sha256-j0dnWZt1kQ7pbMLz3DSgDLfR/l2exwf1ebMveo0Hwlc=",
      "url": "_framework/Microsoft.Extensions.Primitives.tdwayxbjeu.wasm"
    },
    {
      "hash": "sha256-dTpn8r+xR2+7XDCQYr4b6TPjcHe5MaZLlIlYy/5hdMs=",
      "url": "_framework/Microsoft.Extensions.Validation.j23g6nh3wp.wasm"
    },
    {
      "hash": "sha256-VEB/4YtP9ySU4p2RtiTB5X0jKnexUUDF9ZO492ISjxI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.grtk0vdldj.wasm"
    },
    {
      "hash": "sha256-SXxZknLsjuJ2srBnwQWrVPOYNnagXR12cbBxU6/Lh7Q=",
      "url": "_framework/Microsoft.JSInterop.ha52dy43a4.wasm"
    },
    {
      "hash": "sha256-D2aFO++J+d2eE9RGg/gBdqcJunjgMz7Yu3Hw2YCzBrE=",
      "url": "_framework/MoreLinq.5njmhjv7yd.wasm"
    },
    {
      "hash": "sha256-xIQ2OP4hY0PSJfwwINdgnKkZEq4FOy/oNqJZDpNUL9M=",
      "url": "_framework/Siteswap.Details.gjczlv8bjt.wasm"
    },
    {
      "hash": "sha256-uL/nDiHRGcefD6YUZMIcr9XIScGaiDalrjc85eKIjwo=",
      "url": "_framework/Siteswaps.Components.4l5sxht75t.wasm"
    },
    {
      "hash": "sha256-uwZJVtBQn/8hgdl67dkbAQQfumN6RQy1NZ54pdfO+A4=",
      "url": "_framework/Siteswaps.Design.Fixtures.jiig937d0t.wasm"
    },
    {
      "hash": "sha256-iLJnTzh7jWUKrvONvIZbf8AqndZrtW5XA5wejp1pP2c=",
      "url": "_framework/Siteswaps.Generator.0qyrujccpc.wasm"
    },
    {
      "hash": "sha256-aMoAPjU8caYzVPsSrG4s27rnhSe9ekdlwMFMVC/1ntw=",
      "url": "_framework/Siteswaps.Generator.Core.4xo9cyhul7.wasm"
    },
    {
      "hash": "sha256-1osrAg6XPws9PtgplrODLAFi0tJp5TeTyaLiKarain8=",
      "url": "_framework/System.2lu0lvqlkg.wasm"
    },
    {
      "hash": "sha256-gvI+w589T1js0Bbvi2pCaCldWF6f4gLfAf58uewWp4w=",
      "url": "_framework/System.Collections.Concurrent.6yzat70a9c.wasm"
    },
    {
      "hash": "sha256-wVNnQsMhB0k0mxwWYl6pukmWm28u07tfLpydoLqBafo=",
      "url": "_framework/System.Collections.Immutable.pqgwzdqxbj.wasm"
    },
    {
      "hash": "sha256-qh7vTmJRxp1103N6m0gTSelC7mqtZJwMK+bFGv0tSfI=",
      "url": "_framework/System.Collections.NonGeneric.ao4kimabq3.wasm"
    },
    {
      "hash": "sha256-9IrBywdZlbih/k06IkHdjI+uXILWFCFKp2F+AetdaC0=",
      "url": "_framework/System.Collections.Specialized.s8d0y487c5.wasm"
    },
    {
      "hash": "sha256-rx7Yujr1H/KefiAHP0juLQRAJ0rQXJzcncESKvDaJOQ=",
      "url": "_framework/System.Collections.dp429lg9b9.wasm"
    },
    {
      "hash": "sha256-pZDEdW73XjgC+uDmT7wWDUjTomiz/0KyLmpsMBoO0q8=",
      "url": "_framework/System.ComponentModel.Annotations.x55aczy9pr.wasm"
    },
    {
      "hash": "sha256-77qRwSWzJzVWigdNHLMEP7UFpQ7jnDDH/eqmnfwAvSA=",
      "url": "_framework/System.ComponentModel.Primitives.zvjlf9joe4.wasm"
    },
    {
      "hash": "sha256-bUC3AlyFpFrik+qMttKACQu/HhkpU0v4fNQFd4IOxyw=",
      "url": "_framework/System.ComponentModel.TypeConverter.ftns0qf769.wasm"
    },
    {
      "hash": "sha256-YlLfq0EX1nNUW7tW8GNqnPWHcx7DFy9FK8XbjmjN47s=",
      "url": "_framework/System.ComponentModel.yc9cwij36p.wasm"
    },
    {
      "hash": "sha256-fInTeJ+EUUrYhpD+2WPK6siRKqEtmcBCJoTMzvfDL3s=",
      "url": "_framework/System.Console.g9n71t1nmv.wasm"
    },
    {
      "hash": "sha256-oeHQBtgPAcVpVOpvDIsIO9mY97N51Qo/MozQE/XZwfY=",
      "url": "_framework/System.Core.lzieern80l.wasm"
    },
    {
      "hash": "sha256-8gDNj8n6Lwlt5qLRxgzEm8hW9HOBDuqUdW2wcXB3H3U=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.iwi99caxnj.wasm"
    },
    {
      "hash": "sha256-uyaIE1q4oBqZqfk3pGj9UYl3z2te1m86DjBnpfVLYps=",
      "url": "_framework/System.Diagnostics.TraceSource.1ld2496uac.wasm"
    },
    {
      "hash": "sha256-hWs0v9to3b7BaYvZJab82U5oDM5/oW/UQDL63N+IzPQ=",
      "url": "_framework/System.IO.MemoryMappedFiles.7tidwlylnv.wasm"
    },
    {
      "hash": "sha256-r7wKAS7oxcoJTy7tCLMnkWk3Wi2l93xuyn/ZG+KTfX4=",
      "url": "_framework/System.IO.Pipelines.vw5bymtycv.wasm"
    },
    {
      "hash": "sha256-0Ava9QEAZzvicw6huLI/Lwt3mkFEbYYYmYgqguN6Ov0=",
      "url": "_framework/System.Interactive.Async.47zcrvq9fy.wasm"
    },
    {
      "hash": "sha256-oMwsQ+EjIOE/J2m67AJNJT2Zde5BIZ3Z6Hy4g/unDHk=",
      "url": "_framework/System.Linq.8yl2lb7t5g.wasm"
    },
    {
      "hash": "sha256-8rh0I8ytJ9YuI3d/UO+1qGTWyvfj8FWSzw+ujwASSUg=",
      "url": "_framework/System.Linq.Async.20jndnhczl.wasm"
    },
    {
      "hash": "sha256-TkBk1IfRRBQbMxKV7+BR+NxOU62jaA5EEi5qMd0Cbrs=",
      "url": "_framework/System.Linq.AsyncEnumerable.much190unz.wasm"
    },
    {
      "hash": "sha256-C1CP17yev2rIvnfo/+4/NwsOrr2Ejg3d3i5xmdltfPU=",
      "url": "_framework/System.Linq.Dynamic.Core.hhsvivqloy.wasm"
    },
    {
      "hash": "sha256-FXD/3XtcsOYRV8v4fMgSbtUBEw0qoheHRDgwXmDcFVk=",
      "url": "_framework/System.Linq.Expressions.t6m7059h36.wasm"
    },
    {
      "hash": "sha256-ajzGvu7X1POszeytjOwCbMsc+P7V3oRguxbfsY/ea+g=",
      "url": "_framework/System.Linq.Queryable.2t8wnafs26.wasm"
    },
    {
      "hash": "sha256-xTJF5Q4/1j3dLabtmKogdFxho+IgVWRAcfx2D9Kl/10=",
      "url": "_framework/System.Memory.zeulg0ra8x.wasm"
    },
    {
      "hash": "sha256-IzhgOg2uhtcp6IplM5hs0vr5WlY/oHXdtE31RXkM8uw=",
      "url": "_framework/System.ObjectModel.3sfdbrz5no.wasm"
    },
    {
      "hash": "sha256-A5Y8gS9KRjKUcCi+f4jn/oL/Fx0Pj+h7FTA8G5OsXZQ=",
      "url": "_framework/System.Private.CoreLib.5me0cp9sv8.wasm"
    },
    {
      "hash": "sha256-38O4EhkxrGmrLUkv5E7GhQPgITnXTPSnrlJaky4uaIA=",
      "url": "_framework/System.Private.DataContractSerialization.53j6e2w6vg.wasm"
    },
    {
      "hash": "sha256-gnr6E5k1foKqWD6raClOB9H2IpDzsJr7IBx43w7mQHw=",
      "url": "_framework/System.Private.Uri.66ebp4qymo.wasm"
    },
    {
      "hash": "sha256-XQvTu2/Zooc9egF8qum0ksvhVoVxVxGhWVmUn3APIr8=",
      "url": "_framework/System.Private.Xml.Linq.x3hrg73jny.wasm"
    },
    {
      "hash": "sha256-P9bL1K4mYkSYD0IbZRDOd9LCwHLUderVXQqnYqKwvW8=",
      "url": "_framework/System.Private.Xml.lnj1oyjoes.wasm"
    },
    {
      "hash": "sha256-LPOSyZCr6ZrqXrOUEyOlxw0FXfcoiXGk/W9F/OfJGuU=",
      "url": "_framework/System.Reflection.Emit.095h41ndsg.wasm"
    },
    {
      "hash": "sha256-k9/Su2zc22Gin+BCC//lfFrLwCRzDuexBXAf4VG38WA=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.9ddr057k2z.wasm"
    },
    {
      "hash": "sha256-XycPygVcuoE/Rb4ggPFMsFaGa0pr8yqmxcqm7ydkgME=",
      "url": "_framework/System.Reflection.Metadata.7qrsgb5lta.wasm"
    },
    {
      "hash": "sha256-mDJ7Ett9ugYCXWiI7MI4UK9poeHX6O4gO29zMHJGWC0=",
      "url": "_framework/System.Reflection.Primitives.k5la5tzvyd.wasm"
    },
    {
      "hash": "sha256-xq0EdDisxJjHFB3HsOivMO/BRYE76KkWvpTk/niTZ1k=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.m1gwpwsdcd.wasm"
    },
    {
      "hash": "sha256-xN71lt5Z31VqHHhkEXVJr1tttkQkUkNv0HuYQxle0jY=",
      "url": "_framework/System.Runtime.InteropServices.wpehy2d48q.wasm"
    },
    {
      "hash": "sha256-hqc9eutB+AaKcs4Wi0fb7iRSNx8H+PxfYCpPlvhIVSI=",
      "url": "_framework/System.Runtime.Serialization.Xml.mtp7uzdz9m.wasm"
    },
    {
      "hash": "sha256-mljrnErMW7sgBlYw/jKYCesTiBtj/WOreQBdDEZZ9wc=",
      "url": "_framework/System.Runtime.iqu8bg6eb1.wasm"
    },
    {
      "hash": "sha256-z802q+3oYIj5lG7hUa/0K0OgDc9W4HY6h0SsiP8QnmA=",
      "url": "_framework/System.Security.Cryptography.d92vdmp9jw.wasm"
    },
    {
      "hash": "sha256-VXDuab3m70WxTSmzqghNJ4//HQyV6xtXLNaItGbAzeo=",
      "url": "_framework/System.Text.Encodings.Web.3q0sluflbf.wasm"
    },
    {
      "hash": "sha256-6pIvz6ek54qH/Xn3lckNrx0i9g8ejdmj5Rdte5vBqN8=",
      "url": "_framework/System.Text.Json.qf23a9n3dj.wasm"
    },
    {
      "hash": "sha256-d5S+4G23uNWGftgS0JQtaulbggXsFcqL2bUB94zP/Os=",
      "url": "_framework/System.Text.RegularExpressions.l9vlqsltce.wasm"
    },
    {
      "hash": "sha256-raNVb2WpJ2PEpRJAfrrKra2I7w2t8cT8jPBWbJDPAhU=",
      "url": "_framework/System.Threading.z8dhjboai6.wasm"
    },
    {
      "hash": "sha256-LY1Lvrd0k00+ECGnd9WCQG18yq/7IjnXBTB2yZb0eJA=",
      "url": "_framework/System.Xml.ReaderWriter.d0qa7x25k2.wasm"
    },
    {
      "hash": "sha256-z4MGt02mblzVKLe1k2EUyAY7BQRlbNG31oZAsA73pj0=",
      "url": "_framework/System.Xml.XDocument.peelcd60u1.wasm"
    },
    {
      "hash": "sha256-uTsVV+qbYMaSHuOJA+8uehV657M9oR2RmgmRhWAwjyk=",
      "url": "_framework/VisNetwork.Blazor.nwvjgzqmt4.wasm"
    },
    {
      "hash": "sha256-r/mqBI5xUAuldzcb07DF7WuXhQJ2k63jXHovZQwdiOE=",
      "url": "_framework/Webassembly.ttm7bnjb2h.wasm"
    },
    {
      "hash": "sha256-xI+0AYBllEcYNYZeds+rgnJ8l9AF245ZsJTBUmm+7RU=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-XtzVQt8vk5A9LDqJQcUAK4ukFgix9LUQ0R4ojl3LkjU=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-3l90LkivUkLJHuDB7kgCNVyJkWcgbUbL0/05h+92TFY=",
      "url": "_framework/de/Siteswaps.Components.resources.igh3lsoyva.wasm"
    },
    {
      "hash": "sha256-uBdZh6wiGNppib9AKDs+Z/acwKIEO8BwUyhVjq1E8TY=",
      "url": "_framework/de/Siteswaps.Generator.resources.0qhgasudm8.wasm"
    },
    {
      "hash": "sha256-NrChdy9/WV+U6KQWgmf5DcMPesHQyDUCdiD1Z3uBfRo=",
      "url": "_framework/de/Webassembly.resources.ebbejfpksv.wasm"
    },
    {
      "hash": "sha256-2BUjrkXJWjfM6ff4inbqiIvFlDepWPI4bbcpa8keCbs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-5NFVQxWhQxclCd8qh6Azcm6gHVkA3eKEYMo/4A8erLw=",
      "url": "_framework/dotnet.native.g5ul60sb6x.wasm"
    },
    {
      "hash": "sha256-QqWHMtorYt8TklMJJswjnxmzZrcapFqsCR63YLHwxsc=",
      "url": "_framework/dotnet.native.u9ibce76wy.js"
    },
    {
      "hash": "sha256-OGdJqUg/TKNiEWrbtZYHLEgztG9PgriAi1g0ExEKpa0=",
      "url": "_framework/dotnet.runtime.okxdo5zwwj.js"
    },
    {
      "hash": "sha256-5BfhzgOGQRjWj996AOsK8ZD97vgGxXD5Ucoy9h+kBH8=",
      "url": "_framework/icudt.g3en5r9teb.dat"
    },
    {
      "hash": "sha256-zjpktuKD6LcIVJwaS0mKaHY+YZt/gcpIbVjMzTsYacI=",
      "url": "_framework/netstandard.ugjp07djlo.wasm"
    },
    {
      "hash": "sha256-FiwvmTHh6RK0qtUUS2i5dh+OLlMw0UEge01a4o/iEYE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-gCw01Fy6keKtd8KJAutkwfkLjCTKoFwYY5Mc/FxbJyM=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-7+tPbT7PbyQ/jsoE2CnO4GZ6P2EWrzc1WLN/XbQMURg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YD6ZiRS11HFkE5RK4pa+gbg41BfrL4EajQZj9w5mnJA=",
      "url": "images/brand/fav-icon.svg"
    },
    {
      "hash": "sha256-U2muwLEwJsqjmTr6KQoRrr9sb3PCPIW6T6nTLz640Co=",
      "url": "images/brand/passing_zone_logo_all.svg"
    },
    {
      "hash": "sha256-eOdi7ENvIhNj2dWYeCGdYaVwe0N26k2+LHPWF1FrTVU=",
      "url": "images/brand/passing_zone_short_logo.svg"
    },
    {
      "hash": "sha256-tz6SDxMqEsAxYtUYPlLCS9Cnz980buGBmlS2y+9S1n4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-xZxX3HCGv1TLpxU7++crUesr3lmj99urJcP0hjSTGHY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-AqMy6ms/HeOdXV/Q6pY4gNPNQoU0LYrAb0YdM+OkIPA=",
      "url": "pwa-install.js"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-icJjkY+OZgTWDhLfFupwPt4NS/3HEV4Xht0V9Ygu5xU=",
      "url": "sw-registrator.js"
    }
  ]
};
