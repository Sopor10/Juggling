self.assetsManifest = {
  "version": "xhiAwo/8",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-f028uc2y913T5CHs9m4/BRg8QiXMvF5j8UWuf++bHxI=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-QT60B4Wdh8UNI2Jhr/xjAzFoOIwQ+/DyQF/jE5V8jX8=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-xWjcnO7tDmh1ml6yLIhjuYUCEF3sEm2ydPRWBXd/QKw=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-M9oCY0HEHaFPTMj7CLTxNBT7/8jUvcI3/3q27/kphek=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-3qaU5Qf3m+6YvdqrEJG1rVIUkUwltxqk4xKVf1bVNUo=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-6HFYTCZVdz758ysJNkvJ5qBJtqWSi91t4m0D0abdT7E=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-lYiMLG73UrqjeD3Xr0zwkygnPDSAQXeAo1554Yjqjkc=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-7fORUpdOMIYb4HQJqAGQrvAHRvQMA1X/BZ4ovWVEU9Q=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-1JrtdcSOh2YiO6Os6uJCn3wet9p14y0CyxjphGmzHhs=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-tBhm2s/GXqEG5m1yiGgm7pB0SR1bHGJGcXH55NuvGEY=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-wsCFo85Tm++Hir55ycJcA850vMHr3ejT4YmaO32HaNc=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-D5MHqlKaEeTh/QJ/+M3z6aO8XJ3QupwvuQ7HCLby9RQ=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-J8kJYxpBFMrMjHMBSdDlq1lYqyntxOrDZ8AW5FrxH8U=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-j6LH4+AGvB4vGR4H6fZN92328TS2q0CUU93trCPHGsQ=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-8+tvfsaPMeU/HiAO3mw5I1oka/hdvwej7H1OmnsaPwc=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-V+Gj1H7AnqB1o9DdrQRB/lL1+uqWFaJXX/Xi5HVjXe4=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-mscmBJFsTrAe0H/SoknylPnukiQX2yfQ/zSnbR4B75k=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-9DbzoROrVKa1zV8WB3GdITLEOe7mk9ehW44c17IkKbs=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-y6x9nQqkv3mW+Dvmm6Pvh+h0ixHfY0RLzrX6ZlktoG4=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-r5eOcj3VAd8z54w7OBnbnBo+BSO3Ytv18eZ+EPO3O68=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-wQSB1k9zEeItD4LdpTUielZCOAVBlSac1oECeHaLbqI=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-ujA90Bq0F/QSh1ffnw3ev7nNg/1KPW5aulXbd9xKdm0=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-VyhJgq8po3mud6FSP2a9ENksqEZN5jW2kGxLQC+F154=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-xnGQMz4e9qAB/KtsO4t04l/lFsC7gFgd/MgMwxd3q2M=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-tRcVAq9DGc0nyvTuxUpiBTY8PaxnC6deHLSE8Ri1PMg=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-mqyFaPa4MTVKOrUSpP4JItB0rNzYlwbIogKXvtu49xo=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-FAp7hB0EIa/WS12wZmH5E8RZsjcD4/S3IoUiucpNsWQ=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-7D8P4GXfe36mw3yTdB2/hYeOw5I0e2aY0FXv+xW/qcw=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-HYNTnwNf3xj899KPdiKwmD1e5t3XRg9VaQgB1ZOvKeI=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-tzniTDQLy+s3V5n1fk4nFbR0kik10nw+fim7uuxyFcM=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GFU2mt0A9T8j9YMwMQqIUmdziKNDuPppDCn2o37LV2E=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-crZ20WoGvNttYzhC1Gqvh4K9cqRP+AgsORNbvqmWg1o=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-+eSpwuS0Mx0DVjyuFo3DoQXiI+Mp+4I1MtdWSbDcZK4=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-8kZcrnldrkkLW30p/g/K9p+NC6jEXOKGglC2qZfmqDE=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.ulmmvjocnf.bundle.scp.css"
    },
    {
      "hash": "sha256-jvdEwbPP9ySWwm0cTSiOqdIfO15rtDmoxKmiqmFQR/A=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js"
    },
    {
      "hash": "sha256-y7L+XtwoUJtcUnvXGeRLVrLj2uLMTgPyNKJlEJnFbpc=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js.map"
    },
    {
      "hash": "sha256-pCIEjwDATOwa31+YvucoW1WTxT4YiQVDFhw94hu6wx8=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js"
    },
    {
      "hash": "sha256-MTgEQwaemErPPoFSvy9/AvhoR7QaOAVkSgXh+Gs5jmY=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js.map"
    },
    {
      "hash": "sha256-la7lyIF2RfLmzbgQq451BnkJEU/wykMPE6pCn8Po4pI=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js"
    },
    {
      "hash": "sha256-HQWKRYNJ6U0CQ6cjuHiZNYzn9EyBxinvWwT2zctFdWE=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js.map"
    },
    {
      "hash": "sha256-YQqC+x+db2pnQw/gibR4ai58y8WWbVsaiM7Dg/5ZjmQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-YEIKzZHjTFrB0PdPq+MUTCQVa9BXJOk4GoWEv21FNno=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-eM8DTi6b6DvS8NIedSLSGsOM4Y0OGeQUae6fmc0F5HQ=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.map"
    },
    {
      "hash": "sha256-tmxVjsHcxYihEtmXEJz2gJejcMpa2tNP2K5IAMBUwls=",
      "url": "_content/Z.Blazor.Diagrams/Z.Blazor.Diagrams.ezdqu7jd9f.bundle.scp.css"
    },
    {
      "hash": "sha256-s7EEPdhBW2P8sjiCOtar0D9cqNeKSPOwBxqj89twi14=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.css"
    },
    {
      "hash": "sha256-tjG7h09kCbOtLws3pLFB95nmOYxMZl7c8jbGPTarGBc=",
      "url": "_content/Z.Blazor.Diagrams/default.styles.min.css"
    },
    {
      "hash": "sha256-DPGv+cCxzPgtITUub8yFS2/hFYsTZvuV+MX2hT1/C58=",
      "url": "_content/Z.Blazor.Diagrams/script.js"
    },
    {
      "hash": "sha256-LgAw9yB0DF0MNdupxctpNfEU7NoB56YJnh9QpuwRcI8=",
      "url": "_content/Z.Blazor.Diagrams/script.min.js"
    },
    {
      "hash": "sha256-EntOrNcHrVMAVfWpFhvF7p3Dlm2ljQBZcZQoK9/ENig=",
      "url": "_content/Z.Blazor.Diagrams/style.css"
    },
    {
      "hash": "sha256-UKzIp+VqUElrrWqYXITbK2mVVp6d5hx2LP+pnMfozLA=",
      "url": "_content/Z.Blazor.Diagrams/style.min.css"
    },
    {
      "hash": "sha256-qbG0STeTRSjScVJ9SBP9y6zl4YpUsBt317lGajCmB8Q=",
      "url": "_framework/AutomaticGraphLayout.Drawing.rfmvbsf468.wasm"
    },
    {
      "hash": "sha256-G5FHc2TipvCo7po6ZTAuX5MXPHgkB4E+CcQNvwSgIvo=",
      "url": "_framework/AutomaticGraphLayout.xhitsgdb3e.wasm"
    },
    {
      "hash": "sha256-W5jAEh1BJpID2KOjfMO9vOPVsdrYaro2ijjK6RlgFTc=",
      "url": "_framework/Blazor.Diagrams.Core.z625myqj9k.wasm"
    },
    {
      "hash": "sha256-zGXooQdLm05nUxu/a1HW0N8h1onvcACfrPx+R+fpsFI=",
      "url": "_framework/Blazor.Diagrams.ckfoh8zkyc.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-4Oeo8/KDTym/CblLRv6nEV9S1CDpm+rU4UjbGfjgDyM=",
      "url": "_framework/DotNetGraph.8ylozkoln5.wasm"
    },
    {
      "hash": "sha256-UUDdQpFUY9H2fvZxvGhWLfifbi0vztUkLr14L1HLE9U=",
      "url": "_framework/ExCSS.vo340561u5.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-EBslmZvfsvpTBdvOmv3rEOEg7Pc+HAABf7+3bJOokfc=",
      "url": "_framework/Fluxor.Blazor.Web.cl1oh36s39.wasm"
    },
    {
      "hash": "sha256-APyVBDq93FhhHXOm8kB0Guo/oYk+VcKmObk/+HK6CAI=",
      "url": "_framework/Fluxor.spaznd1495.wasm"
    },
    {
      "hash": "sha256-ardo2j/gxqPYJyrRDnTGcgWeJKq4mcnytO6Ip5aiAGU=",
      "url": "_framework/Microsoft.AspNetCore.Components.2tokma1x5s.wasm"
    },
    {
      "hash": "sha256-oCteveJEvmv3N3UP8n2e/nHVgmc++GDANmRSc0XzMb0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.0gulbz7qk1.wasm"
    },
    {
      "hash": "sha256-5wGdgl+PsRrwn5UMe13MM02yn5C87hkEGmNod4ultYs=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.1m82m8v255.wasm"
    },
    {
      "hash": "sha256-rEEAKwh+sw8szjmkdPsne3J/1kYWauEoeiST0tzm14s=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.sw5z1m8ccl.wasm"
    },
    {
      "hash": "sha256-K9tHLia56Z7fg2zsIfiJA1wgCb8MMVkM8X3CSXQ+yf0=",
      "url": "_framework/Microsoft.CSharp.lgsnpvm9xw.wasm"
    },
    {
      "hash": "sha256-VcpjgiVQGVhlsFFL+GzVh/tl1ycxkiTzhb3zMyKI0Yg=",
      "url": "_framework/Microsoft.CodeAnalysis.CSharp.p31rc0goqn.wasm"
    },
    {
      "hash": "sha256-UrCKIA7ySpcVuJFCzqzHYPujBSMtSeyQCqfCmliSttY=",
      "url": "_framework/Microsoft.CodeAnalysis.ux1aktmc0y.wasm"
    },
    {
      "hash": "sha256-O/18yK/3Pj3wG2PLVJBN283TmIjoQ5k/JAdb5d/O+P8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.h19gpugiy5.wasm"
    },
    {
      "hash": "sha256-7Wv00KMrZAHb5sX5acrBZ6dNoPfDuaNWlT69VNMGt1g=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.n3x20s9cxz.wasm"
    },
    {
      "hash": "sha256-XhpSYR8F8A+kKAi/mojMfR/OreGPs3bc2GIu2PE9098=",
      "url": "_framework/Microsoft.Extensions.Configuration.icatoxhjsq.wasm"
    },
    {
      "hash": "sha256-pA4DH4S59H7Bk/d+U0x8vOL+PsUB+5iRJMRSokywMr8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.s8elee7mjf.wasm"
    },
    {
      "hash": "sha256-DnnRKy8PZBHtfhziO6DfIwoozcHbfQiGwcXDh5nRSZc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.qeizni4cln.wasm"
    },
    {
      "hash": "sha256-WijGiJNaX6qnL+mrvvm4JS6cejxOl1gaW3tRxlPAMJA=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.qrkymho8xv.wasm"
    },
    {
      "hash": "sha256-TusUfPjSxh0GzZINX/Xk9afg45BQccmXJOyvulCHlU4=",
      "url": "_framework/Microsoft.Extensions.Logging.e47xhy91y6.wasm"
    },
    {
      "hash": "sha256-x1bUj8WeS5AKM4ASKXjYmCQkVeKXXBC+l7/kfZqYiGs=",
      "url": "_framework/Microsoft.Extensions.Options.f2jp6lfc0r.wasm"
    },
    {
      "hash": "sha256-6cQKFBXogCgICQbWptUlzgW+xOHIWbUMRjFxztqytdA=",
      "url": "_framework/Microsoft.Extensions.Primitives.9kx4ehp8td.wasm"
    },
    {
      "hash": "sha256-NNwR0xu2wKvvEIZnSUwKht+/0RJ9ziHW01M66VViIkI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.s0bw0921jm.wasm"
    },
    {
      "hash": "sha256-2lYr+P0dFjQSAt/g6ED+ym+OuheSxSAdW8yLlY5XHVE=",
      "url": "_framework/Microsoft.JSInterop.ii0tfcd38k.wasm"
    },
    {
      "hash": "sha256-30xO+FUzOa+7erb3K4Vs4Mw4xddwMQwXmalKInZSXEQ=",
      "url": "_framework/Microsoft.Win32.Primitives.ln9p2dayjh.wasm"
    },
    {
      "hash": "sha256-wSkk4E15aam2FWzUH/j4/+YRobnqZkZFegdWJlLjDxo=",
      "url": "_framework/Microsoft.Win32.SystemEvents.zne00j2dyy.wasm"
    },
    {
      "hash": "sha256-l2qEfPM/BjYyiblhUW+zUgDUT7vciCSwbC6Vj2Klbeo=",
      "url": "_framework/MoreLinq.zdi2h46g68.wasm"
    },
    {
      "hash": "sha256-P8cElbADu+wOgLep4wqFufIm1wsnC6mNj/6ZZcdtJ/4=",
      "url": "_framework/Radzen.Blazor.btqax8k0l2.wasm"
    },
    {
      "hash": "sha256-kombBzI9lRm0YPtXO8o+Q+9lMPFNgqBn6pFqyhvxzAA=",
      "url": "_framework/Shared.uwhj9riuue.wasm"
    },
    {
      "hash": "sha256-7i11fyEkZ9aIkGmM3hVk48lNebcri7YumMRBhyB6LAM=",
      "url": "_framework/Siteswap.Details.ep8o0simv6.wasm"
    },
    {
      "hash": "sha256-Fw8EMyAdyjwhR3iHDWYv4o5Vpz3SweaQXKP8fWtMj6M=",
      "url": "_framework/Siteswaps.Components.n0826hdwkx.wasm"
    },
    {
      "hash": "sha256-AgbQAhrO1XQgDWhhvwjwsq9Pfq90eAdPHMPxOWhXxso=",
      "url": "_framework/Siteswaps.Generator.y45gw69ce4.wasm"
    },
    {
      "hash": "sha256-azDM9i9So5Tcn2T/kuO6UrAUoeBnjYrEnvVNvp+aaGI=",
      "url": "_framework/Siteswaps.Visualization.t230oq0k7l.wasm"
    },
    {
      "hash": "sha256-eV3F6NH5/nfLcQMQAloe6sGD4/VtH983nxzPYykRU30=",
      "url": "_framework/SkiaSharp.Views.Blazor.74nar1fiep.wasm"
    },
    {
      "hash": "sha256-uR6oKkgUwjDk1/tUffARfYBE2e0hbro7wn7QpNvF3lY=",
      "url": "_framework/SkiaSharp.j5guk4pyiy.wasm"
    },
    {
      "hash": "sha256-k46YDqsBQ84522ERaK6jUsIe7mlIJ4lIxsWnckhxyvw=",
      "url": "_framework/Svg.3wlfysmzyb.wasm"
    },
    {
      "hash": "sha256-mnGtUMBNvStqULzvqZhBxCYgBKXWHcsZGJ33qucDawQ=",
      "url": "_framework/SvgPathProperties.ebwgyay2jc.wasm"
    },
    {
      "hash": "sha256-5MvaAA6gkBs6LKxhGykmQcYhWwA7gWETFDSPz6lEbvI=",
      "url": "_framework/System.Collections.8nqon2rb7v.wasm"
    },
    {
      "hash": "sha256-9Qg/oLeqsjdrRbZkJ0NranqQHCofcQ9LzJEP7UDzFcA=",
      "url": "_framework/System.Collections.Concurrent.5wv6qyw86f.wasm"
    },
    {
      "hash": "sha256-DHrtLq+d4H2mVKSdadWaYu+BVeui+g77j1+iOVaFy78=",
      "url": "_framework/System.Collections.Immutable.o33186a1k7.wasm"
    },
    {
      "hash": "sha256-cxuuGo+l1J65KWkCrxxppA0uVQf5EZpW0Pph8SDbVVs=",
      "url": "_framework/System.Collections.NonGeneric.52obipcafc.wasm"
    },
    {
      "hash": "sha256-ZPlwQoYzG01AL8439YV0EYWRcbJYn5l2GEHOJ5SxRd8=",
      "url": "_framework/System.Collections.Specialized.4c36f9fubl.wasm"
    },
    {
      "hash": "sha256-bV3jqp7kGGqCmLalY8QTaBnbfpJhg4BGMpN/NcJnV7Y=",
      "url": "_framework/System.ComponentModel.Annotations.7jeg9j2sr2.wasm"
    },
    {
      "hash": "sha256-V4f+vaHCemO1h5aB4VRdSeR1uz5JohS1V/Vt62Hv1Ow=",
      "url": "_framework/System.ComponentModel.Primitives.1qctb65mmm.wasm"
    },
    {
      "hash": "sha256-hz4vLNkrEZHZsqKPHD/kcbgmayJg5kuIVzH/gYfKF+E=",
      "url": "_framework/System.ComponentModel.TypeConverter.1u8f3dziv4.wasm"
    },
    {
      "hash": "sha256-TIyLLWX8nKGeXHzU/UjYj14fM1mTuFwTHJn4OgA5OFc=",
      "url": "_framework/System.ComponentModel.onqvfbarx0.wasm"
    },
    {
      "hash": "sha256-UwAdQYsQTB3HFS/uI4wcyTbxk4MQe8KAqtd0hM2E8n8=",
      "url": "_framework/System.Console.phj8fbb33t.wasm"
    },
    {
      "hash": "sha256-cZpqW77a/WZBnUmE/DH3NB6DnEZWPH+/+gwdbAIJX18=",
      "url": "_framework/System.Core.5becv67885.wasm"
    },
    {
      "hash": "sha256-u2Fz1rnlnemBqO3kouLMsTJDsbZH0CD7bHyCiUKxQR0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.lkumuns4o8.wasm"
    },
    {
      "hash": "sha256-nxd4b8ENf3EY0dniRV9Tdkl0R2i8BxmatYpJg51oxgM=",
      "url": "_framework/System.Diagnostics.Process.vgca2m6o77.wasm"
    },
    {
      "hash": "sha256-6wxjQD/5CYGM/T0M3BUxPzMFlgvo3ur/DtMJqkLpqiY=",
      "url": "_framework/System.Diagnostics.StackTrace.x9n1fq3i51.wasm"
    },
    {
      "hash": "sha256-PS3LZpsiLEBs/ZnMlK853BGdzr7zzYWDnrDICpqbkU8=",
      "url": "_framework/System.Diagnostics.TraceSource.xfwgta80xt.wasm"
    },
    {
      "hash": "sha256-BkUQ2DshRREjYIWGmtuvWHXXtBWmMQMgqh5KRQignEg=",
      "url": "_framework/System.Diagnostics.Tracing.avezv8z980.wasm"
    },
    {
      "hash": "sha256-/XZkesye3Ykec1QYcxq28VRhC1+GxtfJ2LyI4EMXwIU=",
      "url": "_framework/System.Drawing.Common.twylf961ot.wasm"
    },
    {
      "hash": "sha256-HltABqEtTXefzafuSm0NHt+39uaC+Hyo3JlrmcqfwPg=",
      "url": "_framework/System.Drawing.Primitives.24p3v5hhfj.wasm"
    },
    {
      "hash": "sha256-T80AuWk5oNch/RPOfQ2j1jHHUNTHahti2HDKbJSBiYU=",
      "url": "_framework/System.Drawing.vs4w9hyl7j.wasm"
    },
    {
      "hash": "sha256-W+agpgrnztf/F4I++CPfKNKBbVMdCy5mty/UCTg3nkQ=",
      "url": "_framework/System.Globalization.9zze0ba3e4.wasm"
    },
    {
      "hash": "sha256-HJRD5aNVwqfhhhAetr3/leD5cZ0MajOznu8pTJkxUbQ=",
      "url": "_framework/System.IO.Compression.cmohlwqmgs.wasm"
    },
    {
      "hash": "sha256-45pq039VLO5j05u+F5ROszsMC6fwWbRQ3ZeQYalP8WI=",
      "url": "_framework/System.IO.MemoryMappedFiles.7z33wpo7lm.wasm"
    },
    {
      "hash": "sha256-178PvlfqqHexwMa+sha7jkzLVkO2mDIOyznyHXwFjeI=",
      "url": "_framework/System.IO.Pipelines.xy0xpl5xng.wasm"
    },
    {
      "hash": "sha256-CH9HlSymBG/b7dH7jcPxKNmsHaT3OBrjgrUGQqTWkBo=",
      "url": "_framework/System.Linq.Async.k9im717kse.wasm"
    },
    {
      "hash": "sha256-8gX6kR2XBWCzxTL59zM8Ixmpj6nrpv6CfNXObAHXlq0=",
      "url": "_framework/System.Linq.Dynamic.Core.6ykcdy14yj.wasm"
    },
    {
      "hash": "sha256-/9QylUM/xAIYEA/F0qVOc0TftL0kzcKVuUmspQOH/fI=",
      "url": "_framework/System.Linq.Expressions.j7z7j9vqlv.wasm"
    },
    {
      "hash": "sha256-FE2vNnEbBehhVQ/IrXO03kZE/j7cl2/ofOAnPKTSAnA=",
      "url": "_framework/System.Linq.Queryable.8b0my0wlrk.wasm"
    },
    {
      "hash": "sha256-IrTUTS6vFdLMFjMeh/gtBYQE9t0EdMGIDepRdp+wQZs=",
      "url": "_framework/System.Linq.if3m9uz2qs.wasm"
    },
    {
      "hash": "sha256-1yDkboRHJBq8dWLHRP0QJaYN0C/onRVoJq/+eG6zoMU=",
      "url": "_framework/System.Memory.pcavpktt6a.wasm"
    },
    {
      "hash": "sha256-CllLysfQGdyB6QTeLOqelZikIJiXCZgo3uHn/Ru1jH8=",
      "url": "_framework/System.Net.Http.e6lvqsu8cm.wasm"
    },
    {
      "hash": "sha256-jnSWuf5Fy5z+FXyicdP7crEW2t7uf5s4+qcEP273HHs=",
      "url": "_framework/System.Net.Primitives.el7k0yi1gl.wasm"
    },
    {
      "hash": "sha256-5Ap3UiZ6f1fxwUP8iCyNAB3nyRaTKccdL9UX7fbp8NY=",
      "url": "_framework/System.Numerics.Vectors.o98xlqbnxd.wasm"
    },
    {
      "hash": "sha256-42aFOKoib4isAcC5GRsFHYR0anUnE4StO+ZCIuk2/7o=",
      "url": "_framework/System.ObjectModel.lyo7r1w6bt.wasm"
    },
    {
      "hash": "sha256-W68eK9GOUIIrkF/BvatzyHVTsqieIm8K8ki5vVtrTSc=",
      "url": "_framework/System.Private.CoreLib.vfau7i7zi2.wasm"
    },
    {
      "hash": "sha256-CgaGxmpmOU3rbZJcAuQTdMK0Jqf8l6RuxlzrRQIdZFs=",
      "url": "_framework/System.Private.DataContractSerialization.uqjcvb4le7.wasm"
    },
    {
      "hash": "sha256-WOc5DgtfY0elvCpCClz4T8hiunC0oJ/TbPHt+1fz5vc=",
      "url": "_framework/System.Private.Uri.svrmqqap4i.wasm"
    },
    {
      "hash": "sha256-4/b+FBH0b4ETvWXyezsugE30QQ7TqSdXqwW2JnHMdjw=",
      "url": "_framework/System.Private.Windows.Core.jw9rk6igcf.wasm"
    },
    {
      "hash": "sha256-I2nVwYw6TQ7OLWlGiV9zpPTjwAAIWC+JGftMcLzH6w0=",
      "url": "_framework/System.Private.Xml.Linq.1rho7go0am.wasm"
    },
    {
      "hash": "sha256-h2gPL3uJix0tg6jb4dVv08b9nOPwd6g1uOQutMfqklA=",
      "url": "_framework/System.Private.Xml.fi76x3duqt.wasm"
    },
    {
      "hash": "sha256-nuWlc/sXNn7IpEiBPYY0QNUJcOoLrsqY6EQgi+6DU4c=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.672ta06jod.wasm"
    },
    {
      "hash": "sha256-4DTVxdGdFWgIhuOjGzaHoSBHaijuDJQs21sK7JTvB3Q=",
      "url": "_framework/System.Reflection.Emit.c9tn5jfoyg.wasm"
    },
    {
      "hash": "sha256-vMYXA24BJAB0qD/E9LaCTljIQbxiaHobEQylKOSOq+0=",
      "url": "_framework/System.Reflection.Metadata.0v6s9fvu3z.wasm"
    },
    {
      "hash": "sha256-ObQo4St0v13/9qco9s4bodCKC3b8AVTtFalf8eeMC9U=",
      "url": "_framework/System.Reflection.Primitives.vmdzcc6a6r.wasm"
    },
    {
      "hash": "sha256-fhN1VgGEJpBfqaKMiyIj7xesCD1lNiZXO8rVDv9J+Bs=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.2rrgnrarl0.wasm"
    },
    {
      "hash": "sha256-u8s3VlPAusrFaPM6WM4cuxHnwkjgFEgwumKcLQh6MLo=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.hxx67n63ih.wasm"
    },
    {
      "hash": "sha256-SmhJ1SBA0QawyFKt6yl/acqk6jLBK53zwQFfls4bAW4=",
      "url": "_framework/System.Runtime.InteropServices.mk9dueprat.wasm"
    },
    {
      "hash": "sha256-fg5ZJ75d93EEIvaYtLA/eXZQHIbvVmyL99L28WcDHfk=",
      "url": "_framework/System.Runtime.Loader.ucza5qb73o.wasm"
    },
    {
      "hash": "sha256-TKh2bNYhjy57Dwfrm8dcKpiOrskx0h5c/5dWg/c2qp4=",
      "url": "_framework/System.Runtime.Numerics.ot2crhzokj.wasm"
    },
    {
      "hash": "sha256-hUHT95Ns4gDq3hzDZe9wIoKsAjvLth0Pl8+0YnoF6yg=",
      "url": "_framework/System.Runtime.Serialization.Formatters.vfcy7x4a35.wasm"
    },
    {
      "hash": "sha256-ueGOSaMIDyZl81noc7psZfm0HJtZ96UhI98RZr/DmSM=",
      "url": "_framework/System.Runtime.Serialization.Primitives.hefn0lssuf.wasm"
    },
    {
      "hash": "sha256-3mkpwx6K8kiG5vRedjmOZ5Upg2bAZG2/V994752jtxk=",
      "url": "_framework/System.Runtime.m7xg2m3spu.wasm"
    },
    {
      "hash": "sha256-ZpvWhG7haUE1po3+HdRGLwJzu7S+7952xaxDAzuIj3k=",
      "url": "_framework/System.Security.Cryptography.ihf87tiazu.wasm"
    },
    {
      "hash": "sha256-lNLrNFPAyjdMCcSb3fKiaFxJngRRsgksWHHLKjIOh80=",
      "url": "_framework/System.Text.Encoding.CodePages.wt2pklfc17.wasm"
    },
    {
      "hash": "sha256-DFa1OSg3/7NF6ypJsiqIgB8abJeuLvEAjyuQNsbukjc=",
      "url": "_framework/System.Text.Encoding.Extensions.g7chadq38d.wasm"
    },
    {
      "hash": "sha256-oHU/Sh7pSsGocJiqskEB6dC0t/W6cfvu0emRqJk6X7U=",
      "url": "_framework/System.Text.Encodings.Web.86025yzcvr.wasm"
    },
    {
      "hash": "sha256-QVaRvTf9OrcnGKRt0nQFhtA5dSLVbH1rwPJCvVsoslY=",
      "url": "_framework/System.Text.Json.5rbrqutyje.wasm"
    },
    {
      "hash": "sha256-az0CXL4Twepvk92Eara0+RGmy6vhqw36B/ryYNxGve8=",
      "url": "_framework/System.Text.RegularExpressions.79mzq6f75x.wasm"
    },
    {
      "hash": "sha256-0iJx+4PIkDSIzsvl2jOGMU9AtYr+UuvRPfrIM9cN9r0=",
      "url": "_framework/System.Threading.2vliybj0rr.wasm"
    },
    {
      "hash": "sha256-XJpRhu0fFlSfKfTZrFcYiIissbuz/HulRflLUbMd1zU=",
      "url": "_framework/System.Threading.Tasks.Parallel.o7tvcpresk.wasm"
    },
    {
      "hash": "sha256-iWrTicSFDQFCpuITuQIFwpcBmz/kJLreO2O7wNwhLpw=",
      "url": "_framework/System.Threading.Thread.dfuudulfvg.wasm"
    },
    {
      "hash": "sha256-OzYRmpQt3FKcyMgg1CWybmSCT9PALweBA3YehuuK5cM=",
      "url": "_framework/System.Threading.ThreadPool.t225cdxdzw.wasm"
    },
    {
      "hash": "sha256-r1Rvjzy1eOgrGTxrnCatjyOh+1PInPjVicvotDjF1Y4=",
      "url": "_framework/System.Web.HttpUtility.3v5gnv41mf.wasm"
    },
    {
      "hash": "sha256-akuvaefMEZkY+xfX8AkcFNb1F9Qu3cRoTWvxlR6Vnw4=",
      "url": "_framework/System.Xml.Linq.yiwjknpdq4.wasm"
    },
    {
      "hash": "sha256-EqiQUKy3iQEakxZqPxD4DS9XXyLjQWnPk5yPS+IzEFc=",
      "url": "_framework/System.Xml.ReaderWriter.283rv80rxf.wasm"
    },
    {
      "hash": "sha256-3MK6pckn4OvSwdspLMxg2E/mglzksLEPpB93pwD8ow8=",
      "url": "_framework/System.Xml.XDocument.sauz905bp5.wasm"
    },
    {
      "hash": "sha256-4pxs988ieiulDcyRvU0mMGCO6alvxzQpjs8E4TZFRRI=",
      "url": "_framework/System.Xml.XPath.XDocument.yrzgmxlc9l.wasm"
    },
    {
      "hash": "sha256-YkFFFBkhWPJ9NX+mNSyGmlb6hmjtja4JNTnNi66JSGU=",
      "url": "_framework/System.icunsnzrqy.wasm"
    },
    {
      "hash": "sha256-GqbYZLBITO3dqqsJ4DPwOeElXCpYNCbHhlrTpj+c2wY=",
      "url": "_framework/TextCopy.m05mv6487u.wasm"
    },
    {
      "hash": "sha256-ULsvyv7nl6doDq/7V6xScA4P8bEScbsCcPFBlPnaS7Y=",
      "url": "_framework/VisNetwork.Blazor.4fraq2v2tj.wasm"
    },
    {
      "hash": "sha256-IDer07QzMe2WvxAwav+RbiQELyw0pzXWLxmbA9fYATk=",
      "url": "_framework/Webassembly.ws9tuxneal.wasm"
    },
    {
      "hash": "sha256-ECsatq+QjwmNl1G5ZmQSxerkkaczPSfgnqZ4xrkhwRg=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-NyqJWAQffi5s2B7+jr2gd4NGYR1uGQU3ugVMslD15Co=",
      "url": "_framework/cs/Microsoft.CodeAnalysis.CSharp.resources.vylskahzzd.wasm"
    },
    {
      "hash": "sha256-L3bKdVeK4S0Y6aWqPts668EX9n2zkOL6TqgUzlASxv8=",
      "url": "_framework/cs/Microsoft.CodeAnalysis.resources.vceumzhqml.wasm"
    },
    {
      "hash": "sha256-aoMjXlggVRObU8Fi12eR7M6hky7HTvuodgMZqURQh74=",
      "url": "_framework/de/Microsoft.CodeAnalysis.CSharp.resources.itrvy704bc.wasm"
    },
    {
      "hash": "sha256-7X63txji8CRVNINAmel5bUHinrFp3g7ieHLz2sM9x4I=",
      "url": "_framework/de/Microsoft.CodeAnalysis.resources.to7s51asb6.wasm"
    },
    {
      "hash": "sha256-XoL4KXKUiNydxBQ0q7b/0gDsgsuq8oac0YMVUnGkfRc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-tehX1ATpwp2kVcop5RcxmQ0rj+CPxoRPbW5f8HnQwe0=",
      "url": "_framework/dotnet.native.7dzhi6auol.wasm"
    },
    {
      "hash": "sha256-wDMUuMrCJikl0HzDzeYdNhCiJRmf3s1+V8yxaGuCYYI=",
      "url": "_framework/dotnet.native.8a9n5oy4bg.js"
    },
    {
      "hash": "sha256-ilTXrnUF4HKbIAFVIYlRmX3ryKNZpGUObkWMF0n2Kcg=",
      "url": "_framework/dotnet.runtime.qrl1fuqt3c.js"
    },
    {
      "hash": "sha256-NXEmu0iSMse7rCCuGQ37z1EXcx43ZgSZvs2x/xYEjfM=",
      "url": "_framework/es/Microsoft.CodeAnalysis.CSharp.resources.ff6petsiqz.wasm"
    },
    {
      "hash": "sha256-Uh9Oeki14vqSrSMueTb++lYjt1j7RjWJhBExSX/2phY=",
      "url": "_framework/es/Microsoft.CodeAnalysis.resources.me6h21w7u9.wasm"
    },
    {
      "hash": "sha256-l+BbxzrrOid2ArJyD5uSb3KoeUetmb4/Pkh6fIdYctE=",
      "url": "_framework/fr/Microsoft.CodeAnalysis.CSharp.resources.3xb5pvc7h5.wasm"
    },
    {
      "hash": "sha256-R/p6rSzNfHwN9vIXl20l+HdlxjDgJH02ujXITSaAbdw=",
      "url": "_framework/fr/Microsoft.CodeAnalysis.resources.j933nglr8j.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-VWB38g4CaKU00JtNZr5LfBmrfWCTLPagpowJXgNOq4E=",
      "url": "_framework/it/Microsoft.CodeAnalysis.CSharp.resources.xlsme6gyj6.wasm"
    },
    {
      "hash": "sha256-oHeY9/V1n4CJRGTiLT9rJfBAn5S8YHqysdxSeh0MyVY=",
      "url": "_framework/it/Microsoft.CodeAnalysis.resources.g83krw0vfe.wasm"
    },
    {
      "hash": "sha256-3BAXPNBL6akRlFzhYSFgye4I9p+Mb+MBioYO2/SRTOY=",
      "url": "_framework/ja/Microsoft.CodeAnalysis.CSharp.resources.skjrh1aqwb.wasm"
    },
    {
      "hash": "sha256-Cc4fdG4NwA+RTo9DT7F9Sbhv0kpsKZ3S7Nc5RT3rasg=",
      "url": "_framework/ja/Microsoft.CodeAnalysis.resources.7swctlh1au.wasm"
    },
    {
      "hash": "sha256-MPj6p69oheP7XsyvKgZIXp1vyRNT4X4yxSmdUDwFZ0A=",
      "url": "_framework/ko/Microsoft.CodeAnalysis.CSharp.resources.0sm6bhok3u.wasm"
    },
    {
      "hash": "sha256-uWFHPvAgn8I3ZZzG62SJxDqim5XJ1Nl00+hkjYQ7X2c=",
      "url": "_framework/ko/Microsoft.CodeAnalysis.resources.989426cy45.wasm"
    },
    {
      "hash": "sha256-8o4oTJwVHt0gAj66GJN2vtOHlrM7Xkhh70rHvd7Z5a0=",
      "url": "_framework/netstandard.6z0kly9njd.wasm"
    },
    {
      "hash": "sha256-sxwDwwrPt5JfmJ1O/dyIUtEGQ7TAatqnCZ3xpwX7Txk=",
      "url": "_framework/pl/Microsoft.CodeAnalysis.CSharp.resources.zorauptvam.wasm"
    },
    {
      "hash": "sha256-E9DhkvWStAmI/pIFbJuoZ7IymnFENRUtmJxMHJmxSx0=",
      "url": "_framework/pl/Microsoft.CodeAnalysis.resources.1bqfl6r9eh.wasm"
    },
    {
      "hash": "sha256-AwBtAuX3y8JuLD66WMgOkw3SsJ2gZmZ7tgQhjPSdgos=",
      "url": "_framework/pt-BR/Microsoft.CodeAnalysis.CSharp.resources.nnv74sjfz0.wasm"
    },
    {
      "hash": "sha256-p2wHOUhg+WLHoaTyB1+Q5wAA7f8EfKp6bH2AQPrY6jY=",
      "url": "_framework/pt-BR/Microsoft.CodeAnalysis.resources.1m4c920cpk.wasm"
    },
    {
      "hash": "sha256-gyvuLjq56xJ52UJ4PYF5kNrg/0o7U+fwNd7Y/ymQ6KA=",
      "url": "_framework/ru/Microsoft.CodeAnalysis.CSharp.resources.73tx2uqww1.wasm"
    },
    {
      "hash": "sha256-+7mZeRjGc2M6hJ1qiMRJ8OEm5UyZWf3qPw/Z0sZUQcc=",
      "url": "_framework/ru/Microsoft.CodeAnalysis.resources.jasfdca8tn.wasm"
    },
    {
      "hash": "sha256-OowbIL5ac+p0DilPW+iu1yXTSqqZcWbh7HEgwNXVn4o=",
      "url": "_framework/tr/Microsoft.CodeAnalysis.CSharp.resources.6pvz9eylvv.wasm"
    },
    {
      "hash": "sha256-gqd81F4jNypiqxlOrU8EwRHawcFDnr4kBcOs+jTsGpg=",
      "url": "_framework/tr/Microsoft.CodeAnalysis.resources.6n8brj49y6.wasm"
    },
    {
      "hash": "sha256-blb8qJxNtyTL5n3Q0mtUkbE56uV98Eo9aj8RQt5a6Jc=",
      "url": "_framework/zh-Hans/Microsoft.CodeAnalysis.CSharp.resources.ehmv21sa71.wasm"
    },
    {
      "hash": "sha256-ztaU1ohgQYAeC1Q3IltD5DYmkXv0Lgz9mQBsUssQ2a4=",
      "url": "_framework/zh-Hans/Microsoft.CodeAnalysis.resources.m2f69v8d2f.wasm"
    },
    {
      "hash": "sha256-IMqU+o7J2aQWaVQIPaCReB1GsG6WoH4fYK2Djri4ilA=",
      "url": "_framework/zh-Hant/Microsoft.CodeAnalysis.CSharp.resources.g0tdy5e2jj.wasm"
    },
    {
      "hash": "sha256-zFLRkAZCZbhRpwNfnTOr862AwXfo7UhDnhJH7ZfKB8w=",
      "url": "_framework/zh-Hant/Microsoft.CodeAnalysis.resources.oxl7kl6ueq.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
