self.assetsManifest = {
  "version": "0LpEOYGZ",
  "assets": [
    {
      "hash": "sha256-PYyGyRDnwKfZLzf90UBJX8optr4eAwO5FV+CtzpuU5E=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-GUAbZb3n9+xm+K5fTzwZbjTFfgyKifCQ87ZpqbE1v7I=",
      "url": "Webassembly.styles.css"
    },
    {
      "hash": "sha256-Zj7sF25g49ZYgpgxmvvLs4xs7wWCla5f2cWoqW+r6/4=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-kYE8x9Fxto4kAa5rZOX7UoWbO/ezKh+gt2g0jSZWNtI=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-9t6EXWYnl/QKcjuT8/+OKfHA1pouuLwhKIYsHnsB1tA=",
      "url": "_content/Radzen.Blazor/css/components/_qrcode.scss"
    },
    {
      "hash": "sha256-YVOvEQpafIYbQ1C1wHpTmvQmix/J7IIM/s6bR15xzeY=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-gkui+AFMoSJ/CZpSzxAiT7olmWjNpYUjIBWOJI6wuMc=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-twSJ5g1IeBzpsxmHR3FNu7ItID6H3XbU1HZ/qJSWRFg=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-9ZPFj82lGG387S9bKduzkwVEZO4fdwo027aodi4LNVo=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-YmGG8kk6j+Dwd+oz9V/6BjCSaUsYklsZsy/ikfZnS68=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-vty/la3MXjb8+NihPQEMF9ijro+NPHFHsJOXoK4Mh28=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-4tmVJXuCBk2/QRsIy7dLf1bN3X2OolRLRGYmKeVi0zk=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-teD7Xp9KoEEbG4QaoWzAqntOrbHPWNULM3dsFVROfkE=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-F6ZGl/o1vaNUJUGMCDbYnYCswD583tEqbu+LSy+/0ho=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-4ZMduw+tDam6nGA8fEuuPFi23JFfcM2y2EDh3/5rKAw=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-VId/LOwa/fiUtA67BmPAvXp5phlsSyykd0Lw/Fc2DAM=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-h2e1Huh88KqwXtlPMXfdyz7KuPmGwRQ4mlMmmDB0ttM=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-fzXK/2BQ8C/lABKJC6dsV+cXmFHprEg2ICoPIqt6r2E=",
      "url": "_content/Radzen.Blazor/css/math.css"
    },
    {
      "hash": "sha256-wJ3Lb9vVJtckdL66r8uyArmsd8F8WDFB2tVJR17TJ/M=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-FC48ZdritMsdzEs4DD6VfaM2i2mQenOOvjOe4CKSJCU=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-tkEpeRJs4pAczrvwgj5NEuwRXunsC9lJYbx/prqb+IM=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-BR7Qlv0MDGLSKU4dbtBeCRDWQRHGoA4xs+85cVsXI2k=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-3zReFg9ZAhiu8VOEA3fk2vRjYcKthwM+mh8/Xs8S/tw=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-ioPJnBiXjLVLzXAmSiBh6j7e9/Z+OtdZ4+++6sqTfmY=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-6/nVMSZPj5TQ58+geQrVD21/1z5mCK1ktWtneQZzvaY=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-U9HViKHLkZ5sWC6DzhKOGlAyxEQWJKRSkwzvTPi63/A=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-6qnVYH1VESGY6mBfq77LXQovhwNHH7q5jTJ1VGGCurk=",
      "url": "_content/Siteswaps.Components/Siteswaps.Components.2dgtuou56t.bundle.scp.css"
    },
    {
      "hash": "sha256-0U16NrdYdU3LYn4kWYb8+VAUI5WfKWPP2Drc/M0m+0c=",
      "url": "_content/Siteswaps.Generator/Siteswaps.Generator.zjil1c9e62.bundle.scp.css"
    },
    {
      "hash": "sha256-gO5JsY5NdJMftloL68eqbbG4e51Keuq6HkKkDK5Lemc=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js"
    },
    {
      "hash": "sha256-o27cqfyP6SVlnra5XG0WBiEvteJKgRkCmig25IbGs3o=",
      "url": "_content/VisNetwork.Blazor/BlazorVisNetwork.js.LICENSE.txt"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Ik5uplNefps/fy9tENejA29huXb6uxnHtCxJvzAJiWo=",
      "url": "_framework/ExhaustiveMatching.uxanfigfr3.wasm"
    },
    {
      "hash": "sha256-f0uhXaNzSHCguW7IErTRjeiGQXPWEWl5p/eehMZkDdc=",
      "url": "_framework/Fluxor.9yjucuf12h.wasm"
    },
    {
      "hash": "sha256-DBC32gXCmb31ELcLWyN0VaYPespDZiNUhIL276D1X7Q=",
      "url": "_framework/Fluxor.Blazor.Web.4opwue5a6j.wasm"
    },
    {
      "hash": "sha256-zMlOsBH3Ko8IBjlhABd+Jr2c/7JCSCy9k+K0BpToCNs=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ckbdq9ruxq.wasm"
    },
    {
      "hash": "sha256-pdkXa9EEZWuP7M415RjN0ZC5CoMU9hcxYmaiTei1wHI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.nld6kq2pwf.wasm"
    },
    {
      "hash": "sha256-a/0Af2XIYluqNM97qMHbxpix/RVQxB7Q1POvdMUTA00=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.xdebdmakgf.wasm"
    },
    {
      "hash": "sha256-wH+c7DNMvfIGWM02tKkt08GTQm4PBCtLID96I4RrRSU=",
      "url": "_framework/Microsoft.AspNetCore.Components.ctiikrvaqd.wasm"
    },
    {
      "hash": "sha256-XTq/tEjZkTKdBvCDafUHCw4LgJfH0pKruxcsK+cXQYY=",
      "url": "_framework/Microsoft.CSharp.b6wbugnn7x.wasm"
    },
    {
      "hash": "sha256-3DH5Li3nbKgskNzRybjZBIfXSoxH/TN0wolg2KHl/YQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.w7skqr0zek.wasm"
    },
    {
      "hash": "sha256-D1jnvoQnv2aAi2ps5NzM3lqE5jEy+XJit2tS6neJnXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dtdoolwb2w.wasm"
    },
    {
      "hash": "sha256-FU9TpGEmQwWgADUtlXFTdJIwsCDEyFtgEJacSi8iIoY=",
      "url": "_framework/Microsoft.Extensions.Configuration.jqj4k4pj3p.wasm"
    },
    {
      "hash": "sha256-le5rmrBMDRqKfFdTIfPXMMq+YRlD1okvk+xc6dLUYm8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7t9rn8l3bj.wasm"
    },
    {
      "hash": "sha256-UXrIbQ0y/Y4HVyH/H0pzoSYB4x8Ux/HUWKCoqHieWLU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ttaa9fm62u.wasm"
    },
    {
      "hash": "sha256-DF/ymbcFNX+inXLhxorWc0PXWU7/u3c+uXIi5i8bJvI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.g5re4fc98k.wasm"
    },
    {
      "hash": "sha256-DTNxE9CKAiPWTFDFl3niOH75tY1pweWfsMzIaVbhBMI=",
      "url": "_framework/Microsoft.Extensions.Logging.r2dra2oldd.wasm"
    },
    {
      "hash": "sha256-uo1w7sxHgCNMcwq2qEX/0jMxLZj/MMO1qf687j382P8=",
      "url": "_framework/Microsoft.Extensions.Options.65wgrrkcha.wasm"
    },
    {
      "hash": "sha256-7R0sWRhKvcSoQaFmMrrXBOS1v+DUjxhETvDxEQbHVRQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.7za6xlrecu.wasm"
    },
    {
      "hash": "sha256-d1csL6xZFLtlvPbddYtpSayl19/drI7WubYTnTBYboc=",
      "url": "_framework/Microsoft.Extensions.Validation.zlafc2er9f.wasm"
    },
    {
      "hash": "sha256-PbFL4iy7d51g3xqJodWZQ8PfU6M8RHmVnsbJcc+D/Zo=",
      "url": "_framework/Microsoft.JSInterop.5ifrufjqbv.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-cLVNovefC9F04tK245qPNjGnqZe2UJLeVoZ+nRkRbCA=",
      "url": "_framework/MoreLinq.wkgemdkwo6.wasm"
    },
    {
      "hash": "sha256-qIHmYHu8Tx8xpLRm1wWccLL8BTvtOR33aCodIDqE7yY=",
      "url": "_framework/Radzen.Blazor.szeblzox47.wasm"
    },
    {
      "hash": "sha256-Ga26FJz4Jl0b6P1qQjCydhtzlFxylYYn0E2+cjREMro=",
      "url": "_framework/Siteswap.Details.ltjbgthn0f.wasm"
    },
    {
      "hash": "sha256-tTL7BcjYUiFVwHwECiMAd6KgWb8lJt6ittRZHK1VRaA=",
      "url": "_framework/Siteswaps.Components.h1o4s94xsv.wasm"
    },
    {
      "hash": "sha256-irv8CigVk/Pd5sbzzJew5siyRfsawr9BFydXQb6ZkDg=",
      "url": "_framework/Siteswaps.Generator.2tqfzbslx4.wasm"
    },
    {
      "hash": "sha256-7UZ/LrKf1FDQdR8VPa4agGDldNjBwi5jZI4n4SGvnGc=",
      "url": "_framework/Siteswaps.Generator.Core.j00siq95gn.wasm"
    },
    {
      "hash": "sha256-94yGdEUJuCTVs0gEQqsnJOuCFcintAe/YARjamO1mVM=",
      "url": "_framework/System.Collections.5xaviy5vv2.wasm"
    },
    {
      "hash": "sha256-5NE6EF/cIhLdSd+EvwruWEpeCm6KAqDhDh5/1UKXRMo=",
      "url": "_framework/System.Collections.Concurrent.0fwcrt7o87.wasm"
    },
    {
      "hash": "sha256-h2bA/tBegdBn0mao1VWv7XPC8mIBHe6weDkUMFCtNUM=",
      "url": "_framework/System.Collections.Immutable.3xa5cto85h.wasm"
    },
    {
      "hash": "sha256-+4lnBn8QEsGVrtGoPV3I4ZinZPhs6LGRfoQutiSEagE=",
      "url": "_framework/System.Collections.NonGeneric.9jd6wr0qyj.wasm"
    },
    {
      "hash": "sha256-BtOhh0TngeRnqTpp76/O/sgp9tBzkv3KkzAukcGXmOQ=",
      "url": "_framework/System.Collections.Specialized.uqcm9sl4so.wasm"
    },
    {
      "hash": "sha256-+jXv5myZK7RDL3jISNBm3YS6BnYzTHWqFyv/ULjOWrc=",
      "url": "_framework/System.ComponentModel.6p3x58af60.wasm"
    },
    {
      "hash": "sha256-MBUMB3LaOpgI+lgmM61f42LvT0ovwCLzr3pm9OLULoA=",
      "url": "_framework/System.ComponentModel.Annotations.kn66qppnjc.wasm"
    },
    {
      "hash": "sha256-hemKWbmCJA1nHPUFmECcw2qXJ7DUvJDUH/M5y/nImLk=",
      "url": "_framework/System.ComponentModel.Primitives.p778j4pkq5.wasm"
    },
    {
      "hash": "sha256-NMRe8pMxUO/CSWQrKZ7G3Aa5qeoGEn1QbCIrcsBh2lQ=",
      "url": "_framework/System.ComponentModel.TypeConverter.gfenvpxc4n.wasm"
    },
    {
      "hash": "sha256-Des6fMApjpjQbGFrZb1pUs3lP2EA4HtOqpBPqfKMP9I=",
      "url": "_framework/System.Console.r2po0gks52.wasm"
    },
    {
      "hash": "sha256-A8XPVUtS87o3+N04hXe1wtLepz/jsoSDluJphOu99dg=",
      "url": "_framework/System.Core.zcbadcxyey.wasm"
    },
    {
      "hash": "sha256-Wf7gNtrUc5nQpO4zr5RO6EdO/Sqpey5ObB49t3qDgSE=",
      "url": "_framework/System.Data.Common.7weh4ihqmd.wasm"
    },
    {
      "hash": "sha256-wWPcNNDfZ/pt5aY8se/yLmfVZcpLfb+vkseoGrc5/Do=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.5f2myvbjzl.wasm"
    },
    {
      "hash": "sha256-sm3/j8w+HGuxacGuDERfcH3+paHY3l/M03bmIGFOSGo=",
      "url": "_framework/System.Diagnostics.TraceSource.me0dv01nms.wasm"
    },
    {
      "hash": "sha256-Ms0MXKwEHbcbQABCQcz1UtmSjJGoxk8LdIAGlvJgqGM=",
      "url": "_framework/System.Drawing.Primitives.u5i9d37a5f.wasm"
    },
    {
      "hash": "sha256-TlXNxmLk1YV1ejuovnCatD2nWmMHX0d1ro832sI20b0=",
      "url": "_framework/System.Drawing.e8qudqmdpa.wasm"
    },
    {
      "hash": "sha256-sRfXsXtfMMTo2CLx4ZKDFwtkYvOe/IRL5Gwf4dsnXMk=",
      "url": "_framework/System.IO.MemoryMappedFiles.zn3zrwfe2r.wasm"
    },
    {
      "hash": "sha256-5NlyiKMjQMJVLZ+E92VHzP4NXkvjJnT4LTZkWqm0KJc=",
      "url": "_framework/System.IO.Pipelines.orwcdf2bqi.wasm"
    },
    {
      "hash": "sha256-kCn05pitMJb4HeHW8//LYoOnmmVre2ARo/2fCjaKzd4=",
      "url": "_framework/System.Interactive.Async.w4ccatvl43.wasm"
    },
    {
      "hash": "sha256-e7f/b+XuYlL7gnMn3ZSLldZLWLhnjmjnS9e/lc9nFhI=",
      "url": "_framework/System.Linq.Async.9ng5pnnqa8.wasm"
    },
    {
      "hash": "sha256-eQIFTV1HrX05FfuiE7+IIiOIO+jyh1EDgCB/r0sdFEc=",
      "url": "_framework/System.Linq.AsyncEnumerable.dzwuo6d5d4.wasm"
    },
    {
      "hash": "sha256-5mMcR6Lmx8cWJWZek6QwlfKvlcYMgwRBLA5/5KeAVes=",
      "url": "_framework/System.Linq.Dynamic.Core.yt3i0kvfqy.wasm"
    },
    {
      "hash": "sha256-rtIycKtoAlmnJVWbuiANvDY2D4ifLYE9M00sLpcTK1k=",
      "url": "_framework/System.Linq.Expressions.edn4mmzvnf.wasm"
    },
    {
      "hash": "sha256-RSF6b2FxNUxnq0jqHG1IcPrSJLFTWW4ZVSNXTLSjyzI=",
      "url": "_framework/System.Linq.Queryable.l4mhnkdyn3.wasm"
    },
    {
      "hash": "sha256-FNU6jl+xL3Itkmjmc4PIbcfktUeq5lBtOHIxAOJSsKI=",
      "url": "_framework/System.Linq.wh51b2pddz.wasm"
    },
    {
      "hash": "sha256-oLRp33zeVPtvsRwIoczoGoNlHTs+QMYkGUbG+vtdypE=",
      "url": "_framework/System.Memory.kji3cubnvm.wasm"
    },
    {
      "hash": "sha256-9+hifoS1pTMOYnun2s2pGCLO2GIBpeZc+OaHGrjVtTI=",
      "url": "_framework/System.Net.Http.jh0akx9ikc.wasm"
    },
    {
      "hash": "sha256-GcUZS2bRpGeEZCKIDbdSt4QSQyAwEiU5RtUDWnGUaOI=",
      "url": "_framework/System.Net.Primitives.vi4gsxomfn.wasm"
    },
    {
      "hash": "sha256-lRaazvAInUA1MwqdLzsVYBuXTsYGE19/L/+rsmolay4=",
      "url": "_framework/System.ObjectModel.97pwn6ow83.wasm"
    },
    {
      "hash": "sha256-Z3T9noSLH+uRSeB3xsGochPKgMMYI532yRbTi23ot7M=",
      "url": "_framework/System.Private.CoreLib.lt3dficudb.wasm"
    },
    {
      "hash": "sha256-qEsrsGLxQAT7zZCU/kZyz0k7xq+OSbu1HcVds4YqzbA=",
      "url": "_framework/System.Private.Uri.021k2otc44.wasm"
    },
    {
      "hash": "sha256-zj/vIi/i/DNTBabA+newQAXMZSdut28hLymD1IS53aE=",
      "url": "_framework/System.Private.Xml.Linq.m2v6hf1c5y.wasm"
    },
    {
      "hash": "sha256-TKhfpwCULcz59U1sXwZ8OYVO2cPdrtH/TxtobzxwZg4=",
      "url": "_framework/System.Private.Xml.s2lses0h9o.wasm"
    },
    {
      "hash": "sha256-LyE9Rm4kWsBbSptYpgV0/S1c3Lfq0TevI7YwWHp5ueg=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.jniflczcyf.wasm"
    },
    {
      "hash": "sha256-c1IM3phfGVIm/I5OgIglGoGEcHWwHoKqwo8exqK9ckg=",
      "url": "_framework/System.Reflection.Emit.v95jx8t42v.wasm"
    },
    {
      "hash": "sha256-7fxQRWMlzDZacsqgfD0kpxfG0yPKuBfZfB+7BnWcMh8=",
      "url": "_framework/System.Reflection.Metadata.xz62hrvms1.wasm"
    },
    {
      "hash": "sha256-d3K/0sOH7IpBeQB9qj98KMmsPZy9QPcDIJxaT7Gw7LE=",
      "url": "_framework/System.Reflection.Primitives.nsfubnmzhb.wasm"
    },
    {
      "hash": "sha256-Gou7ofN8XZcBsP+q3wRMMij0QKBJHuPXANGusbmh+Z0=",
      "url": "_framework/System.Runtime.6xvuiz5utk.wasm"
    },
    {
      "hash": "sha256-WAM5OMcJO64InQovrLZ46el9w7eLyMLnICLGedHyr8Q=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ktbegkrd8y.wasm"
    },
    {
      "hash": "sha256-9aPqmfsBq57giPJV0U0WNFiu3KZ9vUmwqO4JNEcQ880=",
      "url": "_framework/System.Runtime.InteropServices.fj9jdecnpc.wasm"
    },
    {
      "hash": "sha256-MVD3ssIt7P+k4uq8Wp3WQbpOnJZhtGIWkQy1a7QrI3w=",
      "url": "_framework/System.Runtime.Serialization.Primitives.zfd78u3cjz.wasm"
    },
    {
      "hash": "sha256-oAiqN4+0rXCP07gQh1D89o9s9TjaMTh1Pgbtm7wEiPg=",
      "url": "_framework/System.Security.Cryptography.ouxcxoa0xa.wasm"
    },
    {
      "hash": "sha256-SjSXjB+ypX/cHtZAKKaQQwNop8x2URA+CydzqPhhArs=",
      "url": "_framework/System.Text.Encodings.Web.6ki720vlaa.wasm"
    },
    {
      "hash": "sha256-4z3P6a/sCFJToHYeF89KE3PYgwyjk4M8ktl5Q8JtOAI=",
      "url": "_framework/System.Text.Json.vtbk5s3ar4.wasm"
    },
    {
      "hash": "sha256-ylDktiBqwJSveXWfAIdzJ/B4j6jM0JJYTA9Q5VL4AJg=",
      "url": "_framework/System.Text.RegularExpressions.6gnaq473vv.wasm"
    },
    {
      "hash": "sha256-/eoeqi8pIdj6qpku1wAfSipmpEIApfz/Pdm7/JlvGSw=",
      "url": "_framework/System.Threading.zkdp4s1yjq.wasm"
    },
    {
      "hash": "sha256-MnMTQ58LKdYfHk8GzjEwEZzNjPdhpMeoEsZguk5jFNk=",
      "url": "_framework/System.Web.HttpUtility.qarozkw8cv.wasm"
    },
    {
      "hash": "sha256-sndSZhomaMgZJSV8YYnGu9JTyssQJWIyipDAPAgJbwQ=",
      "url": "_framework/System.Xml.Linq.ysq4rzz6yg.wasm"
    },
    {
      "hash": "sha256-xMLso5CVXzn2dmHskYwkJ+eKyBfMcQjxri4VVivVkLI=",
      "url": "_framework/System.Xml.XDocument.cwv7oqq5f5.wasm"
    },
    {
      "hash": "sha256-JRSnUKU4RCZCvwQXVaK87jabHPSnQK1daxG24xvCico=",
      "url": "_framework/System.deed694j9w.wasm"
    },
    {
      "hash": "sha256-qmei3ao4lg8vkeCZ6fu4ih0TWXD9dYOtmzIGtnlyxNw=",
      "url": "_framework/VisNetwork.Blazor.2ef7yrjxai.wasm"
    },
    {
      "hash": "sha256-aZm8/InlSFstQx/Kyw8In8hI3glDi1croPDwP6AjOt0=",
      "url": "_framework/Webassembly.l9d5rjiijm.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-uGkb1nsTucXRwWALp/L9GT0LrYA0JPthwyxz/n8l2bc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-uhDj0fQ4fcXIIsNLtUozIMSQFoMNYyVGAaTwQx9TigE=",
      "url": "_framework/dotnet.native.eahnktlfhl.wasm"
    },
    {
      "hash": "sha256-sAIgfePhjGeMa0y0h2k1BC1/55SxiZQi3UEvixm80sQ=",
      "url": "_framework/dotnet.native.gkvy5h2kjd.js"
    },
    {
      "hash": "sha256-ArknccFM1sHNVcih0x1h52AG+abNCoQjl6BlVrv3ePw=",
      "url": "_framework/dotnet.runtime.q5rqv3xrhm.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-xvptSBfcMwUZeNjDef/alOysvAQVPxLXbySpFo2K1/c=",
      "url": "_framework/netstandard.ei3kwfzfz9.wasm"
    },
    {
      "hash": "sha256-5mqFq4DUGr9sXZSIkbYLDayNwcA8PMb1oGBbfJLGPo0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-djO3wMl9GeaC/u6K+ic4Uj/LKhRUSlUFcsruzS7v5ms=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-z/c1rzzuR6WNgmPgoYRXMC9xLJcMkN4hbTIx/RxBs7I=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-PLCtxjGaaA0qzetfmiWzhNJAytq5vqIYg2UNNX3NMqU=",
      "url": "css/colors.css"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "css/custom.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-H06eu21WxOovkIymeQKzlfO0fjUFYN/w7kJJ8ZIiVXo=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-XwJu4hjbLyi51bV/uD/h2b+2rJJGJguBhCD+5uic5Mw=",
      "url": "css/radzen.css"
    },
    {
      "hash": "sha256-ZGgyZhgQdPusEO7pLng67F72Vje6Pd553JzzQnuZjUw=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-+PjwLZu5vwAOATMx20PRzOFoNpIyPfKdHYV6hXTTfBw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-meOREuTFCMC7g3bknVg++vnJ6gmqKOVDHLq0663KNfg=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Jy0BvOxh3fnirqTQFxfngsfm5UYIX+iq0dY8p6YoqBg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fh8VA992XMpeCZiRuU4xii75UIG6KvHrbUF8yIS/2/4=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+iAOW17+fSyX0lsqsBz3KezMu/lrIkg7k07jDKxOkUQ=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-+WkXx3gWJk6YNxLWeZwznsCqmEpRBHUz5NfPquLWND4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yFpGhuAbEpinkeda0Mgo5cLe9K5Zad5JGCSjmvraN5U=",
      "url": "staticwebapp.config.json"
    },
    {
      "hash": "sha256-+0OWG7rwmaRK1rWWgZF3+9p5jFJ6lSdSTC8KN/pf3RQ=",
      "url": "sw-registrator.js"
    }
  ]
};
